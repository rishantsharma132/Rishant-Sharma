<?php



// This file is part of Moodle - https://moodle.org/



//



// Moodle is free software: you can redistribute it and/or modify



// it under the terms of the GNU General Public License as published by



// the Free Software Foundation, either version 3 of the License, or



// (at your option) any later version.



//



// Moodle is distributed in the hope that it will be useful,



// but WITHOUT ANY WARRANTY; without even the implied warranty of



// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the



// GNU General Public License for more details.



//



// You should have received a copy of the GNU General Public License



// along with Moodle. If not, see <https://www.gnu.org/licenses/>.







/**



 * @package local_user_time_spent



 * @category quizaccess



 * @copyright  ELS <admin@elearningstack.com>



 * @author eLearningstack



 */







namespace enrol_els_paypalcheckout\external;



defined('MOODLE_INTERNAL') || die();



require_once("$CFG->libdir/externallib.php");



require_once("$CFG->dirroot/webservice/externallib.php");



global $CFG;



use external_api;



use external_function_parameters;



use external_value;



use enrol_els_paypalcheckout\user_enrolment;







class responseData extends external_api {



    // Service for insert timeuse on quiz.



    public static function get_paypalcheckout_responseData_is_allowed_from_ajax() {



        return true;



    }



    public static function get_paypalcheckout_responseData_returns() {



        return new external_value(PARAM_RAW, 'User enrol');



    }



    public static function get_paypalcheckout_responseData_parameters() {



        return new external_function_parameters(



            array(



                'courseid' => new external_value(PARAM_INT, 'course id', '', 'Course id'),
                'orderdata' => new external_value(PARAM_RAW, 'orderdata', '', 'Order data'),
                'discountvalue' => new external_value(PARAM_INT, 'discountvalue', '', 'Discount Value'),
                'discount_type' => new external_value(PARAM_RAW, 'discount_type', '', 'Discount Value')


            )



        );



    }



    public static function get_paypalcheckout_responseData($courseid, $orderdata, $discountvalue, $discount_type) {



        require_login();



        $params = self::validate_parameters(



            self::get_paypalcheckout_responseData_parameters(),



            array(



                'courseid' => $courseid,      



                'orderdata' => $orderdata,
                

                'discountvalue' => $discountvalue,
                

                'discount_type' => $discount_type



            )



        );



   



        return json_encode(user_enrolment::enroluser_intocourse($params));



    }



}