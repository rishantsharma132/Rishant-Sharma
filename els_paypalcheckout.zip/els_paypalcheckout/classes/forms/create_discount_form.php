<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
* @package enrol_els_paypalcheckout
* @category enrol
* @copyright  ELS <admin@elearningstack.com>
* @author eLearningstack
*/

require_once "../../config.php";
require_once "$CFG->libdir/formslib.php";

class create_discount_form extends moodleform
{
    //Add elements to form

    public function definition()
    {
        global $CFG, $DB;
        $manage_coupon = $CFG->wwwroot."/enrol/els_paypalcheckout/manage_coupon.php";
        echo '<a class="btn btn-primary" href="'.$manage_coupon.'">'.get_string('manage_coupon', 'enrol_els_paypalcheckout').'</a> &nbsp';  
        $report = $CFG->wwwroot."/enrol/els_paypalcheckout/report.php";
        echo '<a class="btn btn-primary" href="'.$report.'">'.get_string('report', 'enrol_els_paypalcheckout').'</a>';   


        $courses = self::getcourses();
        $all_course = [];
        foreach ($courses as $get_course) {
            $all_course[$get_course->id] = $get_course->fullname;
        }

        $mform = $this->_form; // Don't forget the underscore!
        $mform->addElement("text", "couponcode", get_string('coupon_code', 'enrol_els_paypalcheckout')); // Add elements to your form
        $mform->setDefault("couponcode", ""); //Set type of element
        $mform->setType("couponcode", PARAM_RAW);
        $mform->addRule('couponcode',  get_string('field_required', 'enrol_els_paypalcheckout'), 'required', null, 'client');
        $opt = [
            "subdirs" => 0,
            "maxbytes" => 100,
            "maxfiles" => 1,
            "changeformat" => 0,
            "context" => null,
            "noclean" => 0,
            "trusttext" => 0,
            "enable_filemanagement" => false,
        ];

        $mform->addElement("editor", "desc", get_string('description', 'enrol_els_paypalcheckout'), null, $opt);
        $mform->setType("desc", PARAM_RAW);
        $mform->addElement("select","discount_type", get_string('discount_type', 'enrol_els_paypalcheckout'),["Percentage" => "Percentage", "Fixed" => "Fixed"],["class" => "dropdown"]);

        $mform->setDefault("discount_type", "");
        $mform->setType("discount_type", PARAM_RAW);
        $mform->addElement("select", "coupon_currency", get_string('coupon_crncy', 'enrol_els_paypalcheckout'), [
            "USD" => "USD",
            "AUD" => "AUD",
            "INR" => "INR",
        ]);

        $mform->setDefault("coupon_currency", "");
        $mform->setType("coupon_currency", PARAM_RAW);
        $mform->addElement("text", "discount_value", get_string('dscnt_value', 'enrol_els_paypalcheckout')); // Add elements to your form
        $mform->setDefault("discount_value", ""); //Set type of element
        $mform->setType("discount_value", PARAM_RAW);
        $mform->addRule('discount_value',  get_string('field_required', 'enrol_els_paypalcheckout'), 'required', null, 'client');
        $mform->addRule('discount_value', get_string('enter_numericvalue', 'enrol_els_paypalcheckout'), 'numeric', null, 'client');

        $mform->addElement("select", "coupon_type",
            get_string('coupon_typ', 'enrol_els_paypalcheckout'), [ "Single Course" => "Single Course",
                "Subscription" => "Subscription",
            ], ["class" => "dropdown"]);
        $mform->setDefault("coupon_type", "");
        $mform->setType("coupon_type", PARAM_RAW);

        $mform->addElement( "select", "multicour_selection", get_string('select_multicourse', 'enrol_els_paypalcheckout'), $all_course, ["class" => "selectcourse"]);
        $mform->setDefault("multicour_selection", $all_course);
        $mform->getElement("multicour_selection")->setMultiple(true);
        $mform->setType("multicour_selection", PARAM_RAW);
        //$mform->addRule('multicour_selection',  get_string('field_required', 'enrol_els_paypalcheckout'), 'required', null, 'client');

        $mform->addElement("date_selector", "datefrom", get_string('date_validfrom', 'enrol_els_paypalcheckout'));
        $mform->setDefault("datefrom", "");
        $mform->setType("datefrom", PARAM_RAW);

        $mform->addElement("date_selector", "dateto", get_string('date_validto', 'enrol_els_paypalcheckout'));
        $mform->setDefault("dateto", "");
        $mform->setType("dateto", PARAM_RAW);
        $opt = [
            "subdirs" => 0,
            "maxbytes" => 100,
            "maxfiles" => 1,
            "changeformat" => 0,
            "context" => null,
            "noclean" => 0,
            "trusttext" => 0,
            "enable_filemanagement" => false,
        ];

        $mform->addElement( "editor", "termcondition", get_string('terms_conditions', 'enrol_els_paypalcheckout'), null, $opt);
        $mform->setType("termcondition", PARAM_RAW);
        $this->add_action_buttons();
    }

    //Custom validation should be added here

    function validation($data, $files)
    {
        global $DB; 
        $errors = parent::validation($data, $files);  
        $now = time();  
        $startdate = $data['datefrom'];  
        $enddate = $data['dateto'];
        if ($startdate > $enddate) {  
            $errors['dateto'] = get_string('date_validation', 'enrol_els_paypalcheckout');
        }    
        $coursesval = $data['multicour_selection'];
        if (empty($coursesval)) {  
            $errors['multicour_selection'] = get_string('selcourse_validation', 'enrol_els_paypalcheckout');
        }    
        return $errors;  
    }

    public function getcourses() {
        global $DB;
        $courses = $DB->get_records_sql("SELECT c.id, c.fullname FROM {course} c INNER JOIN {enrol} e on c.id=e.courseid WHERE c.visible=1 AND c.id!=1 AND e.enrol='els_paypalcheckout'");
        return $courses;
    }
}