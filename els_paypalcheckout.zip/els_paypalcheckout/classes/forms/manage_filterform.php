<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
* @package enrol_els_paypalcheckout
* @category enrol
* @copyright  ELS <admin@elearningstack.com>
* @author eLearningstack
*/

defined("MOODLE_INTERNAL") || die();
require_once $CFG->libdir . "/formslib.php";
class managefilter_form extends moodleform
{
    public function definition()
    { 
        global $CFG;
        $discount_code = $CFG->wwwroot."/enrol/els_paypalcheckout/create_discount.php";
        echo '<a class="btn btn-primary" href="'.$discount_code.'">'.get_string('create_coupon', 'enrol_els_paypalcheckout').'</a> &nbsp';  
        $report = $CFG->wwwroot."/enrol/els_paypalcheckout/report.php";
        echo '<a class="btn btn-primary" href="'.$report.'">'.get_string('report', 'enrol_els_paypalcheckout').'</a>';   
        $mform = &$this->_form;
        $mform->addElement("text", "discount_code", get_string("discount_code", "enrol_els_paypalcheckout"));
        $mform->setType("discount_code", PARAM_TEXT);
        $mform->addElement("date_selector", "datefrom", get_string("fromtrxdate", "enrol_els_paypalcheckout"), ["optional" => true]);
        $mform->setType("datefrom", PARAM_TEXT);
        $mform->disabledIf("datefrom", "qe");
        $mform->addElement("date_selector", "dateto", get_string("totrxdate", "enrol_els_paypalcheckout"), ["optional" => true]);
        $mform->setType("dateto", PARAM_TEXT);
        $mform->disabledIf("dateto", "qe");
        $this->add_action_buttons(false, get_string("submit"));
    }
}