<?php

// This file is part of Moodle - https://moodle.org/

//

// Moodle is free software: you can redistribute it and/or modify

// it under the terms of the GNU General Public License as published by

// the Free Software Foundation, either version 3 of the License, or

// (at your option) any later version.

//

// Moodle is distributed in the hope that it will be useful,

// but WITHOUT ANY WARRANTY; without even the implied warranty of

// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the

// GNU General Public License for more details.

//

// You should have received a copy of the GNU General Public License

// along with Moodle. If not, see <https://www.gnu.org/licenses/>.



/**

* @package enrol_els_paypalcheckout

* @category enrol

* @copyright  ELS <admin@elearningstack.com>

* @author eLearningstack

*/



defined('MOODLE_INTERNAL') || die;

require_once($CFG->libdir . '/formslib.php');



class filter_form extends moodleform {

    public function definition() {

        global $CFG;

        if(is_siteadmin()) {

           /* $discount_code = $CFG->wwwroot."/enrol/els_paypalcheckout/create_discount.php";

            echo '<a class="btn btn-primary" href="'.$discount_code.'">'.get_string('create_coupon', 'enrol_els_paypalcheckout').'</a> &nbsp';  

            $manage_coupon = $CFG->wwwroot."/enrol/els_paypalcheckout/manage_coupon.php";

            echo '<a class="btn btn-primary" href="'.$manage_coupon.'">'.get_string('manage_coupon', 'enrol_els_paypalcheckout').'</a>';  */ 

            $mform =& $this->_form;

            $mform->addElement('text', 'username', get_string('username', 'enrol_els_paypalcheckout'));

            $mform->setType('username', PARAM_TEXT);

            /*$mform->addElement('text', 'discount_code', get_string('discount_code', 'enrol_els_paypalcheckout'));

            $mform->setType('discount_code', PARAM_TEXT);*/

            $mform->addElement('date_selector', 'startfrom', get_string('fromtrx_date', 'enrol_els_paypalcheckout'),['optional' => true]);

            $mform->setType('startfrom', PARAM_TEXT);

            $mform->disabledIf('startfrom', 'eq');

            $mform->addElement('date_selector', 'endto', get_string('totrx_date', 'enrol_els_paypalcheckout'),['optional' => true]);

            $mform->setType('endto', PARAM_TEXT);

            $mform->disabledIf('endto', 'eq');

            $this->add_action_buttons(false, get_string('submit'));

        }

    }

}