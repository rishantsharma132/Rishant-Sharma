<?php



// This file is part of Moodle - https://moodle.org/



//



// Moodle is free software: you can redistribute it and/or modify



// it under the terms of the GNU General Public License as published by



// the Free Software Foundation, either version 3 of the License, or



// (at your option) any later version.



//



// Moodle is distributed in the hope that it will be useful,



// but WITHOUT ANY WARRANTY; without even the implied warranty of



// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the



// GNU General Public License for more details.



//



// You should have received a copy of the GNU General Public License



// along with Moodle. If not, see <https://www.gnu.org/licenses/>.







/**



 * @package enrol_paypal



 * @category enrol



 * @copyright  ELS <admin@elearningstack.com>



 * @author eLearningstack



 */



namespace enrol_els_paypalcheckout;



defined('MOODLE_INTERNAL') || die();







use coding_exception;



use dml_exception;



use stdClass;



use context_system;



use user_picture;



use context_coursecat;



use core_text;



use core_user;



use enrol_els_paypalcheckout\invoices;









/**



 * Class tool_olms_tenant_user represents a tenancy object.



 */



class user_enrolment {



    public static function enroluser_intocourse($params) {



        global $DB, $CFG, $USER;



        $courseid = (int) $params['courseid'];



        $userid = $USER->id;



        $orderdata = json_decode($params['orderdata']);  



        $user = $DB->get_record("user", ["id" => $USER->id]);



        $course = $DB->get_record("course", ["id" => $courseid]);



        $plugin_instance = $DB->get_record("enrol", [

            "courseid" => $courseid,

            "enrol" => "els_paypalcheckout",

            "status" => 0,

        ]);
        $total_cost = $plugin_instance->cost;
        $discount = $params['discountvalue'];
        $discount_type = $params['discount_type'];
        if($discount!=0){
         if ($discount_type == "Fixed") {
                $total_cost = $plugin_instance->cost - $discount;
            } else {
                $count_discount = ($total_cost * $discount) / 100;

                $total_cost = $total_cost - $count_discount;
            }
        }


        $transactionID = 'abc'.time();

        $paidAmount = $plugin_instance->cost;

        $rec = new stdClass();

        $rec->item_number = $courseid ;

        $rec->item_name = $course->fullname;

        $rec->item_price = $plugin_instance->cost;

        $rec->item_price_currency = 'USD';

        $rec->buyer_name = $orderdata->payer->name->given_name . " " . $orderdata->payer->name->surname;

        $rec->user_id = $userid;

        $rec->txn_id = $orderdata->id;

        $rec->paid_amount = $plugin_instance->cost;

        $rec->paid_amount_currency = 'USD';

        $rec->payment_status = 'Completed';

        $rec->created = time();

        $rec->modified = time();

        $rec->discount_code = '';

        $rec->discount_code_amount = $discount;

        $rec->discount_type = 'Percentage';        

        $data["orderID"] = $DB->insert_record("els_paypalcheckout_orders", $rec);

        $data["courseid"] = $courseid;

        $data["status"] = 1;

        $plugin = enrol_get_plugin("els_paypalcheckout");

        $plugin_instance = $DB->get_record("enrol", [

            "courseid" => $courseid,

            "enrol" => "els_paypalcheckout",

            "status" => 0,

        ]);

        if ($plugin_instance->enrolperiod) {

            $timestart = time();

            $timeend = $timestart + $plugin_instance->enrolperiod;

        } else {

            $timestart = 0;

            $timeend = strtotime('+90 days');

        }

        $plugin->enrol_user(

            $plugin_instance,

            $rec->user_id,

            $plugin_instance->roleid,

            $timestart,

            $timeend

        );

        $user_obj = $DB->get_record("user", ["id" => $rec->user_id]);      

        $rec1 = new stdClass();

        $rec1->business = 'safetyprotc';

        $rec1->receiver_email = 'cs@aviationcontinuinged.com';

        $rec1->receiver_id = "";

        $rec1->userid = $user_obj->id;

        $rec1->item_name = $course->fullname;

        $rec1->courseid = $courseid;

        $rec1->instanceid = $plugin_instance->id;

        $rec1->memo = "";

        $rec1->tax = "";

        $rec1->option_name1 = "User";

        $rec1->option_selection1_x = $total_cost;

        $rec1->option_name2 = "";

        $rec1->option_selection2_x = $plugin_instance->cost;

        $rec1->payment_status = "Completed";

        $rec1->pending_reason = "";

        $rec1->reason_code = "";

        $rec1->txn_id = $orderdata->id;

        $rec1->parent_txn_id = "";

        $rec1->payment_type = "instant";

        $rec1->timeupdated = time();

        $rec1->discount_code = '';

        $rec1->discount_code_amount = $discount;

        $rec1->discount_type = 'Percentage';

        $checkoutid = $DB->insert_record("enrol_els_paypalcheckout", $rec1);  

        $checkout = $DB->get_record('enrol_els_paypalcheckout', array('id'=>$checkoutid));

        $pdffile =  invoices::print_invoice($checkout,false,true);

        if (
            $DB->record_exists("user_enrolments", [

                "userid" => $user_obj->id,

                "enrolid" => $plugin_instance->id,

            ])

        ) {

            $user = $DB->get_record("user", ["id" => $user_obj->id]);

            $user2 = $DB->get_record("user", ["id" => 4025]);

            $course = $DB->get_record("course", ["id" => $courseid]);

            $email_user = $DB->get_record("user", ["id" => 4025]);

            $subject = "SafetyPro Enrollment Successful";

             $messagetext = $messageHtml = '<div style="font-family: Arial;font-size: 12px;"><p>Hi ' . $user->firstname . " " . $user->lastname . ',</p>                  
                    <p>Welcome and thank you for choosing our <a href="https://www.safetyprotc.com/home.php" style="font-weight:bold;">SafetyPro™ Training Center</a> for your safety training. You have been enrolled into our ' . $course->fullname . ' course.</p>
                    <p>Please use <a href="https://www.google.com/chrome/" >Google Chrome</a>, <a href="https://www.microsoft.com/en-us/edge" >Microsoft Edge</a> or <a href="https://www.mozilla.org/en-US/" >Mozilla Firefox</a> to use the website and <strong>MAKE CERTAIN THAT CONTENT BLOCKING, AD BLOCKING and ANTIVIRUS PROTECTION ARE TURNED OFF</strong> to allow grades to be recorded. <a href="https://www.safetyprotc.com/faq.php"><u>Learn How Here</u></a>. </p>
                   
                    <p>Your course will be available to you for 90 days.  You may begin at any time. While you can stop in the middle of a lesson and resume at a later time, we suggest you allot the time to complete each lesson in one session.</p> 
                    <p>Your course will be available under the "My Courses" link on the far right of the blue navigation bar.</p>                    
                    <img src="https://safetyprotc.com//enrol/els_paypalcheckout/pix/1.png"/>
                    <br/>
                    <p>
                    The "My Courses" link directs to the Course Overview page.  Here you can access the course(s) enrolled in. The course can be viewed in three ways; Card, List or Summary.</p>                   
                    <img src="https://safetyprotc.com//enrol/els_paypalcheckout/pix/2.png"/>
                    <br>
                    <p>You will have 3 opportunities to view each lesson, quiz and the final exams. To retake a quiz only, simply close the lesson window, open the lesson again, after checking the "Start a new attempt". You can watch the lesson again or scroll directly down to the quiz.</p>             
                    <img src="https://safetyprotc.com//enrol/els_paypalcheckout/pix/3.png"/>
                    <br/>
                    <p>Configuration information can be found in our <a href="https://www.safetyprotc.com/faq.php">FAQ Section</a> found on our home page.</p>                   
                    <p>
                    All lessons on the SafetyPro Training Center are presented in HTML5 format and in Pop-Up windows. When selecting a Lesson Hyperlink, should a new window NOT appear the Pop-Up Blocker is enabled. Enabling pop-ups from our site will solve this issue.</p>                   
                    <p>The certificate link will become active when all course criteria are met. Restrictions to certificate issuance are included in the certificate module found at the bottom of course just below the Final Assessment Lesson.</p>                   
                    <img src="https://safetyprotc.com//enrol/els_paypalcheckout/pix/4.png"/>
                    <br>    
                    <p>Once the certificate link is active, click it revealing a button to either <strong>"Get" or "Review"</strong> your certificate which will be displayed in a pop-up window and emailed. Save and/or print the generated PDF certificate.</p>
                    <p>The "Restricted: Not available unless" list is your "Still must complete" list.  The "Restricted" list will diminish as you progress through your lessons.</p>  
                    <p><strong><u>You must:</u></strong> View all the lessons and complete the quizzes and obtain a passing score on the final assessment. Our system is designed not to allow "Skimming", so you must view each course or lesson it its entirety.</p>                    
                    <p>If you are taking the Fuel Safety Supervisor 14 CFR 139.321(e)(1) or the Line Fuel Service 14 CFR 139.321(e)(2) course, you must have hands-on fire extinguisher training within 60 days of course completion.</p>                    
                    <p>For Supervisors, the Local Fire Authority will review the information required by the FAA and sign off on the Local Fire Code Verification form provided on the <a href="https://www.safetyprotc.com/index.php/forms-and-brochures"><u>Forms and Brochures Page.</u></a> </p>                    
                    <p>Save this document with your Certificate. This form, along with your Certificate, constitutes your "Certification" in accordance with <strong><u>Advisory Circular 15/5230-4C.</u></strong></p>                    
                    <p>Please be sure that the name on your account is the way you want your Certificate to read.  Please verify our that domain emails @aviationcontinuinged.com can get past your firewalls, spam filters and blacklists, if any. </p>                     
                    <p>If we can be of assistance, please feel free to contact us at 877-322-7139 or email at cs@aviationcontinuinged.com .</p>                         
                    <p>Thanks again for your business, we really do appreciate it and will do all we can to continue to earn it. </p>                       
                    <p>As always, more than ever, for yourself, your co-workers and your families.......</p>                     
                    <p>Please be as safe as you can out there!!</p>                       
                    <p>SafetyPro Customer Service</p>                    
                    <p><strong>Aviation Continuing Education, Inc. / SafetyPro Training Center | Office and Fax 1-877-322-7139</strong></p>
                    <p>           
                    <strong><u>Business and Technical Support Hours</u></strong>
                    <br>
                    Mon-Fri 0800-1800 EST - Phone and Email 
                    <br>
                    Mon-Fri 1800-2300 EST - Email 
                    <br>
                    Sat-Sun 0800-2300 EST - Email                   
                    
                    </p>
                    </div>
             '; 


            $sentmail = email_to_user(

                $user,               

                $email_user,

                $subject,

                $messagetext,

                $messageHtml,

                "",

                "",

                true

            );

            $sentmail1 = email_to_user(

                $user2,               

                $email_user,

                $subject,

                $messagetext,

                $messageHtml,

                "",

                "",

                true

            );


            $filename = clean_filename("SafetyProReceipt".$checkout->id.".pdf"); 

            $filepath = $filename;      

            $subject2 = "SafetyPro Payment Receipt";

            $messageHtml2 = $messagetext2= "<p><strong>Please find attached payment receipt for your training course.  Please save this document for your future use.</strong></p>

                                                <p><strong>If we can be of assistance, please feel free to contact us by phone at 877-322-7139 or by email at cs@aviationcontinuinged.com.</strong></p>";



            $sentmail=email_to_user($user, $email_user, $subject2, $messagetext2, $messageHtml2, $filepath, $filename, false);

            $sentmail1=email_to_user($user2, $email_user, $subject2, $messagetext2, $messageHtml2, $filepath, $filename, false);



        } else {

            $user = $DB->get_record("user", ["id" => $usr_obj->id]);
 
            $course = $DB->get_record("course", ["id" => $courseid]);

            $email_user = $DB->get_record("user", ["id" => 4025]);

            $subject = "SafetyPro Enrollment Successful";

             $messagetext = $messageHtml = '<div style="font-family: Arial;font-size: 12px;"><p>Hi ' . $user->firstname . " " . $user->lastname . ',</p>                  
                    <p>Welcome and thank you for choosing our <a href="https://www.safetyprotc.com/home.php" style="font-weight:bold;">SafetyPro™ Training Center</a> for your safety training. You have been enrolled into our ' . $course->fullname . ' course.</p>
                    <p>Please use <a href="https://www.google.com/chrome/" >Google Chrome</a>, <a href="https://www.microsoft.com/en-us/edge" >Microsoft Edge</a> or <a href="https://www.mozilla.org/en-US/" >Mozilla Firefox</a> to use the website and <strong>MAKE CERTAIN THAT CONTENT BLOCKING, AD BLOCKING and ANTIVIRUS PROTECTION ARE TURNED OFF</strong> to allow grades to be recorded. <a href="https://www.safetyprotc.com/faq.php"><u>Learn How Here</u></a>. </p>
                   
                    <p>Your course will be available to you for 90 days.  You may begin at any time. While you can stop in the middle of a lesson and resume at a later time, we suggest you allot the time to complete each lesson in one session.</p> 
                    <p>Your course will be available under the "My Courses" link on the far right of the blue navigation bar.</p>                    
                    <img src="https://safetyprotc.com//enrol/els_paypalcheckout/pix/1.png"/>
                    <br/>
                    <p>
                    The "My Courses" link directs to the Course Overview page.  Here you can access the course(s) enrolled in. The course can be viewed in three ways; Card, List or Summary.</p>                   
                    <img src="https://safetyprotc.com//enrol/els_paypalcheckout/pix/2.png"/>
                    <br>
                    <p>You will have 3 opportunities to view each lesson, quiz and the final exams. To retake a quiz only, simply close the lesson window, open the lesson again, after checking the "Start a new attempt". You can watch the lesson again or scroll directly down to the quiz.</p>             
                    <img src="https://safetyprotc.com//enrol/els_paypalcheckout/pix/3.png"/>
                    <br/>
                    <p>Configuration information can be found in our <a href="https://www.safetyprotc.com/faq.php">FAQ Section</a> found on our home page.</p>                   
                    <p>
                    All lessons on the SafetyPro Training Center are presented in HTML5 format and in Pop-Up windows. When selecting a Lesson Hyperlink, should a new window NOT appear the Pop-Up Blocker is enabled. Enabling pop-ups from our site will solve this issue.</p>                   
                    <p>The certificate link will become active when all course criteria are met. Restrictions to certificate issuance are included in the certificate module found at the bottom of course just below the Final Assessment Lesson.</p>                   
                    <img src="https://safetyprotc.com//enrol/els_paypalcheckout/pix/4.png"/>
                    <br>    
                    <p>Once the certificate link is active, click it revealing a button to either <strong>"Get" or "Review"</strong> your certificate which will be displayed in a pop-up window and emailed. Save and/or print the generated PDF certificate.</p>
                    <p>The "Restricted: Not available unless" list is your "Still must complete" list.  The "Restricted" list will diminish as you progress through your lessons.</p>  
                    <p><strong><u>You must:</u></strong> View all the lessons and complete the quizzes and obtain a passing score on the final assessment. Our system is designed not to allow "Skimming", so you must view each course or lesson it its entirety.</p>                    
                    <p>If you are taking the Fuel Safety Supervisor 14 CFR 139.321(e)(1) or the Line Fuel Service 14 CFR 139.321(e)(2) course, you must have hands-on fire extinguisher training within 60 days of course completion.</p>                    
                    <p>For Supervisors, the Local Fire Authority will review the information required by the FAA and sign off on the Local Fire Code Verification form provided on the <a href="https://www.safetyprotc.com/index.php/forms-and-brochures"><u>Forms and Brochures Page.</u></a> </p>                    
                    <p>Save this document with your Certificate. This form, along with your Certificate, constitutes your "Certification" in accordance with <strong><u>Advisory Circular 15/5230-4C.</u></strong></p>                    
                    <p>Please be sure that the name on your account is the way you want your Certificate to read.  Please verify our that domain emails @aviationcontinuinged.com can get past your firewalls, spam filters and blacklists, if any. </p>                     
                    <p>If we can be of assistance, please feel free to contact us at 877-322-7139 or email at cs@aviationcontinuinged.com .</p>                         
                    <p>Thanks again for your business, we really do appreciate it and will do all we can to continue to earn it. </p>                       
                    <p>As always, more than ever, for yourself, your co-workers and your families.......</p>                     
                    <p>Please be as safe as you can out there!!</p>                       
                    <p>SafetyPro Customer Service</p>                    
                    <p><strong>Aviation Continuing Education, Inc. / SafetyPro Training Center | Office and Fax 1-877-322-7139</strong></p>
                    <p>           
                    <strong><u>Business and Technical Support Hours</u></strong>
                    <br>
                    Mon-Fri 0800-1800 EST - Phone and Email 
                    <br>
                    Mon-Fri 1800-2300 EST - Email 
                    <br>
                    Sat-Sun 0800-2300 EST - Email                   
                   
                    </p>
                    </div>
             '; 


            $sentmail = email_to_user(

                $user,

                $email_user,

                $subject,

                $messagetext,

                $messageHtml,

                "",

                "",

                true

            );

            $filename = clean_filename("SafetyProReceipt".$checkout->id.".pdf"); 

            $filepath = $filename;      

            $subject2 = "SafetyPro Payment Receipt";

            $messageHtml2 = $messagetext2= "<p><strong>Please find attached payment receipt for your training course.  Please save this document for your future use.</strong></p>

                                                <p><strong>If we can be of assistance, please feel free to contact us by phone at 877-322-7139 or by email at cs@aviationcontinuinged.com.</strong></p>";


            $sentmail=email_to_user($user, $email_user, $subject2, $messagetext2, $messageHtml2, $filepath, $filename, false);



        }



        $instance = $DB->get_record('enrol', array('courseid'=>$courseid, 'enrol'=>'els_paypalcheckout'), '*');



            if(!empty($instance)) {

                $timestart = '';

                $timeend = '';

                $role_id = 5;

                $enrol_manual = enrol_get_plugin('els_paypalcheckout');

                $enrolled = $enrol_manual->enrol_user($instance, $userid, $role_id, $timestart, $timeend);

            }
            return $enrolled;

    }

}