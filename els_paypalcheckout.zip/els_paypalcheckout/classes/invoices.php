<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
* @package enrol_els_paypalpro
* @category enrol
* @copyright  ELS <admin@elearningstack.com>
* @author eLearningstack
*/

namespace enrol_els_paypalcheckout;
use context_system;
use stdClass;

class invoices {

    public static function print_invoice($checkout, $download = false, $createfile = false) {
        global $CFG, $DB;        
        $products = array();       
        $products = $DB->get_record('course', array('id' => $checkout->courseid));      
        $params = new stdClass;
        $params->products = $products;
        $params->currency = get_config('enrol_els_paypalcheckout', 'currency').' ';
        $userto = $DB->get_record('user', array('id'=>$checkout->userid));
        $byurnames = $DB->get_records_sql("SELECT buyer_name FROM {els_paypalcheckout_orders} WHERE txn_id = '$checkout->txn_id' ORDER BY id ASC");
        foreach ($byurnames as $byurn) {
            $byurname=$byurn->buyer_name;
       }
        $dscsss = $DB->get_records_sql('SELECT data FROM  {user_info_data} uids INNER JOIN {user_info_field} uinf ON uids.fieldid = uinf.id WHERE uinf.id = 3  AND uids.userid = "'.$checkout->userid.'"  ');
        foreach ($dscsss as $kvalues) {
             $address=$kvalues->data;
        }
        $dscsss1 = $DB->get_records_sql('SELECT data FROM  {user_info_data} uids INNER JOIN {user_info_field} uinf ON uids.fieldid = uinf.id WHERE uinf.id = 4  AND uids.userid = "'.$checkout->userid.'"  ');
        foreach ($dscsss1 as $kvalues1) {
             $state=$kvalues1->data;
        }
        $params->username = fullname($userto);
        $params->byur_name = $byurname;
        $params->address = $address;
        $params->state = $state;
        $params->country = $userto->country;
        $params->email = $userto->email;
        $params->phone1 = $userto->phone1;
        $params->subtotal = $checkout->option_selection2_x;
        $params->discount = $checkout->discount_code_amount;
        $params->salestax = $checkout->tax;
        $params->balancedue = "0.00";
        if($params->payment_status == 'pending'){
            $params->balancedue = $checkout->option_selection2_x;
        }

        $filename = clean_filename("SafetyProReceipt".$checkout->id.".pdf");

        self::generate_invoice($checkout, $params, $filename, $download, $createfile);
    }

    public static function generate_invoice($checkout, $params, $filename, $download = false, $createfile = false) {
        global $CFG, $DB, $OUTPUT, $PAGE, $SITE;      
        define('PDF_CUSTOM_FONT_PATH', $CFG->dirroot.'/enrol/els_paypalcheckout/fonts/pdf_fonts/');
        require_once("$CFG->libdir/pdflib.php");

        make_cache_directory('tcpdf');

        // No debugging here, sorry.
        $PAGE->set_context(context_system::instance());
        $CFG->debugdisplay = 0;
        @ini_set('display_errors', '0');
        @ini_set('log_errors', '1');

        $pdf = new \PDF('P', 'mm', 'A4', true, 'UTF-8', false);

        $pdf->SetTitle($filename);       
        $pdf->SetProtection(array('modify'));
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $pdf->SetAutoPageBreak(false, 0);
        $pdf->AddPage();
        $pdf->SetTextColor(0, 0, 0);

        $site = get_site();
        $params->sitename = $site->fullname;
        $params->receiptdate = userdate($checkout->timeupdated, get_string('strftimedatefullshort', 'core_langconfig'));
        
        $date = date('M d, Y',$checkout->timeupdated);
//set font to arial, bold, 14pt





//Cell(width , height , text , border , end line , [align] )

//$pdf->Cell(130    ,5,'Company Logo',0,0);

$pdf->Image($CFG->dirroot.'/enrol/els_paypalcheckout/logo.png',5,5,65);



//Cell(width , height , text , border , end line , [align] )

$pdf->Cell(115,5,'',0,0);

$pdf->Cell(10,5,'Transaction Details',0,1,'L');//end of line



//set font to arial, regular, 12pt


//$pdf->Cell(130    ,5,'[Street Address]',0,0);

//$pdf->Cell(59 ,5,'',0,1);//end of line





$pdf->Cell(130  ,5,'',0,0);

$pdf->Cell(25   ,5,'',0,1);

$pdf->Cell(25   ,5,'',0,1);







$pdf->Cell(115,5,'',0,0);

$pdf->Cell(10,5,'Date: '.$date,0,0);

//$pdf->Cell(25,5, $date,0,1);//end of line



$pdf->Cell(115  ,5,'',0,0);

$pdf->Cell(10   ,5,'',0,1,'R');

//$pdf->Cell(190    ,5,$date,0,1,'R');



$pdf->Cell(115,5,'',0,0);

$pdf->Cell(10,5,'Transaction No: '.$checkout->txn_id,0,0);

//$pdf->Cell(34,5,$invoiceid,0,1);//end of line

//$pdf->Line(10,60,100,60);

$pdf->Line(10,40,200,40);

$pdf->Cell(130  ,5,'',0,0);

$pdf->Cell(25   ,5,'',0,1,'R');

//$pdf->Cell(170    ,5,$invoiceid,0,1,'R');//end of line





//make a dummy empty cell as a vertical spacer

$pdf->Cell(189  ,10,'',0,1);//end of line



$pdf->Line(10,80,200,80);


$tabletop = self::generate_products_toptable($checkout, $params);
self::receipt_print_text($pdf, 15, 50, 'L', 'arialunicodems', '', 10, $tabletop, 182);
$pdf->Cell(100,40,'',0,1);//end of line

 $table = self::generate_products_table($checkout, $params);
 self::receipt_print_text($pdf, 15, 90, 'L', 'arialunicodems', '', 10, $table, 182);

$pdf->Cell(100,40,'',0,1);//end of line



$pdf->Line(10,110,200,110);



$pdf->Cell(10   ,5,'',0,0);

$pdf->Cell(177,5,'Aviation Continuing Education,Inc.',0,1,'L');//end of line



$pdf->Cell(10   ,5,'',0,0);

$pdf->Cell(177,5,'DBA SafetyPro Training Center ',0,1,'L');





$pdf->Cell(10   ,5,'',0,0);

$pdf->Cell(177,5,'16490 NE 51ST ST ',0,1,'L');



$pdf->Cell(10   ,5,'',0,0);

$pdf->Cell(177,5,'Williston FL 32696',0,1,'L');





$pdf->Cell(10   ,5,'',0,0);

$pdf->Cell(177,5,'1-877-322-7139',0,1,'L');


$pdf->Cell(10   ,5,'',0,0);

$pdf->Cell(177,5,'cs@aviationcontinuinged.com',0,1,'L');



        // Clean any content of the output buffer
        //ob_end_clean();
        ob_clean();

        if ($download) {
            $pdf->Output($filename, 'D');
            exit;
        }

        if($createfile){
            $filepath = $CFG->dataroot . '/' .$filename;
            $pdf->Output($filepath, 'F');
            return $filepath;
        }

        return $pdf->Output($filename, 'I');
    }

    /**
     * Sends text to output given the following params.
     *
     * @param stdClass $pdf
     * @param int $x horizontal position
     * @param int $y vertical position
     * @param char $align L=left, C=center, R=right
     * @param string $font any available font in font directory
     * @param char $style ''=normal, B=bold, I=italic, U=underline
     * @param int $size font size in points
     * @param string $text the text to print
     * @param int $width horizontal dimension of text block
     */
    public static function receipt_print_text($pdf, $x, $y, $align, $font='freeserif', $style, $size = 10, $text, $width = 0) {
        $pdf->setFont($font, $style, $size);
        $pdf->SetXY($x, $y);
        $pdf->writeHTMLCell($width, 0, '', '', $text, 0, 0, 0, true, $align);
    }


    /**
     * Prints border images from the borders folder in PNG or JPG formats.
     *
     * @param stdClass $pdf
     * @param string $filename
     * @param int $x x position
     * @param int $y y position
     * @param int $w the width
     * @param int $h the height
     */
    public static function receipt_print_image($pdf, $filepath, $x, $y, $w, $h) {
        //$pdf->Image($filepath, $x, $y, $w, $h);
        $pdf->Image($filepath, $x, $y, $w, $h,'','','','','300','',false,false,'','');
    }

    public static function generate_products_table($checkout, $params) { 
        /*if( $checkout->discount_type=='Fixed'){
            $discount_amt=$checkout->discount_code_amount;
        }
        elseif($checkout->discount_type=='Percentage'){
            $discount_amt=$checkout->option_selection2_x * $checkout->discount_code_amount/100;
        } else{    
            $discount_amt=$checkout->discount_code_amount;
  
        }*/       
        $productslist = '';
                
           
                $productslist .= '<tr><td width="50%"><strong>'.$checkout->item_name.'</strong>';               
                $productslist .= '</td><td width="15%" align="left">$ '.format_float($checkout->option_selection2_x, 2, false).' '.$params->currency.'</td>';

                $productslist .= '<td width="15%" align="left">'.(($checkout->discount_code_amount) ? '$ '.format_float($checkout->discount_code_amount, 2, false).' '.$params->currency : '').'</td>';
                $productslist .= '<td width="20%" align="right">';
                $productslist .= ($checkout->option_selection1_x) ? '$ '.format_float($checkout->option_selection1_x, 2, false). ' '.$params->currency : '$ '.format_float($product->item_price, 2, false).$params->currency ;
                $productslist .= '</td></tr>';
           
            $params->productslist = $productslist;   

        $barcolor = '#cccccc';       
        
        return '<table cellpadding="5">
                <thead>
                    <tr style="background-color: '.$barcolor.';">
                        <th width="50%">COURSE</th>
                        <th width="15%" align="left">COURSE PRICE</th>
                        <th width="15%" align="left">'.strtoupper(get_string('discount_amount', 'enrol_els_paypalcheckout')).'</th>
                        <th width="20%" align="right">COURSE AMOUNT</th>
                    </tr>
                </thead>
                <tbody>
                    '.$productslist.'
                </tbody>
                </table>
             
                <table cellpadding="3" width="100%">
                <tbody>
                </tbody>
                    <tr>
                        <td width="70%" align="right">Total</td>
                        <td width="30%" align="right">$ '.number_format((float)$checkout->option_selection1_x, 2, '.', '').' '.$params->currency.'</td>
                    </tr>
                </tbody>
                </table>';
    } 
    public static function generate_products_toptable($checkout, $params) { 

        if ($params->byur_name) {
            $byurname = $params->byur_name;
        }else{
            $byurname = $params->username;
        }       
        
        return '<table cellpadding="2">               
                <tbody>
                    <tr>
                        <td><h3>Bill To</h3></td>
                        <td><h3>Payment Method</h3></td>
                    </tr>
                    <tr>
                        <td>'.$params->username.'</td>
                        <td>PayPal Checkout Payment </td>
                    </tr>
                    <tr>
                        <td>'.$params->address.'</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>'.$params->state.' ('.$params->country .')'.'</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>'.$params->email.'</td>
                        <td> Paid By : ' .$byurname.'</td>
                    </tr>
                </tbody>
                </table>';             
              
    } 
}
