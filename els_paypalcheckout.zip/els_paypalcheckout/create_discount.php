<?php





// This file is part of Moodle - https://moodle.org/





//





// Moodle is free software: you can redistribute it and/or modify





// it under the terms of the GNU General Public License as published by





// the Free Software Foundation, either version 3 of the License, or





// (at your option) any later version.





//





// Moodle is distributed in the hope that it will be useful,





// but WITHOUT ANY WARRANTY; without even the implied warranty of





// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the





// GNU General Public License for more details.





//





// You should have received a copy of the GNU General Public License





// along with Moodle. If not, see <https://www.gnu.org/licenses/>.











/**





* @package enrol_els_paypalcheckout





* @category enrol





* @copyright  ELS <admin@elearningstack.com>





* @author eLearningstack





*/











require_once "../../config.php";





require($CFG->dirroot.'/enrol/els_paypalcheckout/classes/forms/create_discount_form.php');





$PAGE->set_url("/enrol/els_paypalcheckout/create_discount.php");





$PAGE->set_pagelayout("standred");





$PAGE->set_title(get_string('create_coupon', 'enrol_els_paypalcheckout'));





$PAGE->set_heading(get_string('create_coupon', 'enrol_els_paypalcheckout'));





echo $OUTPUT->header();





global $DB;











//Instantiate simplehtml_form











$mform = new create_discount_form();





//Form processing and displaying is done here











if ($mform->is_cancelled()) {





    //Handle form cancel operation, if cancel button is present on form





    redirect("create_discount.php");





} elseif ($fromform = $mform->get_data()) {





    //In this case you process validated data. $mform->get_data() returns data posted in form.





    $description = $fromform->desc["text"];





    $couponcode = $fromform->couponcode;





    $discount_type = $fromform->discount_type;





    $coupon_currency = $fromform->coupon_currency;





    $discount_value = $fromform->discount_value;





    $coupon_type = $fromform->coupon_type;





    $multicour_selection = implode(", ", $fromform->multicour_selection);





    $datefrom = $fromform->datefrom;





    $dateto = $fromform->dateto;





    $termcondition = $fromform->termcondition["text"];





    $rec1->description = $description;





    $rec1->couponcode = $couponcode;





    $rec1->discount_type = $discount_type;





    $rec1->coupon_currency = $coupon_currency;





    $rec1->discount_value = $discount_value;





    $rec1->coupon_type = $coupon_type;





    $rec1->multiple_course = $multicour_selection;





    $rec1->date_from = $datefrom;





    $rec1->date_to = $dateto;





    $rec1->term_condition = $termcondition;





    $rec1->amount = "100";





    $rec1->deleted = "0";








    $check = $DB->get_record("paypalcheckout_discount_code",array('couponcode'=>$rec1->couponcode));





    if(!$check){


        $insert = $DB->insert_record("paypalcheckout_discount_code", $rec1);


    } else {


    	redirect('create_discount.php', get_string('coupon_code_alreadyexist', 'enrol_els_paypalcheckout'), null, \core\output\notification::NOTIFY_WARNING);    


    }





    if ($insert) {





        redirect('create_discount.php', get_string('coupon_code_success', 'enrol_els_paypalcheckout'), null, \core\output\notification::NOTIFY_SUCCESS);     





    }





} else {





    //displays the form





    $mform->display();





}





echo $OUTPUT->footer();