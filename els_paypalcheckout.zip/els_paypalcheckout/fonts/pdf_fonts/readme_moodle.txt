This directory contains just selected set of original tcpdf fonts in order to
keep the standard Moodle distribution lightweight. You may want to manually
download tcpdf package and extract its fonts/ directory into your
$CFG->dataroot/fonts/. In such case, pdflib.php will use this directory.  In
the future, we plan to have fonts downloadable in a same way as languages are.
(TODO MDL-18663).
