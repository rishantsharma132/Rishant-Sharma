<?php







// This file is part of Moodle - https://moodle.org/



//



// Moodle is free software: you can redistribute it and/or modify



// it under the terms of the GNU General Public License as published by



// the Free Software Foundation, either version 3 of the License, or



// (at your option) any later version.



//



// Moodle is distributed in the hope that it will be useful,



// but WITHOUT ANY WARRANTY; without even the implied warranty of



// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the



// GNU General Public License for more details.



//



// You should have received a copy of the GNU General Public License



// along with Moodle. If not, see <https://www.gnu.org/licenses/>.







/**



* @package enrol_els_paypalcheckout



* @category enrol



* @copyright  ELS <admin@elearningstack.com>



* @author eLearningstack



*/







$string["licensekey"] = "License Key";



$string["licensekey_desc"] = "License key of paypal pro plugin"; 



$string["assignrole"] = "Assign role";



$string["businessemail"] = "PayPal business email";



$string["businessemail_desc"] = "The email address of your business PayPal account";



$string["cost"] = "Enrol cost";



$string["costerror"] = "The enrolment cost is not numeric";



$string["costorkey"] = "Please choose one of the following methods of enrolment.";



$string["currency"] = "Currency";



$string["defaultrole"] = "Default role assignment";



$string["defaultrole_desc"] = "Select role which should be assigned to users during PayPal enrolments";



$string["enrolenddate"] = "End date";



$string["enrolenddate_help"] = "If enabled, users can be enrolled until this date only.";



$string["enrolenddaterror"] = "Enrolment end date cannot be earlier than start date";



$string["enrolperiod"] = "Enrolment duration";



$string["enrolperiod_desc"] = "Default length of time that the enrolment is valid. If set to zero, the enrolment duration will be unlimited by default.";



$string["enrolperiod_help"] = "Length of time that the enrolment is valid, starting with the moment the user is enrolled. If disabled, the enrolment duration will be unlimited.";



$string["enrolstartdate"] = "Start date";



$string["enrolstartdate_help"] = "If enabled, users can be enrolled from this date onward only.";



$string["errdisabled"] = "The PayPal enrolment plugin is disabled and does not handle payment notifications.";



$string["erripninvalid"] = "Instant payment notification has not been verified by PayPal.";



$string["errpaypalconnect"] = 'Could not connect to {$a->url} to verify the instant payment notification: {$a->result}';



$string["expiredaction"] = "Enrolment expiry action";



$string["expiredaction_help"] = "Select action to carry out when user enrolment expires. Please note that some user data and settings are purged from course during course unenrolment.";



$string["mailadmins"] = "Notify admin";



$string["mailstudents"] = "Notify students";



$string["mailteachers"] = "Notify teachers";



$string["messageprovider:paypal_enrolment"] = "PayPal enrolment messages";



$string["nocost"] = "There is no cost associated with enrolling in this course!";



$string["paypal:config"] = "Configure PayPal enrol instances";



$string["paypal:manage"] = "Manage enrolled users";



$string["paypal:unenrol"] = "Unenrol users from course";



$string["paypal:unenrolself"] = "Unenrol self from the course";



$string["paypalaccepted"] = "PayPal payments accepted";



$string["pluginname"] = "ELS PayPal Checkout";
$string["managecoupon"] = "Manage Coupon";
$string["reportpay"] = "Report";

$string["paymentinstant"] = "For purchases of 2 or more students, call 877-322-7139 or email cs@safetyprotc.com";



$string["pluginname_desc"] = "The PayPal module allows you to set up paid courses.  If the cost for any course is zero, then students are not asked to pay for entry.  There is a site-wide cost that you set here as a default for the whole site and then a course setting that you can set for each course individually. The course cost overrides the site cost.";



$string["manage_coupon"] = "Manage Coupon";



$string["apiusername"] = "User name";



$string["apipassword"] = "Password";



$string["apisignature"] = "Signature";



$string["checksandbox"] = "Sandbox";



$string["apiusername_desc"] = "Paypal Pro API username";



$string["apipassword_desc"] = "Paypal Pro API password";



$string["apisignature_desc"] = "Paypal Pro API signature";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout"] = "Information about the PayPal transactions for PayPal enrolments.";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:business"] = "Email address or PayPal account ID of the payment recipient (that is, the merchant).";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:courseid"] = "The ID of the course that is sold.";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:instanceid"] = "The ID of the enrolment instance in the course.";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:item_name"] = "The full name of the course that its enrolment has been sold.";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:memo"] = "A note that was entered by the buyer in PayPal website payments note field.";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:option_selection1_x"] = "Full name of the buyer.";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:parent_txn_id"] = "In the case of a refund, reversal, or canceled reversal, this would be the transaction ID of the original transaction.";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:payment_status"] = "The status of the payment.";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:payment_type"



] ="Holds whether the payment was funded with an eCheck (echeck), or was funded with PayPal balance, credit card, or instant transfer (instant).";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:pending_reason"] = "The reason why payment status is pending (if that is).";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:reason_code"] = "The reason why payment status is Reversed, Refunded, Canceled_Reversal, or Denied (if the status is one of them).";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:receiver_email"] = "Primary email address of the payment recipient (that is, the merchant).";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:receiver_id"] = "Unique PayPal account ID of the payment recipient (i.e., the merchant).";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:tax"] = "Amount of tax charged on payment.";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:timeupdated"] = "The time of Moodle being notified by PayPal about the payment.";



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:txn_id"] = 'The merchant\'s original transaction identification number for the payment from the buyer, against which the case was registered';



$string["privacy:metadata:enrol_els_paypalcheckout:enrol_els_paypalcheckout:userid"] =



    "The ID of the user who bought the course enrolment.";



$string["privacy:metadata:enrol_els_paypalcheckout:paypal_com"] = "The PayPal enrolment plugin transmits user data from Moodle to the PayPal website.";



$string["privacy:metadata:enrol_els_paypalcheckout:paypal_com:address"] = "Address of the user who is buying the course.";



$string["privacy:metadata:enrol_els_paypalcheckout:paypal_com:city"] = "City of the user who is buying the course.";



$string["privacy:metadata:enrol_els_paypalcheckout:paypal_com:country"] = "Country of the user who is buying the course.";



$string["privacy:metadata:enrol_els_paypalcheckout:paypal_com:custom"] = "A hyphen-separated string that contains ID of the user (the buyer), ID of the course, ID of the enrolment instance.";



$string["privacy:metadata:enrol_els_paypalcheckout:paypal_com:email"] = "Email address of the user who is buying the course.";



$string["privacy:metadata:enrol_els_paypalcheckout:paypal_com:first_name"] = "First name of the user who is buying the course.";



$string["privacy:metadata:enrol_els_paypalcheckout:paypal_com:last_name"] = "Last name of the user who is buying the course.";



$string["privacy:metadata:enrol_els_paypalcheckout:paypal_com:os0"] = "Full name of the buyer.";



$string["processexpirationstask"] = "PayPal enrolment send expiry notifications task";



$string["sendpaymentbutton"] = "Send payment via PayPal";



$string["status"] = "Allow PayPal enrolments";



$string["status_desc"] = "Allow users to use PayPal to enrol into a course by default.";



$string["transactions"] = "PayPal transactions";



$string["unenrolselfconfirm"] = 'Do you really want to unenrol yourself from course "{$a}"?';



$string["username"] = "Firstname/Lastname";



$string["userid"] = "Userid";



$string["course"] = "Course";



$string["txn_id"] = "Transaction no.";



$string["discount_code"] = "Discount code";



$string["discount_amount"] = "Discount amount";



$string["actual_discount"] = "Actual amount";



$string["net_amount_paid"] = "Net amount paid";



$string["discount_type"] = "Discount type";



$string["trx_date"] = "Transaction date";



$string["invoice"] = "Invoice";



$string["fromtrx_date"] = "From Transaction date";



$string["totrx_date"] = "To Transaction date";



$string["fromtrxdate"] = " Valid From ";



$string["totrxdate"] = " Valid To";



$string["api_key"] = "API Key";



$string["secret_key"] = "Secret Key";



$string["havediscode"] = "Do you have a discount code?";



$string["course_price"] = "Course Price: ";



$string["courseheading"] = "Course: ";



$string["payable_amt"] = "Payable amount: ";



$string["card_no"] = "Card number";



$string["exp_month"] = "Expiry month";



$string["exp_year"] = "Expiry year";



$string["cvv"] = "CVV";



$string["name_oncard"] = "Name on card";



$string["generate"] = "Generate";



$string["download"] = "Download";











//invoice



$string["transaction_detail"] = "Transaction Details";



$string["date"] = "Date: ";



$string["trans_no"] = "Transaction No: ";



$string["bill_to"] = "Bill To";



$string["payment_method"] = "Payment Method";



$string["course_enrolled"] = "Course Enrolled";



$string["unit_price"] = "Unit Price";



$string["discount_amt"] = "Discount amount";



$string["sub_tot"] = "Sub Total";



$string["total"] = "Total";



$string["total"] = "Total";



$string["course_prc"] = "Course Price";



$string["course_amt"] = "Amount";



$string["invoice"] = "INVOICE";



$string["billto"] = "BILL TO";



$string["invoicenumber"] = "Invoice #";



$string["invoicedate"] = "DATE";



$string["subtotal"] = "SUB-TOTAL";



$string["discount"] = "DISCOUNT";



$string["balancedue"] = "BALANCE DUE";







//enrol els paypalpro



$string["emailbody"] = "<p>Hello {$a->username}</p><br><p>You are Successfully  enrolled into {$a->coursename} Course";



$string["payment_success"] = "Payment Successfull";



$string["enrol_success"] = "You are successfully enrolled into ";



$string["discountcode_expire"] = "Discount code Expired";



$string["discountcode_notvalid"] = "Discount code not valid";



$string["discountcode_applied"] = "Discount code applied: ";



$string["enter_discountcode"] = "Please enter discount code";



$string["discount_price"] = "Discounted Price: ";







$string["payment_receipt_body"] = "Please find attached payment receipt for your training course.  Please save this document for your future use.<br>

                                       If we can be of assistance, please feel free to contact us by phone at 877-322-7139 or by email at cs@aviationcontinuinged.com.







";



$string["payment_receipt"] = "SafetyPro Payment Receipt";







 



//Coupon code



$string["create_coupon"] = "Create Coupon";



$string['coupon_code'] = 'Coupon code';



$string["coupon_code_success"] = "Coupon Code Created Sucessfully!";



$string["coupon_code_alreadyexist"] = "Coupon Code is already exist. Please enter different Coupon Code";



$string["discount_type"] = "Discount type";



$string["coupon_crncy"] = "Coupon Currency";



$string["dscnt_value"] = "Discount value";



$string["coupon_typ"] = "Coupon Type";



$string["select_multicourse"] = "Multiple Course Selection";



$string["date_validfrom"] = "Date valid From";



$string["date_validto"] = "Date valid To";



$string["terms_conditions"] = "Terms & Conditions";



$string['field_required'] = 'This field is required';



$string['course_id'] = 'Course ids';



$string['delete'] = 'Delete';



$string['date_validation'] = ' - Date valid To must be greater than From Date valid From';



$string['selcourse_validation'] = ' - This field is required



';







$string["report"] = "Report";



$string["enter_numericvalue"] = "Please enter numeric value";











// Manage coupons



$string['coupon_type'] = 'Type';



$string["validfrom"] = "Valid From";



$string["validto"] = "Valid To";







// License key



$string["activate"] = "Activate";



$string["no_record"] = "No Record Found";



$string["description"] = "Description";



$string["licenseactivation"] = "License Activation";



$string["license_key"] = "License Key";



$string["enter_license_key"] = "Enter License Key";



$string["active_license"] = "Activate License";



$string["backto_setting"] = "Go to Setting ";



$string["active_license_desc"] = "For Activate License, Please click on Activate Button below";



$string["keyalready_activated"] = "License Key Activated";



$string["key_invalid"] = "You entered invalid license key. Please enter correct key.";



$string["blank_keymsg"] = "Please enter a License Key.";



$string["enter_code"] = "Enter Discount Code";