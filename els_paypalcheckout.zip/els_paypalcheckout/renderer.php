<?php


// This file is part of Moodle - https://moodle.org/

//

// Moodle is free software: you can redistribute it and/or modify

// it under the terms of the GNU General Public License as published by

// the Free Software Foundation, either version 3 of the License, or

// (at your option) any later version.

//

// Moodle is distributed in the hope that it will be useful,

// but WITHOUT ANY WARRANTY; without even the implied warranty of

// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the

// GNU General Public License for more details.

//

// You should have received a copy of the GNU General Public License

// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**

* @package enrol_els_paypalcheckout

* @category enrol

* @copyright  ELS <admin@elearningstack.com>

* @author eLearningstack

*/


require_once "../../config.php";

require($CFG->dirroot.'/enrol/els_paypalcheckout/classes/forms/filter_form.php');

require($CFG->dirroot.'/enrol/els_paypalcheckout/classes/forms/manage_filterform.php');


require_login();


class enrol_els_paypalcheckout_renderer extends plugin_renderer_base {



    public function report_table() {



        $id = optional_param("id", 0, PARAM_TEXT);

        global $CFG, $DB, $OUTPUT, $USER;

        $baseurl = new moodle_url("report.php");


        $page = optional_param("page", 0, PARAM_INT); 

        $limit = 10;


        // Set up the filter form.


        $mform = new filter_form();


        $usernamefilter = "";


        //$discountfilter = "";

        $trxfilter = "";

        $trxfilterr = "";

        if ($formdata = $mform->get_data()) {

            $usernamefilter = $formdata->username;

            //$discountfilter = $formdata->discount_code;

            $formfilter = $formdata->startfrom;
            $endfilter = $formdata->endto;

        }

        $mform->display();

        $table = new html_table();
      
        $table->attributes["paypal_report"] = "enrol_els_paypalcheckout";
        $table->head = [
            get_string("username", "enrol_els_paypalcheckout"),

            get_string("course", "enrol_els_paypalcheckout"),

            get_string("txn_id", "enrol_els_paypalcheckout"),

            get_string("net_amount_paid", "enrol_els_paypalcheckout"),

            get_string("trx_date", "enrol_els_paypalcheckout"),

            get_string("invoice", "enrol_els_paypalcheckout"),

        ];


        $where = "";

        if ($usernamefilter) {

            $where .= " AND (u.username LIKE '$usernamefilter%' OR u.firstname LIKE '$usernamefilter%' OR u.lastname LIKE '$usernamefilter%')";
        }

       /* if ($discountfilter) {

            $where .= " AND eepl.discount_code LIKE '$discountfilter%'";


        }*/



        if ($formfilter) {

            $where .= " AND eepl.timeupdated > $formfilter";


        }



        if ($endfilter) {


            $where .= " AND eepl.timeupdated < $endfilter";

        }


        $action = !is_siteadmin() ? $USER->id : "u.id";

        $userlist = self::getuserlist($action, $where, $page);

        $totalcount = count(self::getuserlist($action, $where, $page, true));

        if(!$userlist){

            echo $message =  get_string('no_record', 'enrol_els_paypalcheckout');           

        }
        else{

        foreach ($userlist as $regi) {

            if ($regi->discount_code) {

                $dd = $regi->discount_type;

                if ($dd == "Fixed") {
                    $c = $regi->discount_code_amount;

                } elseif ($dd == "Percentage") {

                    $c = ($regi->option_selection2_x * $regi->discount_code_amount) / 100;

                } else {
                    $c = $regi->discount_code_amount;
                }

            } else {

                $dd = $regi->discount_type = "";

                $c = $regi->discount_code_amount = "";

            }

            $total_discount = $regi->option_selection2_x - $c;


            if ($total_discount < 0) {

                $total_discount = 0;

            } else {

               $total_discount;
            }


            $table->data[] = [


                "username" => $regi->firstname . " " . $regi->lastname,


                "course" => $regi->item_name,


                "txn_id" => $regi->txn_id,

                "total" => ($regi->option_selection1_x) ? format_float($regi->option_selection1_x, 2, false) : format_float($regi->option_selection2_x, 2, false),


               /* "discount" => $regi->discount_code,

                "discount_type" => $dd,

                "discount_amount" => $c,

               "amount_paid" => $total_discount,*/


                "date" => date("F d, Y", $regi->timeupdated),


                "invoice" =>   '<a href="viewinvoice.php?id=' .$regi->id .

                   '&action=generate" target="_blank">'.get_string("generate", "enrol_els_paypalcheckout").'</a>'.' -'.'<a href="viewinvoice.php?id=' .$regi->id .

                   '&action=download" target="_blank">'.get_string("download", "enrol_els_paypalcheckout").'</a>',


            ];

        }


        echo "<div class='tableheader' style='overflow:auto'>";

        echo html_writer::table($table);


        echo $OUTPUT->paging_bar($totalcount, $page, $limit, $baseurl);


        echo "</div>";

        }

    }


    public function getuserlist($action, $where, $page, $count=false) {

        global $CFG, $DB;

        $limit = 10;

        $perpage = $page * $limit;

        if($count){

           $query = "SELECT eepl.id as id, eepl.discount_code, eepl.discount_type, eepl.discount_code_amount, eepl.option_selection2_x,eepl.option_selection1_x, eepl.item_name, eepl.txn_id, eepl.timeupdated, u.firstname, u.lastname FROM {enrol_els_paypalcheckout} eepl INNER JOIN {user} u ON eepl.userid=u.id  WHERE u.deleted=0 AND eepl.userid=$action $where ORDER BY id DESC"; 

           return $DB->get_records_sql($query);

        }

         $query = "SELECT eepl.id as id, eepl.discount_code, eepl.discount_type, eepl.discount_code_amount, eepl.option_selection2_x,eepl.option_selection1_x, eepl.item_name, eepl.txn_id, eepl.timeupdated, u.firstname, u.lastname FROM {enrol_els_paypalcheckout} eepl INNER JOIN {user} u ON eepl.userid=u.id  WHERE u.deleted=0 AND eepl.userid=$action $where ORDER BY id DESC LIMIT $perpage, $limit";

        $userlists = $DB->get_records_sql($query);

        return $userlists;

    }



    public function coupon_table() {


        global $CFG, $DB, $OUTPUT;


      /*$pagerec = $DB->get_records("paypalcheckout_discount_code", array('deleted' => 1));


        $totalcount = count($pagerec);*/


        $baseurl = new moodle_url("manage_coupon.php");


        $page = optional_param("page", 0, PARAM_INT);

        $limit = 10;      

        // Set up the filter form.


        $mform = new managefilter_form();


        $discount_filter = "";


        $trxfilter = "";


        if ($formdata = $mform->get_data()) {


            $discount_filter = $formdata->discount_code;


            $trx_filter = $formdata->datefrom;



            $trx_filterr = $formdata->dateto;


        }


        $mform->display();


        $table = new html_table();

        $table->attributes["paypal_report"] = "enrol_els_paypalcheckout";


        $table->head = [


            "Coupon Code",

            "Type",

            "Course ids",

            "Valid From",

            "Valid To",

            "Disable",

        ];

        $table->head = array(get_string('coupon_code', 'enrol_els_paypalcheckout'), get_string('coupon_type', 'enrol_els_paypalcheckout'), get_string('course_id', 'enrol_els_paypalcheckout'), get_string('validfrom', 'enrol_els_paypalcheckout'), get_string('validfrom', 'enrol_els_paypalcheckout'), get_string('delete', 'enrol_els_paypalcheckout'));


        $where = " WHERE id > 0";


        if ($discount_filter != "") {
            $where .= " AND couponcode LIKE '%$discount_filter%'";
        }


        if ($trx_filter != "") {
            $where .= " AND date_from >= '$trx_filter'";
        }

        if ($trx_filterr != "") {

            $where .= " AND date_to <= '$trx_filterr'";
        }


        $couponlists = self::getdiscountcode($where, $page);

        $totalcount = count(self::getdiscountcode($where, $page, true));

        if(!$couponlists){

            echo $message =  get_string('no_record', 'enrol_els_paypalcheckout');           

        } else {


            foreach ($couponlists as $couponlist) {


            $table->data[] = [

                "couponcode" => $couponlist->couponcode,

                "discount_type" => $couponlist->discount_type,

                "courseid" => $couponlist->multiple_course,

                "start" => date("h:i A -d M, Y", $couponlist->date_from),

                "end" => date("h:i A -d M, Y", $couponlist->date_to),

                "delete" => '<a href="' . $CFG->wwwroot . "/enrol/els_paypalcheckout/delete_discount.php?row_id=" . $couponlist->id .'">'.get_string('delete', 'enrol_els_paypalcheckout').'</a>',

            ];


        }      



        echo "<div class='tableheader' style='overflow:auto'>";

        echo html_writer::table($table);

        echo $OUTPUT->paging_bar($totalcount, $page, $limit, $baseurl);

        echo "</div>";      

        }      


    }


    public function getdiscountcode($where, $page, $count=false) {

        global $DB;
        $limit = 10;
        $perpage = $page * $limit;

        if ($count) {

            $query = "SELECT id, couponcode, discount_type, multiple_course, date_from, date_to FROM {paypalcheckout_discount_code} $where";

            return $DB->get_records_sql($query);

        }    

        $query = "SELECT id, couponcode, discount_type, multiple_course, date_from, date_to FROM {paypalcheckout_discount_code} $where LIMIT $perpage, $limit";
            return $DB->get_records_sql($query);

    }



// two table join in report----------------------------------------------------------------------------------------------------end

public function two_table_report() {



    $id = optional_param("id", 0, PARAM_TEXT);

    global $CFG, $DB, $OUTPUT, $USER;


    // Set up the filter form.


    $mform = new filter_form();


    $usernamefilter = "";


    //$discountfilter = "";

    $trxfilter = "";

    $trxfilterr = "";

    if ($formdata = $mform->get_data()) {

        $usernamefilter = $formdata->username;

        //$discountfilter = $formdata->discount_code;

        $formfilter = $formdata->startfrom;
        $endfilter = $formdata->endto;

    }

    $mform->display();

    $table = new html_table();
  
    $table->attributes["paypal_report"] = "enrol_els_paypalcheckout";
    $table->head = [
        get_string("username", "enrol_els_paypalcheckout"),

        get_string("course", "enrol_els_paypalcheckout"),

        get_string("txn_id", "enrol_els_paypalcheckout"),

        get_string("net_amount_paid", "enrol_els_paypalcheckout"),

        get_string("trx_date", "enrol_els_paypalcheckout"),

        get_string("invoice", "enrol_els_paypalcheckout"),

    ];


    $where = "";

    if ($usernamefilter) {

        $where .= " AND (u.username LIKE '$usernamefilter%' OR u.firstname LIKE '$usernamefilter%' OR u.lastname LIKE '$usernamefilter%')";
    }

   /* if ($discountfilter) {

        $where .= " AND eepl.discount_code LIKE '$discountfilter%'";


    }*/



    if ($formfilter) {

        $where .= " AND eepl.timeupdated > $formfilter";


    }



    if ($endfilter) {


        $where .= " AND eepl.timeupdated < $endfilter";

    }


    $action = !is_siteadmin() ? $USER->id : "u.id";

    $userlist = self::getusertwolist($action, $where);

    //echo $totalcount = count(self::getusertwolist($action, $where, true));

    if(!$userlist){

        echo $message =  get_string('no_record', 'enrol_els_paypalcheckout');           

    }
    else{

    foreach ($userlist as $regi) {

        if ($regi->discount_code) {

            $dd = $regi->discount_type;

            if ($dd == "Fixed") {
                $c = $regi->discount_code_amount;

            } elseif ($dd == "Percentage") {

                $c = ($regi->option_selection2_x * $regi->discount_code_amount) / 100;

            } else {
                $c = $regi->discount_code_amount;
            }

        } else {

            $dd = $regi->discount_type = "";

            $c = $regi->discount_code_amount = "";

        }

        $total_discount = $regi->option_selection2_x - $c;


        if ($total_discount < 0) {

            $total_discount = 0;

        } else {

           $total_discount;
        }

        if($regi->timeupdated > 1668529392){
            $dataurl =    '<a href="'.$CFG->wwwroot.'/enrol/els_paypalcheckout/viewinvoice.php?id=' .$regi->id .

            '&action=generate" target="_blank">'.get_string("generate", "enrol_els_paypalcheckout").'</a>'.' -'.'<a href="'.$CFG->wwwroot.'/enrol/els_paypalcheckout/viewinvoice.php?id=' .$regi->id .

            '&action=download" target="_blank">'.get_string("download", "enrol_els_paypalcheckout").'</a>';

        }else {

        
        $dataurl =  '<a href="'.$CFG->wwwroot.'/enrol/els_paypalpro/viewinvoice.php?id=' .$regi->id .

           '&action=generate" target="_blank">'.get_string("generate", "enrol_els_paypalcheckout").'</a>'.' -'.'<a href="'.$CFG->wwwroot.'/enrol/els_paypalpro/viewinvoice.php?id=' .$regi->id .

           '&action=download" target="_blank">'.get_string("download", "enrol_els_paypalcheckout").'</a>';

        }



        $table->data[] = [


            "username" => $regi->firstname . " " . $regi->lastname,


            "course" => $regi->item_name,


            "txn_id" => $regi->txn_id,

            "total" => ($regi->option_selection1_x) ? format_float($regi->option_selection1_x, 2, false) : format_float($regi->option_selection2_x, 2, false),


           /* "discount" => $regi->discount_code,

            "discount_type" => $dd,

            "discount_amount" => $c,

           "amount_paid" => $total_discount,*/


            "date" => date("F d, Y", $regi->timeupdated),


            "invoice" => $dataurl


        ];

    }


    echo "<div class='tableheader' style='overflow:auto'>";

    echo html_writer::table($table);


    //echo $OUTPUT->paging_bar($totalcount, $page, $limit, $baseurl);


    echo "</div>";

    }

}

public function getusertwolist($action, $where) {

    global $CFG, $DB;

   // $limit = 10;

   // $perpage = $page * $limit;


    $query = "SELECT eepl.id as id, eepl.discount_code, eepl.discount_type, eepl.discount_code_amount, eepl.option_selection2_x,eepl.option_selection1_x, eepl.item_name, eepl.txn_id, eepl.timeupdated, u.firstname, u.lastname FROM {enrol_els_paypalcheckout} eepl INNER JOIN {user} u ON eepl.userid=u.id  WHERE u.deleted=0 AND eepl.userid=$action $where ORDER BY id DESC ";

    $userlists = $DB->get_records_sql($query);
    $userlists1 = $DB->get_records_sql("SELECT eepl.id as id ,u.*,eepl.*  FROM mdl_enrol_els_paypalpro eepl 
    INNER JOIN mdl_user u ON u.id=eepl.userid WHERE u.deleted=0 AND  eepl.userid = $action $where ORDER BY eepl.id DESC");           

  

    $twotable = array_merge($userlists,$userlists1);

    return $twotable;

}






}