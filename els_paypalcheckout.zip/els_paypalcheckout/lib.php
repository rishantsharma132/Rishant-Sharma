<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
* @package enrol_els_paypalcheckout
* @category enrol
* @copyright  ELS <admin@elearningstack.com>
* @author eLearningstack
*/

defined('MOODLE_INTERNAL') || die();
/**
 * Paypal enrolment plugin implementation.
 * @author  Eugene Venter - based on code by Martin Dougiamas and others
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

class enrol_els_paypalcheckout_plugin extends enrol_plugin {
    public function get_currencies() {

        // See https://www.paypal.com/cgi-bin/webscr?cmd=p/sell/mc/mc_intro-outside,
        // 3-character ISO-4217: https://cms.paypal.com/us/cgi-bin/?cmd=_render-content&content_ID=developer/e_howto_api_currency_codes

        $codes = array('AUD', 'BRL', 'CAD', 'CHF', 'CZK', 'DKK', 'EUR', 'GBP', 'HKD', 'HUF', 'ILS', 'INR', 'JPY', 'MXN', 'MYR', 'NOK', 'NZD', 'PHP', 'PLN', 'RUB', 'SEK', 'SGD', 'THB', 'TRY', 'TWD', 'USD');
        $currencies = array();
        foreach ($codes as $c) {
            $currencies[$c] = new lang_string($c, 'core_currencies');
        }
        return $currencies;
    }

     public function get_name() {

        // second word in class is always enrol name, sorry, no fancy plugin names with _

        $words = explode('_', get_class($this));
        return $words[1]."_".$words[2];
    }

    /**
     * Returns optional enrolment information icons.
     * This is used in course list for quick overview of enrolment options.
     * We are not using single instance parameter because sometimes
     * we might want to prevent icon repetition when multiple instances
     * of one type exist. One instance may also produce several icons.
     * @param array $instances all enrol instances of this type in one course
     * @return array of pix_icon
     */

    public function get_info_icons(array $instances) {
        $found = false;
        foreach ($instances as $instance) {
            if ($instance->enrolstartdate != 0 && $instance->enrolstartdate > time()) {
                continue;
            }
            if ($instance->enrolenddate != 0 && $instance->enrolenddate < time()) {
                continue;
            }
            $found = true;
            break;
        }
        if ($found) {
            return array(new pix_icon('icon', get_string('pluginname', 'enrol_els_paypalcheckout'), 'enrol_els_paypalcheckout'));
        }
        return array();
    }

    public function roles_protected() {

        // users with role assign cap may tweak the roles later

        return false;
    }

    public function allow_unenrol(stdClass $instance) {

        // users with unenrol cap may unenrol other users manually - requires enrol/paypal:unenrol

        return true;
    }

    public function allow_manage(stdClass $instance) {

        // users with manage cap may tweak period and status - requires enrol/paypal:manage

        return true;
    }

    public function show_enrolme_link(stdClass $instance) {
        return ($instance->status == ENROL_INSTANCE_ENABLED);
    }

    /**
     * Returns true if the user can add a new instance in this course.
     * @param int $courseid
     * @return boolean
     */

    public function can_add_instance($courseid) {
        $context = context_course::instance($courseid, MUST_EXIST);
        if (!has_capability('moodle/course:enrolconfig', $context) or !has_capability('enrol/paypal:config', $context)) {
            return false;
        }

        // multiple instances supported - different cost for different roles

        return true;
    }

    /**
     * We are a good plugin and don't invent our own UI/validation code path.
     * @return boolean
     */

    public function use_standard_editing_ui() {
        return true;
    }

    /**
     * Add new instance of enrol plugin.
     * @param object $course
     * @param array $fields instance fields
     * @return int id of new instance, null if can not be created
     */

    public function add_instance($course, array $fields = null) {
        if ($fields && !empty($fields['cost'])) {
            $fields['cost'] = unformat_float($fields['cost']);
        }
        return parent::add_instance($course, $fields);
    }

    /**
     * Update instance of enrol plugin.
     * @param stdClass $instance
     * @param stdClass $data modified instance fields
     * @return boolean
     */




    public function update_instance($instance, $data) {
        if ($data) {
            $data->cost = unformat_float($data->cost);
        }
        return parent::update_instance($instance, $data);
    }

    /**
     * Creates course enrol form, checks if form submitted
     * and enrols user if necessary. It can also redirect.
     * @param stdClass $instance
     * @return string html text, usually a form in a text box
     */

    function enrol_page_hook(stdClass $instance) {
        global $CFG, $USER, $OUTPUT, $PAGE, $DB;
        ob_start();
        if ($DB->record_exists('user_enrolments', array('userid'=>$USER->id, 'enrolid'=>$instance->id))) {
            return ob_get_clean();
        }
        if ($instance->enrolstartdate != 0 && $instance->enrolstartdate > time()) {
            return ob_get_clean();
        }
        if ($instance->enrolenddate != 0 && $instance->enrolenddate < time()) {
            return ob_get_clean();
        }
        $course = $DB->get_record('course', array('id'=>$instance->courseid));
        $context = context_course::instance($course->id);
        $shortname = format_string($course->shortname, true, array('context' => $context));
        $strloginto = get_string("loginto", "", $shortname);
        $strcourses = get_string("courses");
        if ($users = get_users_by_capability($context, 'moodle/course:update', 'u.*', 'u.id ASC', '', '', '', '', false, true)) {
            $users = sort_by_roleassignment_authority($users, $context);
            $teacher = array_shift($users);
        } else {
            $teacher = false;
        }
        if ( (float) $instance->cost <= 0 ) {
            $cost = (float) $this->get_config('cost');
        } else {
            $cost = (float) $instance->cost;
        }
        if (abs($cost) < 0.01) { // no cost, other enrolment methods (instances) should be used
            echo '<p>'.get_string('nocost', 'enrol_els_paypalcheckout').'</p>';
        } else {

            // Calculate localised and "." cost, make sure we send PayPal the same value,
            // please note PayPal expects amount with 2 decimal places and "." separator.
            $localisedcost = format_float($cost, 2, true);
            $cost = format_float($cost, 2, false);
            if (isguestuser()) { // force login only for guest user, not real users with guest role
                $wwwroot = $CFG->wwwroot;
                echo '<div class="mdl-align"><p>'.get_string('paymentrequired').'</p>';
                echo '<p><b>'.get_string('cost').": $instance->currency $localisedcost".'</b></p>';
                echo '<p><a href="'.$wwwroot.'/login/">'.get_string('loginsite').'</a></p>';
                echo '</div>';
            } else {

                //Sanitise some fields before building the PayPal form

                $coursefullname  = format_string($course->fullname, true, array('context'=>$context));
                $courseshortname = $shortname;
                $userfullname    = fullname($USER);
                $userfirstname   = $USER->firstname;
                $userlastname    = $USER->lastname;
                $useraddress     = $USER->address;
                $usercity        = $USER->city;
                $instancename    = $this->get_instance_name($instance);
                include($CFG->dirroot.'/enrol/els_paypalcheckout/enrol.php');
            }
        }
        return $OUTPUT->box(ob_get_clean());
    }

    /**
     * Restore instance and map settings.
     * @param restore_enrolments_structure_step $step
     * @param stdClass $data
     * @param stdClass $course
     * @param int $oldid
     */

    public function restore_instance(restore_enrolments_structure_step $step, stdClass $data, $course, $oldid) {
        global $DB;
        if ($step->get_task()->get_target() == backup::TARGET_NEW_COURSE) {
            $merge = false;
        } else {
            $merge = array(
                'courseid'   => $data->courseid,
                'enrol'      => $this->get_name(),
                'roleid'     => $data->roleid,
                'cost'       => $data->cost,
                'currency'   => $data->currency,
            );
        }
        if ($merge and $instances = $DB->get_records('enrol', $merge, 'id')) {
            $instance = reset($instances);
            $instanceid = $instance->id;
        } else {
            $instanceid = $this->add_instance($course, (array)$data);
        }
        $step->set_mapping('enrol', $oldid, $instanceid);
    }

    /**
     * Restore user enrolment.
     * @param restore_enrolments_structure_step $step
     * @param stdClass $data
     * @param stdClass $instance
     * @param int $oldinstancestatus
     * @param int $userid
     */

    public function restore_user_enrolment(restore_enrolments_structure_step $step, $data, $instance, $userid, $oldinstancestatus) {
        $this->enrol_user($instance, $userid, null, $data->timestart, $data->timeend, $data->status);
    }

    /**
     * Return an array of valid options for the status.
     *
     * @return array
     */

    protected function get_status_options() {
        $options = array(ENROL_INSTANCE_ENABLED  => get_string('yes'),
                         ENROL_INSTANCE_DISABLED => get_string('no'));
        return $options;
    }

    /**
     * Return an array of valid options for the roleid.
     *
     * @param stdClass $instance
     * @param context $context
     * @return array
     */

    protected function get_roleid_options($instance, $context) {
        if ($instance->id) {
            $roles = get_default_enrol_roles($context, $instance->roleid);
        } else {
            $roles = get_default_enrol_roles($context, $this->get_config('roleid'));
        }
        return $roles;
    }

    /**
     * Add elements to the edit instance form.
     *
     * @param stdClass $instance
     * @param MoodleQuickForm $mform
     * @param context $context
     * @return bool
     */

    public function edit_instance_form($instance, MoodleQuickForm $mform, $context) {
        global $CFG;
        $coupon_url=$CFG->wwwroot."/enrol/els_paypalcheckout/manage_coupon.php";
        $cc_url=$CFG->wwwroot."/enrol/els_paypalcheckout/create_discount.php";
        $report_url=$CFG->wwwroot."/enrol/els_paypalcheckout/report.php";
        $mform->addElement('html', '<h4><a  href="'.$coupon_url.'">Manage Coupons</a>&nbsp;&nbsp;&nbsp; <a  href="'.$cc_url.'">Create Coupon</a>&nbsp;&nbsp;&nbsp; <a  href="'.$report_url.'">Report</a></h4>'); 
        $mform->addElement('text', 'name', get_string('custominstancename', 'enrol'));
        $mform->setType('name', PARAM_TEXT);
        $options = $this->get_status_options();
        $mform->addElement('select', 'status', get_string('status', 'enrol_els_paypalcheckout'), $options);
        $mform->setDefault('status', $this->get_config('status'));
        $mform->addElement('text', 'cost', get_string('cost', 'enrol_els_paypalcheckout'), array('size' => 4));
        $mform->setType('cost', PARAM_RAW);
        $mform->setDefault('cost', format_float($this->get_config('cost'), 2, true));
        $paypalcurrencies = $this->get_currencies();
        $mform->addElement('select', 'currency', get_string('currency', 'enrol_els_paypalcheckout'), $paypalcurrencies);
        $mform->setDefault('currency', $this->get_config('currency'));
        $roles = $this->get_roleid_options($instance, $context);
        $mform->addElement('select', 'roleid', get_string('assignrole', 'enrol_els_paypalcheckout'), $roles);
        $mform->setDefault('roleid', $this->get_config('roleid'));
        $options = array('optional' => true, 'defaultunit' => 86400);
        $mform->addElement('duration', 'enrolperiod', get_string('enrolperiod', 'enrol_els_paypalcheckout'), $options);
        $mform->setDefault('enrolperiod', $this->get_config('enrolperiod'));
        $mform->addHelpButton('enrolperiod', 'enrolperiod', 'enrol_els_paypalcheckout');
        $options = array('optional' => true);
        $mform->addElement('date_time_selector', 'enrolstartdate', get_string('enrolstartdate', 'enrol_els_paypalcheckout'), $options);
        $mform->setDefault('enrolstartdate', 0);
        $mform->addHelpButton('enrolstartdate', 'enrolstartdate', 'enrol_els_paypalcheckout');
        $options = array('optional' => true);
        $mform->addElement('date_time_selector', 'enrolenddate', get_string('enrolenddate', 'enrol_els_paypalcheckout'), $options);
        $mform->setDefault('enrolenddate', 0);
        $mform->addHelpButton('enrolenddate', 'enrolenddate', 'enrol_els_paypalcheckout');
        if (enrol_accessing_via_instance($instance)) {
            $warningtext = get_string('instanceeditselfwarningtext', 'core_enrol');
            $mform->addElement('static', 'selfwarn', get_string('instanceeditselfwarning', 'core_enrol'), $warningtext);
        }
    }

    /**
     * Perform custom validation of the data used to edit the instance.
     *
     * @param array $data array of ("fieldname"=>value) of submitted data
     * @param array $files array of uploaded files "element_name"=>tmp_file_path
     * @param object $instance The instance loaded from the DB
     * @param context $context The context of the instance we are editing
     * @return array of "element_name"=>"error_description" if there are errors,
     * @return void
     */

    public function edit_instance_validation($data, $files, $instance, $context) {
        $errors = array();
        if (!empty($data['enrolenddate']) and $data['enrolenddate'] < $data['enrolstartdate']) {
            $errors['enrolenddate'] = get_string('enrolenddaterror', 'enrol_els_paypalcheckout');
        }
        $cost = str_replace(get_string('decsep', 'langconfig'), '.', $data['cost']);
        if (!is_numeric($cost)) {
            $errors['cost'] = get_string('costerror', 'enrol_els_paypalcheckout');
        }
        $validstatus = array_keys($this->get_status_options());
        $validcurrency = array_keys($this->get_currencies());
        $validroles = array_keys($this->get_roleid_options($instance, $context));
        $tovalidate = array(
            'name' => PARAM_TEXT,
            'status' => $validstatus,
            'currency' => $validcurrency,
            'roleid' => $validroles,
            'enrolperiod' => PARAM_INT,
            'enrolstartdate' => PARAM_INT,
            'enrolenddate' => PARAM_INT
        );
        $typeerrors = $this->validate_param_types($data, $tovalidate);
        $errors = array_merge($errors, $typeerrors);
        return $errors;
    }

    /**
     * Execute synchronisation.
     * @param progress_trace $trace
     * @return int exit code, 0 means ok
     */

    public function sync(progress_trace $trace) {
        $this->process_expirations($trace);
        return 0;
    }

    /**
     * Is it possible to delete enrol instance via standard UI?
     *
     * @param stdClass $instance
     * @return bool
     */

    public function can_delete_instance($instance) {
        $context = context_course::instance($instance->courseid);
        return has_capability('enrol/paypal:config', $context);
    }

    /**
     * Is it possible to hide/show enrol instance via standard UI?
     *
     * @param stdClass $instance
     * @return bool
     */

    public function can_hide_show_instance($instance) {
        $context = context_course::instance($instance->courseid);
        return has_capability('enrol/paypal:config', $context);
    }

    public static function print_invoice($checkout, $download = false) {
        global $CFG, $DB;        
        $products = array();       
        $products = $DB->get_record('course', array('id' => $checkout->courseid));      
        $params = new stdClass;
        $params->products = $products;
        $params->currency = get_config('enrol_els_paypalcheckout', 'currency').' ';
        $userto = $DB->get_record('user', array('id'=>$checkout->userid));
        $params->username = fullname($userto);
        $params->email = $userto->email;              
        $params->subtotal = $checkout->option_selection2_x;
        $params->discount = $checkout->discount_code_amount;
        $params->salestax = $checkout->tax;
        $params->balancedue = "0.00";
        if($params->payment_status == 'pending'){
            $params->balancedue = $checkout->option_selection2_x;
        }

        $filename = clean_filename("invoice".$checkout->id.".pdf");

        self::generate_invoice($checkout, $params, $filename, $download);
    }

    public static function generate_invoice($checkout, $params, $filename, $download = false, $createfile = true) {
        global $CFG, $DB, $OUTPUT, $PAGE, $SITE;      
        define('PDF_CUSTOM_FONT_PATH', $CFG->dirroot.'/enrol/els_paypalcheckout/fonts/pdf_fonts/');
        require_once("$CFG->libdir/pdflib.php");

        make_cache_directory('tcpdf');

        // No debugging here, sorry.
        $PAGE->set_context(context_system::instance());
        $CFG->debugdisplay = 0;
        @ini_set('display_errors', '0');
        @ini_set('log_errors', '1');

        $pdf = new \PDF('P', 'mm', 'A4', true, 'UTF-8', false);

        $pdf->SetTitle($filename);       
        $pdf->SetProtection(array('modify'));
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $pdf->SetAutoPageBreak(false, 0);
        $pdf->AddPage();
        $pdf->SetTextColor(0, 0, 0);

        $site = get_site();
        $params->sitename = $site->fullname;
        $params->receiptdate = userdate($checkout->timeupdated, get_string('strftimedatefullshort', 'core_langconfig'));

        self::receipt_print_text($pdf, 150, 15, 'L', 'arialunicodems', '', 20, $SITE->fullname);
        self::receipt_print_text($pdf, 15, 55, 'L', 'arialunicodems', '', 20, strtoupper(get_string('invoice','enrol_els_paypalcheckout')));

        // Bill To
        self::receipt_print_text($pdf, 15, 70, 'L', 'arialunicodems', 'B', 11, strtoupper(get_string('billto', 'enrol_els_paypalcheckout')), 250);
        self::receipt_print_text($pdf, 15, 77, 'L', 'arialunicodems', '', 11, $params->username, 30);
        self::receipt_print_text($pdf, 15, 77, 'L', 'arialunicodems', '', 11, $params->address, 30);
        self::receipt_print_text($pdf, 15, 77, 'L', 'arialunicodems', '', 11, $params->state, 30);
        self::receipt_print_text($pdf, 15, 77, 'L', 'arialunicodems', '', 11, $params->email, 30);

        // invoice data
        self::receipt_print_text($pdf, 65, 70, 'R', 'arialunicodems', 'B', 11, get_string('invoicenumber','enrol_els_paypalcheckout') , 100);
        self::receipt_print_text($pdf, 164, 70, 'L', 'arialunicodems', '', 11, $checkout->id, 30);

        self::receipt_print_text($pdf, 65, 70, 'R', 'arialunicodems', 'B', 11, get_string('invoicedate', 'enrol_els_paypalcheckout'), 100);
        self::receipt_print_text($pdf, 164, 77, 'L', 'arialunicodems', '', 11, $params->receiptdate, 30);

        // divider
        self::receipt_print_text($pdf, 15, 95, 'L', 'arialunicodems', '', 11, '<hr>', 182);

        $table = self::generate_products_table($checkout, $params);
        self::receipt_print_text($pdf, 15, 100, 'L', 'arialunicodems', '', 10, $table, 182);

        // Clean any content of the output buffer
        //ob_end_clean();
        ob_clean();

        if ($download) {
            $pdf->Output($filename, 'D');
            exit;
        }

        if($createfile){
            $filepath = $CFG->dataroot . '/' .$filename;
            $pdf->Output($filepath, 'F');
            return $filepath;
        }

        return $pdf->Output($filename, 'I');
    }

    /**
     * Sends text to output given the following params.
     *
     * @param stdClass $pdf
     * @param int $x horizontal position
     * @param int $y vertical position
     * @param char $align L=left, C=center, R=right
     * @param string $font any available font in font directory
     * @param char $style ''=normal, B=bold, I=italic, U=underline
     * @param int $size font size in points
     * @param string $text the text to print
     * @param int $width horizontal dimension of text block
     */
    public static function receipt_print_text($pdf, $x, $y, $align, $font='freeserif', $style, $size = 10, $text, $width = 0) {
        $pdf->setFont($font, $style, $size);
        $pdf->SetXY($x, $y);
        $pdf->writeHTMLCell($width, 0, '', '', $text, 0, 0, 0, true, $align);
    }


    /**
     * Prints border images from the borders folder in PNG or JPG formats.
     *
     * @param stdClass $pdf
     * @param string $filename
     * @param int $x x position
     * @param int $y y position
     * @param int $w the width
     * @param int $h the height
     */
    public static function receipt_print_image($pdf, $filepath, $x, $y, $w, $h) {
        //$pdf->Image($filepath, $x, $y, $w, $h);
        $pdf->Image($filepath, $x, $y, $w, $h,'','','','','300','',false,false,'','');
    }

    public static function generate_products_table($checkout, $params) { 
        if( $checkout->discount_type=='Fixed'){
            $discount_amt=$checkout->discount_code_amount;
        }
        elseif($checkout->discount_type=='Percentage'){
            $discount_amt=$checkout->option_selection2_x * $checkout->discount_code_amount/100;
        } else{    
            $discount_amt=$checkout->discount_code_amount;  
        }         

        $productslist = '';
       
           
                $productslist .= '<tr><td width="50%"><strong>'.$checkout->item_name.'</strong>';               
                $productslist .= '</td><td width="15%" align="left">'.$params->currency.' '.format_float($checkout->option_selection2_x, 2, false).'</td>';
                $productslist .= '<td width="15%" align="left">'.(($checkout->discount_code_amount) ? $params->currency.' '.format_float($discount_amt, 2, false) : '').'</td>';
                $productslist .= '<td width="20%" align="right">';
                $productslist .= ($checkout->option_selection1_x) ? $params->currency.' '.format_float($checkout->option_selection1_x, 2, false) : $params->currency.' '.format_float($product->item_price, 2, false);
                $productslist .= '</td></tr>';
           
            $params->productslist = $productslist;   

        $barcolor = '#cccccc';

        if($config->barcolor){
            $barcolor = $config->barcolor;
        }

        return '<table cellpadding="5">
                <thead>
                    <tr style="background-color: '.$barcolor.';">
                        <th width="50%">'.strtoupper(get_string('course', 'enrol_els_paypalcheckout')).'</th>
                        <th width="15%" align="left">'.strtoupper(get_string('course_prc', 'enrol_els_paypalcheckout')).'</th>
                        <th width="15%" align="left">'.strtoupper(get_string('discount_amount', 'enrol_els_paypalcheckout')).'</th>
                        <th width="20%" align="right">'.strtoupper(get_string('course_amt', 'enrol_els_paypalcheckout')).'</th>
                    </tr>
                </thead>
                <tbody>
                    '.$productslist.'
                </tbody>
                </table>
                <br><hr>
                <table cellpadding="3" width="100%">
                <tbody>
                </tbody>
                    <tr>
                        <td width="70%" align="right">'.strtoupper(get_string('total', 'enrol_els_paypalcheckout')).'</td>
                        <td width="30%" align="right">'.$params->currency.format_float($checkout->option_selection1_x, 2, false).'</td>
                    </tr>
                    
                </tbody>
                </table>';
    }    
}