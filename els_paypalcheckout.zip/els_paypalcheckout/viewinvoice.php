<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
* @package enrol_els_paypalpro
* @category enrol
* @copyright  ELS <admin@elearningstack.com>
* @author eLearningstack
*/

require_once "../../config.php";
$id = required_param('id', PARAM_INT);
$action = required_param('action', PARAM_TEXT);
require_login();
$context = context_system::instance();
$title = get_string('invoice', 'enrol_els_paypalcheckout');
$PAGE->set_url('/enrol/els_paypalcheckout/viewinvoice.php');
$PAGE->set_pagelayout('standred');
$PAGE->set_context($context);
$PAGE->navbar->add($title);
$PAGE->set_title($title);
$PAGE->set_heading($title);

$checkout = $DB->get_record('enrol_els_paypalcheckout', array('id'=>$id));
$msg_params = new stdClass();
$msg_params->download = format_string(new \moodle_url('/enrol/els_paypalcheckout/viewinvoice.php', array('id' => $id, 'action' => 'download')));
$msg_params->view = format_string(new \moodle_url('/enrol/els_paypalcheckout/viewinvoice.php', array('id' => $id, 'action' => 'generate')));

if($action == 'view'){
    $renderer = $PAGE->get_renderer('enrol_els_paypalcheckout');
    echo $OUTPUT->header();

    $message = get_string('invoice_paid', 'enrol_els_paypalcheckout');
    $message.= "<br/><br/>";
    $message.= get_string('download_invoice', 'enrol_els_paypalcheckout', $msg_params);
    echo $renderer->store_print_menu('view');
    echo $renderer->print_basic_header(get_string('invoice', 'enrol_els_paypalcheckout'));
    echo $renderer->print_invoice($message);
    echo $OUTPUT->footer();
}else if($action == 'generate'){
    \enrol_els_paypalcheckout\invoices::print_invoice($checkout);
}
else if($action == 'download'){
    \enrol_els_paypalcheckout\invoices::print_invoice($checkout,true);
}
