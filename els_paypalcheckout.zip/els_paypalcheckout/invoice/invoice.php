<?php



require('fpdf183/fpdf.php');



require_once('../../../config.php');

global $DB;

$get_id=$_GET['id'];



$dscs = $DB->get_records_sql('SELECT us.id as uis,us.firstname,us.lastname,us.country,us.email,us.phone1,eo.paid_amount_currency, u.*

                      FROM {enrol} e  

					  INNER JOIN {enrol_els_paypalpro} u ON u.courseid=e.courseid 

					  INNER JOIN {user} us on us.id=u.userid 

					  INNER JOIN {els_paypalpro_orders} eo ON us.id=eo.user_id  WHERE  u.id  = "'.$get_id.'" ');



 foreach ($dscs as $kvalue) {
$dscsss = $DB->get_records_sql('SELECT * FROM  {user_info_data} uids INNER JOIN {user_info_field} uinf ON uids.fieldid = uinf.id WHERE uinf.id = 3  AND uids.userid = "'.$kvalue->uis.'"  ');

foreach ($dscsss as $kvalues) {
	 $address=$kvalues->data;
}
$dscsss1 = $DB->get_records_sql('SELECT * FROM  {user_info_data} uids INNER JOIN {user_info_field} uinf ON uids.fieldid = uinf.id WHERE uinf.id = 4  AND uids.userid = "'.$kvalue->uis.'"  ');

foreach ($dscsss1 as $kvalues1) {
	 $state=$kvalues1->data;
}

if($kvalue->discount_code){



   $dd=$kvalue->discount_type;



  if( $dd=='Fixed'){



   $c=$kvalue->discount_code_amount;



  }



  elseif($dd=='Percentage'){



 $c=$kvalue->option_selection2_x * $kvalue->discount_code_amount/100;

  }



  else{

      

   $c=$kvalue->discount_code_amount;

  

  }

  }

else

{

  $dd=$kvalue->discount_type='';

  $c=$kvalue->discount_code_amount='';

  

}



if($kvalue->discount_code_amount!=''){



	$curr=$kvalue->paid_amount_currency;

}

else{

$curr='';

}





$total_discount=$kvalue->option_selection2_x-$c;



  

          if($total_discount<0)

              {

             $total_discount= 0;

              }

          else{

             $total_discount ;

              }











    $firstname=$kvalue->firstname;
	$lastname=$kvalue->lastname;
	
	 $country=$kvalue->country;

 	$phone=$kvalue->phone1;

 	$email=$kvalue->email;

 	// $r_email=$kvalue->business;

 	$item_name=$kvalue->item_name;

 	$discount=$c;


 	$currency=$kvalue->paid_amount_currency;

 	$currency1=$curr;

  $unit_price=$kvalue->option_selection2_x;	

  $invoiceid=$kvalue->txn_id;

  $date = date(' F d, Y',$kvalue->timeupdated);

 



  if ($c > 0) {
    $discount_am = '$ '.$c;
}else{
    $discount_am = $c;
}





}



//A4 width : 219mm

//default margin : 10mm each side

//writable horizontal : 219-(10*2)=189mm



$pdf = new FPDF('P','mm','A4');

$pdf->AddPage();



//set font to arial, bold, 14pt

$pdf->SetFont('Arial','B',14);



//Cell(width , height , text , border , end line , [align] )

//$pdf->Cell(130	,5,'Company Logo',0,0);

$pdf->Image('logo.png',5,5,65);



//Cell(width , height , text , border , end line , [align] )

$pdf->Cell(115,5,'',0,0);

$pdf->Cell(10,5,'Transaction Details',0,1,'L');//end of line



//set font to arial, regular, 12pt

$pdf->SetFont('Arial','',12);



//$pdf->Cell(130	,5,'[Street Address]',0,0);

//$pdf->Cell(59	,5,'',0,1);//end of line





$pdf->Cell(130	,5,'',0,0);

$pdf->Cell(25	,5,'',0,1);

$pdf->Cell(25	,5,'',0,1);







$pdf->Cell(115,5,'',0,0);

$pdf->Cell(10,5,'Date: '.$date,0,0);

//$pdf->Cell(25,5, $date,0,1);//end of line



$pdf->Cell(115	,5,'',0,0);

$pdf->Cell(10	,5,'',0,1,'R');

//$pdf->Cell(190	,5,$date,0,1,'R');



$pdf->Cell(115,5,'',0,0);

$pdf->Cell(10,5,'Transaction No: '.$invoiceid,0,0);

//$pdf->Cell(34,5,$invoiceid,0,1);//end of line

//$pdf->Line(10,60,100,60);

$pdf->Line(10,40,200,40);

$pdf->Cell(130	,5,'',0,0);

$pdf->Cell(25	,5,'',0,1,'R');

//$pdf->Cell(170	,5,$invoiceid,0,1,'R');//end of line





//make a dummy empty cell as a vertical spacer

$pdf->Cell(189	,10,'',0,1);//end of line



$pdf->Line(10,80,200,80);

$pdf->SetFont('Arial','B',14);



//billing address





$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(90,5,'Bill To',0,0);



$pdf->Cell(90,5,'Payment Method',0,1,'L');//end of line



$pdf->SetFont('Arial','',12);



//add dummy cell at beginning of each line for indentation

$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(90	,5,$firstname.' '.$lastname,0,0);



$pdf->Cell(90,5, 'PayPal Payment Pro',0,1,'L');



// $pdf->Cell(10	,5,'',0,0);

// $pdf->Cell(90	,5,$r_email,0,1);



$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(90	,5,$address,0,1);


$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(90	,5,$state.' ('.$country .').',0,1);

// $pdf->Cell(10	,5,'',0,0);

// $pdf->Cell(90	,5,$phone,0,1);



$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(90	,5,$email,0,1);

//make a dummy empty cell as a vertical spacer

$pdf->Cell(189	,10,'',0,1);//end of line



//invoice contents

$pdf->SetFont('Arial','B',12);

$pdf->Cell(65	,5,'Course Enrolled',1,0);

$pdf->Cell(39	,5,'Unit Price',1,0);

$pdf->Cell(39	,5,'Discount amount',1,0);//end of line

$pdf->Cell(34	,5,'Sub Total',1,1); 



$pdf->SetFont('Arial','',12);



//Numbers are right-aligned so we give 'R' after new line parameter

$cellWidth=65;

$cellHeight=5;

if($pdf->GetStringWidth($item_name) < $cellWidth){

	//if not, then do nothing

	$line=1;

}else{

	//if it is, then calculate the height needed for wrapped cell

	//by splitting the text to fit the cell width

	//then count how many lines are needed for the text to fit the cell

	

	$textLength=strlen($item_name);	//total text length

	$errMargin=8;		//cell width error margin, just in case

	$startChar=0;		//character start position for each line

	$maxChar=0;			//maximum character in a line, to be incremented later

	//$textArray=array($actividad_a_facturar);	//to hold the strings for each line

	$textArray=array($item_name);

	$tmpString="";		//to hold the string for a line (temporary)

	

	while($startChar < $textLength){ //loop until end of text

		//loop until maximum character reached

		while( 

		$pdf->GetStringWidth( $tmpString ) < ($cellWidth-$errMargin) &&

		($startChar+$maxChar) < $textLength ) {

			$maxChar++;

			$tmpString=substr($item_name,$startChar,$maxChar);

		}

		//move startChar to next line

		$startChar=$startChar+$maxChar;

		//then add it into the array so we know how many line are needed

		array_push($textArray,$tmpString);

		//reset maxChar and tmpString

		$maxChar=0;

		$tmpString='';

		

	}

	//get number of line

	$line=count($textArray);

}







$xPos=$pdf->GetX();

$yPos=$pdf->GetY();



$pdf->MultiCell($cellWidth, 5,utf8_decode($item_name),1);





//return the position for next cell next to the multicell

//and offset the x with multicell width

$pdf->SetXY($xPos + $cellWidth , $yPos);



$pdf->Cell(39,($line * $cellHeight),' $ '. $unit_price .' '. $currency,1,0,'C');

$pdf->Cell(39,($line * $cellHeight),$discount_am.' ' . $currency1,1,0,'C');

$pdf->Cell(34,($line * $cellHeight),' $ '. $total_discount,1,1,'C'); //adapt height to number of lines

 //adapt height to number of lines

//summary

$pdf->Cell(65	,5,'',0,0);

$pdf->Cell(39	,5,'',0,0);

$pdf->Cell(39	,5,'Total',1,0);

$pdf->Cell(34	,5,' $ '. $total_discount++ .' '. $currency ,1,1,'C');





$pdf->Cell(10,30,'',0,1);//end of line



$pdf->Line(10,120,200,120);

$pdf->SetFont('Arial','B',14);



$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(177,5,'Aviation Continuing Education,Inc.',0,1,'L');//end of line



$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(177,5,'DBA SafetyPro Training Center ',0,1,'L');





$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(177,5,'16490 NE 51ST ST ',0,1,'L');



$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(177,5,'Williston FL 32696',0,1,'L');





$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(177,5,'1-877-322-7139',0,1,'L');


$pdf->Cell(10	,5,'',0,0);

$pdf->Cell(177,5,'cs@aviationcontinuinged.com',0,1,'L');





$pdf->Output();



?>

