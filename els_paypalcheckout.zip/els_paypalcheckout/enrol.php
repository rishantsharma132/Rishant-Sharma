<?php

// This file is part of Moodle - https://moodle.org/

//

// Moodle is free software: you can redistribute it and/or modify

// it under the terms of the GNU General Public License as published by

// the Free Software Foundation, either version 3 of the License, or

// (at your option) any later version.

//

// Moodle is distributed in the hope that it will be useful,

// but WITHOUT ANY WARRANTY; without even the implied warranty of

// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the

// GNU General Public License for more details.

//

// You should have received a copy of the GNU General Public License

// along with Moodle. If not, see <https://www.gnu.org/licenses/>.



/**

* @package enrol_els_paypalcheckout

* @category enrol

* @copyright  ELS <admin@elearningstack.com>

* @author eLearningstack

*/



require_once "../config.php";

global $CFG, $PAGE, $SESSION, $OUTPUT;

require($CFG->dirroot.'/enrol/els_paypalcheckout/locallib.php');

$page = optional_param('page' , 1, PARAM_INT);

$PAGE->requires->js("/enrol/els_paypalcheckout/js/creditCardValidator.js");

$PAGE->requires->js("/enrol/els_paypalcheckout/js/cardscript.js");

$PAGE->requires->css("/enrol/els_paypalcheckout/css/style.css");

$id = $_GET["id"];

$url_plugin = $CFG->wwwroot;

$logourl = $OUTPUT->get_logo_url(null, 100);    //logo url

$discount_value = 0;

$total_cost = $cost;

$total = $cost;

$SESSION->course_price = $total;

$message = "";

$curdate = time();

$discount_value = 0;

$discount_type = "";

$code = "";


if (isset($_POST["discount_submit"])) {
    $code = $_POST["discount"];

    $code_obj = $DB->get_record_sql(
        "SELECT * FROM {paypalcheckout_discount_code} WHERE couponcode='$code' and multiple_course IN($course->id)"
    );

    $discount_value = $code_obj->discount_value;

    $discount_type = $code_obj->discount_type;

    if ($code_obj && $code) {
        if ($curdate > $code_obj->date_to) {
            $message = "<p>Discount code Expired</p>";
        } elseif ($curdate < $code_obj->date_from) {
            $message = "Discount code not valid";
        } else {
            if ($code_obj->discount_type == "Fixed") {
                $total_cost = $total_cost - $code_obj->discount_value;
            } else {
                $count_discount =
                    ($total_cost * $code_obj->discount_value) / 100;

                $total_cost = $total_cost - $count_discount;
            }

            $message =
                "<p>Discount code applied: <strong>$code <a href='" .
                $CFG->wwwroot .
                "/enrol/index.php?id=" .
                $course->id .
                "'>X</a></strong></p>";
        }
    } elseif (!$code) {
        $message = "<p>Please enter discount code</p>";
    } else {
        $message = "<p>Discount code not valid</p>";
    }
}

?>


<div align="center">



  <form action="" method="POST">



     <label>Do you have a discount code?</label>



     <input type="text" name="discount" placeholder="Enter Discount Code">



     <input type="submit" name="discount_submit" value="Submit">



   </form>



<div class="message-box"><?php echo $message; ?> </div>

<p><b><?php echo "Course Price : {$instance->currency} {$total}"; ?></b></p>

<?php if ($total_cost != $total) { ?>

    <p><b><?php echo "Discounted Price: {$instance->currency} ". number_format((float)$total_cost, 2, '.', ''); ?></b></p>

<?php } ?>
<div id="checkou-logo" style="text-align-last: center;">

      <img src="<?php echo $CFG->wwwroot; ?>/enrol/els_paypalcheckout/pix/SafetyPro-Website-Logo-2015.gif" ></div>
      <p></p>
      <div id="checkout-content">

          <div style="text-align: center;">

          <div id="paypal-button-content">For purchases of 2 or more students please call 877-322-7139 or send student names, email addresses and course required to cs@aviationcontinuinged.com</div>

          </div>

      </div>

<div id="smart-button-container">

      <div style="text-align: center;">

        <div id="paypal-button-container"></div>

      </div>

    </div>



 <script src="https://www.paypal.com/sdk/js?client-id=AWLY8JDQaFl8z_3F4M8ukGlAYexbZeK1qxdjJoXQgjl9vMs4jGDmVAuC6w0nEFNPilVmAL_14mAWEX4Z" data-sdk-integration-source="button-factory"></script>
<!-- <script src="https://www.paypal.com/sdk/js?client-id=AYCyy9qZHel8Nw0GX8BKAMQOtjeTL9PFDVRsyowkyxFG0SonziTt0C9gMbKrSXau9FBSZdf3_VjJysjr" data-sdk-integration-source="button-factory"></script> -->

<?php

global $PAGE, $DB;

$cid = optional_param('id', 0, PARAM_INT);



$PAGE->requires->js_call_amd('enrol_els_paypalcheckout/enrol_users', 'init', array($total_cost,$discount_value,$discount_type));

?>


<style>
    #page-enrol-index .box.generalbox{
         width: 50%;
        margin: 0 auto;
        margin-bottom : 30px;
    }
    #page-enrol-index .box.generalbox div[align="center"]{
   
   
    border: 1px solid #e7e7e7;
    padding: 10px;
    
}

  #paypal-button-content:after {
    content: '';
    width: 100%;
    position: absolute;
    height: 56px;
    left: 0;
    z-index: 999;
    background: #fff;
    margin-top: 20px;
}
div#paypal-button-content {
    position: relative;
}
div[role="main"] {
    background: #fff;
}
#smart-button-container:before {
    content: '';
    position: absolute;
    background: #fff;
    width: 100%;
    bottom: 0;
    height: 50px;
    left: 0;
    z-index: 999;
}

#smart-button-container {
    position: relative;
}
img[alt="ELS PayPal Pro"] {
    display: none;
}
</style>

  