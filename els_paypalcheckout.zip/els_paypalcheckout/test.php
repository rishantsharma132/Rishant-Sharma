<?php



// This file is part of Moodle - https://moodle.org/



//



// Moodle is free software: you can redistribute it and/or modify



// it under the terms of the GNU General Public License as published by



// the Free Software Foundation, either version 3 of the License, or



// (at your option) any later version.



//



// Moodle is distributed in the hope that it will be useful,



// but WITHOUT ANY WARRANTY; without even the implied warranty of



// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the



// GNU General Public License for more details.



//



// You should have received a copy of the GNU General Public License



// along with Moodle. If not, see <https://www.gnu.org/licenses/>.







/**



* @package enrol_els_paypalcheckout



* @category enrol



* @copyright  ELS <admin@elearningstack.com>



* @author eLearningstack



*/







require_once('../../config.php');



global $CFG, $DB;



$data = $DB->get_records_sql("SELECT * FROM {els_paypalcheckout_orders}");
echo "<pre>";
echo "els_paypalcheckout_orders";

print_r($data);

echo "<br>";

echo "<br>";



$data1 = $DB->get_records_sql("SELECT * FROM {enrol_els_paypalcheckout}");



echo "enrol_els_paypalcheckout";

print_r($data1);

echo "<br>";