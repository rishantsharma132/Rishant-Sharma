// This file is part of Moodle - http://moodle.org/



//



// Moodle is free software: you can redistribute it and/or modify



// it under the terms of the GNU General Public License as published by



// the Free Software Foundation, either version 3 of the License, or



// (at your option) any later version.



//



// Moodle is distributed in the hope that it will be useful,



// but WITHOUT ANY WARRANTY; without even the implied warranty of



// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the



// GNU General Public License for more details.



//



// You should have received a copy of the GNU General Public License



// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.



define(['jquery', 'core/ajax', 'core/str', 'core/config', 'core/templates', 'core/notification', 'core/modal_factory'], function ($, AJAX, str, mdlcfg, templates, notification, ModalFactory) {



    var enrolUsers = {



        init: function(ccost,discountamount,discount_type) {



            str.get_strings([



            ]).done(function(s) {



                enrolUsers.initPayPalButton(ccost, discountamount,discount_type, s);

            });


        },


     initPayPalButton: function(ccost, discountamount,discount_type, s) {



      paypal.Buttons({



        style: {



          shape: 'rect',



          color: 'gold',



          layout: 'vertical',



          label: 'paypal',


        },

        createOrder: function(data, actions) {



          return actions.order.create({

            purchase_units: [{"amount":{"currency_code":"USD","value":ccost}}],
            application_context: { shipping_preference: 'NO_SHIPPING' }




          });



        },


        onApprove: function(data, actions) {



          return actions.order.capture().then(function(orderData) {   



            console.log('Capture result', orderData, JSON.stringify(orderData, null, 2));
      



            const element = document.getElementById('paypal-button-container');           



                var courseid = $('.coursebox').attr("data-courseid");
           



                element.innerHTML = '';


                element.innerHTML = '<div style="height:56px;width:100%"></div><h3 style="z-index: 99999; position: relative;">Thank you for your payment! <br/><a href="https://www.safetyprotc.com/course/view.php?id='+courseid+'">Go to course</a></h3>';



                myJSON = JSON.stringify(orderData);



                var promises = AJAX.call([



                    {

                        methodname: 'enrol_paypalcheckout_responseData', 



                        args: {



                            courseid: courseid,                     

                            orderdata: myJSON,
                          
                            discountvalue: discountamount,

                            discount_type: discount_type



                        }



                    }    



                ]);



                promise[0].done(function(json) {




                })



            })            



        },







        onError: function(err) {



          console.log(err);



        }



      }).render('#paypal-button-container');



    }    



 }



 return enrolUsers;



});