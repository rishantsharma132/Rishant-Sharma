<?php

// This file is part of Moodle - https://moodle.org/

//

// Moodle is free software: you can redistribute it and/or modify

// it under the terms of the GNU General Public License as published by

// the Free Software Foundation, either version 3 of the License, or

// (at your option) any later version.

//

// Moodle is distributed in the hope that it will be useful,

// but WITHOUT ANY WARRANTY; without even the implied warranty of

// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the

// GNU General Public License for more details.

//

// You should have received a copy of the GNU General Public License

// along with Moodle. If not, see <https://www.gnu.org/licenses/>.



/**

* @package enrol_els_paypalcheckout

* @category enrol

* @copyright  ELS <admin@elearningstack.com>

* @author eLearningstack

*/



defined('MOODLE_INTERNAL') || die();

global $PAGE;



 //---------------------------------------------- license activation -----------------------------------------

$config = get_config('enrol_els_paypalcheckout');

if ($ADMIN->fulltree) {

        $report_url1=$CFG->wwwroot."/enrol/els_paypalcheckout/manage_coupon.php";

        $settings->add(new admin_setting_heading('enrol_els_paypalcheckout_manage_coupon', '', '<h3><a href="'.$report_url1.'">'.get_string("manage_coupon", "enrol_els_paypalcheckout").'</a></h3>'));

       

        $report_url2=$CFG->wwwroot."/enrol/els_paypalcheckout/create_discount.php";

        $settings->add(new admin_setting_heading('enrol_els_paypalcheckout_create_code', '', '<h3><a href="'.$report_url2.'">'.get_string("create_coupon", "enrol_els_paypalcheckout").'</a></h3>'));


        $report_url=$CFG->wwwroot."/enrol/els_paypalcheckout/report.php";

        $settings->add(new admin_setting_heading('enrol_els_paypalcheckout_manage_code', '', '<h3><a href="'.$report_url.'">'.get_string("report", "enrol_els_paypalcheckout").'</a></h3>'));

        $settings->add(new admin_setting_heading('enrol_els_paypalcheckout_settings', '', get_string('pluginname_desc', 'enrol_els_paypalcheckout')));      



        $settings->add(new admin_setting_configtext('enrol_els_paypalcheckout/paypalbusiness', get_string('businessemail', 'enrol_els_paypalcheckout'), get_string('businessemail_desc', 'enrol_els_paypalcheckout'), '', PARAM_EMAIL));

        $settings->add(new admin_setting_configtext('enrol_els_paypalcheckout/apiusername', get_string('apiusername', 'enrol_els_paypalcheckout'), get_string('apiusername_desc', 'enrol_els_paypalcheckout'), '', PARAM_RAW));

        $settings->add(new admin_setting_configtext('enrol_els_paypalcheckout/apipassword', get_string('apipassword', 'enrol_els_paypalcheckout'), get_string('apipassword_desc', 'enrol_els_paypalcheckout'), '', PARAM_RAW));

        $settings->add(new admin_setting_configtext('enrol_els_paypalcheckout/apisignature', get_string('apisignature', 'enrol_els_paypalcheckout'), get_string('apisignature_desc', 'enrol_els_paypalcheckout'), '', PARAM_RAW));

        $settings->add(new admin_setting_configcheckbox('enrol_els_paypalcheckout/checksandbox', get_string('checksandbox', 'enrol_els_paypalcheckout'), '', 0));

        

        $settings->add(new admin_setting_configcheckbox('enrol_els_paypalcheckout/mailstudents', get_string('mailstudents', 'enrol_els_paypalcheckout'), '', 0));

        $settings->add(new admin_setting_configcheckbox('enrol_els_paypalcheckout/mailteachers', get_string('mailteachers', 'enrol_els_paypalcheckout'), '', 0));

        $settings->add(new admin_setting_configcheckbox('enrol_els_paypalcheckout/mailadmins', get_string('mailadmins', 'enrol_els_paypalcheckout'), '', 0));

        // Note: let's reuse the ext sync constants and strings here, internally it is very similar,

        //       it describes what should happen when users are not supposed to be enrolled any more.

        $options = array(

            ENROL_EXT_REMOVED_KEEP           => get_string('extremovedkeep', 'enrol'),

            ENROL_EXT_REMOVED_SUSPENDNOROLES => get_string('extremovedsuspendnoroles', 'enrol'),

            ENROL_EXT_REMOVED_UNENROL        => get_string('extremovedunenrol', 'enrol'),

        );

        $settings->add(new admin_setting_configselect('enrol_els_paypalcheckout/expiredaction', get_string('expiredaction', 'enrol_els_paypalcheckout'), get_string('expiredaction_help', 'enrol_els_paypalcheckout'), ENROL_EXT_REMOVED_SUSPENDNOROLES, $options));



        //--- enrol instance defaults ----------------------------------------------------------------------------

        $settings->add(new admin_setting_heading('enrol_els_paypalcheckout_defaults',

            get_string('enrolinstancedefaults', 'admin'), get_string('enrolinstancedefaults_desc', 'admin')));

        $options = array(ENROL_INSTANCE_ENABLED  => get_string('yes'),

                         ENROL_INSTANCE_DISABLED => get_string('no'));

        $settings->add(new admin_setting_configselect('enrol_els_paypalcheckout/status',

            get_string('status', 'enrol_els_paypalcheckout'), get_string('status_desc', 'enrol_els_paypalcheckout'), ENROL_INSTANCE_DISABLED, $options));

        $settings->add(new admin_setting_configtext('enrol_els_paypalcheckout/cost', get_string('cost', 'enrol_els_paypalcheckout'), '', 0, PARAM_FLOAT, 4));

        $paypalcurrencies = enrol_get_plugin('paypal')->get_currencies();

        $settings->add(new admin_setting_configselect('enrol_els_paypalcheckout/currency', get_string('currency', 'enrol_els_paypalcheckout'), '', 'USD', $paypalcurrencies));

        if (!during_initial_install()) {

            $options = get_default_enrol_roles(context_system::instance());

            $student = get_archetype_roles('student');

            $student = reset($student);

            $settings->add(new admin_setting_configselect('enrol_els_paypalcheckout/roleid',

                get_string('defaultrole', 'role'), get_string('defaultrole_desc', 'enrol_els_paypalcheckout'), $student->id, $options));

        }

        $settings->add(new admin_setting_configduration('enrol_els_paypalcheckout/enrolperiod',

            get_string('enrolperiod', 'enrol_els_paypalcheckout'), get_string('enrolperiod_desc', 'enrol_els_paypalcheckout'), 0));

   

}