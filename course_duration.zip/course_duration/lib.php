<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Callback implementations for local_course_duration
 *
 * @package    local_course_duration
 * @copyright  2023 YOUR NAME <mailto:your@email.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
use question_engine;
require_once($CFG->dirroot . '/mod/quiz/locallib.php');

 function local_course_duration_before_footer() {
  global $PAGE, $DB, $CFG;
  
    if($PAGE->bodyid=='page-mod-quiz-attempt'){
        $PAGE->requires->jquery();
        $page_v = optional_param('page', 0, PARAM_INT);
    
        $cmid = optional_param('cmid', null, PARAM_INT);
        $attempt = optional_param('attempt',  0, PARAM_INT);
        $pageurl = new moodle_url($PAGE->url);
        $attemptobj = quiz_create_attempt_handling_errors($attempt, $cmid);
        $slots = $attemptobj->get_slots($page_v);
        $attemptobj->get_uniqueid();
        
        // Load Moodle's jQuery library
       
        $quba = question_engine::load_questions_usage_by_activity($attemptobj->get_uniqueid());
       

        $specified_number_choices=0;
         
       foreach($slots as $slot){
            $question = $quba->get_question($slot, false);
            $q_type= $quba->get_question($slot, false)->get_type_name();
            if($q_type!='multichoice'){
                continue;
            }
          
            foreach ($question->answers as $answers) {
                 if($answers->fraction > 0){
                    $specified_number_choices++;
                 };
            }
        }


       $max_choices_message = 'You can select min '.$specified_number_choices.' options and Max '.$specified_number_choices; // Example message, replace with your message
            $min_choices_message = 'Minimum choices not met'; // Example message, replace with your message
            // JavaScript code using the dynamically fetched number of choices
            $js = "
            require(['jquery'], function($) {
                $(document).ready(function() {
                   
                    var specifiedNumberChoices = $specified_number_choices;
                    // Handle checkbox clicks
                    var total = $('div.answer input[type=checkbox]:checked').length;

                    $('div.answer input[type=checkbox]').on('click', function(event) {
                        if (!$(this).is(':checked')) {
                            total--;
                            $('div.validationerror').remove();
                        } else if (total < specifiedNumberChoices) {
                            total++;
                            $('div.validationerror').remove();
                        } else {
                            event.preventDefault();
                            event.stopPropagation();
                            if (!$('div.validationerror').length) {
                                $('div.answer').after('<div class=\"validationerror\">$max_choices_message</div>');
                            }
                        }
                    });
                    // Handle submit button click
                    $('div.formulation div.im-controls input[type=submit]').click(function(event) {
                        event.preventDefault();
                            event.stopPropagation();
                        if (total < 1 || total > specifiedNumberChoices) {
                            if (!$('div.validationerror').length) {
                                $('div.answer').after('<div class=\"validationerror\">$min_choices_message</div>');
                            }
                            event.preventDefault();
                            event.stopPropagation();
                        }
                    });
                });
            });
            ";
            // Initialize the JavaScript code
            $PAGE->requires->js_init_code($js);
        

      
    }
}
