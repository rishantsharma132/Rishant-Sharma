<?php
require_once('../../config.php');
global $DB;
 $main_cohortid = '';
      
            /***********22/02/2019************

        *****ASSIGN TASK TO BM USERS******/

        $getuserid=$DB->get_record('user', array('id' => $usernew->id));
        if($getuserid)
        {

        $bmtaskid=$DB->get_records_sql("SELECT * from mdl_bm_task_list where bm_id=$USER->id AND state_assign='$getuserid->address'");

        foreach ($bmtaskid as $keytask) {

        $grou= explode(", ", $keytask->group_assign);          
        if(!empty($keytask->id) && in_array($getuserid->department, $grou))
        {

                $time=time();

                $record = new stdClass();

                $record->bm_id=$USER->id;

                $record->userid=$usernew->id;

                $record->task_id=$keytask->id;

                $record->created_date=$time;

                  $current_date=time();
                  $date1=date('Y-m-d',$current_date);

                  $due_type=$keytask->due_type;
                  $due_date=$keytask->due_date;

                    if($due_type=='days')

                      {


                        $effectiveDate1 = date('Y-m-d', strtotime("+".$due_date."days" , strtotime($date1)));

                      }

                      elseif($due_type=='months') 

                      {

                         $effectiveDate1 = date('Y-m-d', strtotime("+".$due_date."months", strtotime($date1)));

                      }

                      elseif($due_type=='years')

                      {

                         $effectiveDate1=date('Y-m-d', strtotime('+'.$due_date.'years', strtotime($date1)) );

                      }


                $record->due_date=$effectiveDate1;


                $result_data = $DB->insert_record('user_task_assignment', $record);

                if($result_data)
                {
                    $record1 = new stdClass();

                    $record1->userid=$usernew->id;

                    $record1->assignment_id=$result_data;

                    $record1->completion_state=1;

                    $record1->timemodified=$time;


                    $result_data1 = $DB->insert_record('task_completion', $record1);
                }

            if(!empty($keytask->course_id))
            {
              $rec = new stdClass();

              $rec->enrol='manual';

              $rec->status=0;

              $rec->courseid=$keytask->course_id;

              $rec->timecreated=$time;

              $rec->roleid=5;

              $getenrol=$DB->get_records_sql("SELECT * from {enrol} where courseid=$keytask->course_id  and enrol='manual'");
              foreach ($getenrol as $keyenrol) {
                $newenrol_id=$keyenrol->id;
              }
              if(!empty($newenrol_id))
              {
                $newenrol_id=$keyenrol->id;
              }else
              {
                $newenrol_id = $DB->insert_record('enrol', $rec);
              }
                        

                if(!empty($newenrol_id))
                {

                $userenrol=$DB->get_records_sql("SELECT * from {user_enrolments} where enrolid=$newenrol_id and userid=$usernew->id");            
                if($userenrol)
                {

                }else{
                  $recuser = new stdClass();

                  $recuser->status=0;

                  $recuser->enrolid=$newenrol_id;

                  $recuser->userid=$usernew->id;

                  $recuser->timestart=time();

                  $recuser->timeend=0;

                  $recuser->timecreated=time();


                  $newuserenrol_id = $DB->insert_record('user_enrolments', $recuser);
                }
                }
            }
            
        
        }

        }
       
    }

//****************END CODE HERE******************