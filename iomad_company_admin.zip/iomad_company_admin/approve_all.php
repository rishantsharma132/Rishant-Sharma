<?php

require_once(dirname(__FILE__) . '/../../config.php');
 global $CFG, $USER,$DB;

$get_alldata=$DB->get_records_sql("SELECT * FROM {request_transfer} WHERE status=0");


    foreach ($get_alldata as $key ) {
        // code...
    
        $update= new stdClass();
        $update->id=$key->id;       
        $update->status=1;        
        $up=$DB->update_record('request_transfer', $update);        

       if($up){
      $cmobj=$DB->get_record('company_users', array('userid'=>$key->user_id));
       if(!$cmobj){

        $upd= new stdClass();
        $upd->userid=$key->user_id;        
       $upd->companyid=$key->company_id;
       $upd->departmentid=$key->company_id;
       $ins=$DB->insert_record('company_users',$upd);
      
       }
       else{
       $upd= new stdClass();
        $upd->id=$cmobj->id;      
        $upd->companyid=$key->company_id;
        $upd->departmentid=$key->company_id;
        $ins=$DB->update_record('company_users',$upd);
       }
     }
 }