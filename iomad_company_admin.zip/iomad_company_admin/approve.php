<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package    Block Iomad Approve Access
 * @copyright  2011 onwards E-Learn Design Limited
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(dirname(__FILE__) . '/../../config.php');
require_once('lib.php');
$PAGE->requires->js_call_amd('block_iomad_company_admin/company_user', 'init', []);

$returnurl = optional_param('returnurl', '', PARAM_LOCALURL);

$context = context_system::instance();
  

require_login();
iomad::require_capability('block/iomad_company_admin:company_user', $context);

$urlparams = array();
if ($returnurl) {
    $urlparams['returnurl'] = $returnurl;
}

// Correct the navbar.
// Set the name for the page.
$linktext = get_string('approveusers', 'block_iomad_company_admin');
// Set the url..
$linkurl = new moodle_url('/blocks/iomad_company_admin/request.php');

$PAGE->set_context($context);
$PAGE->set_url($linkurl);
$PAGE->set_pagelayout('admin');
$PAGE->set_title($linktext);

// Set the page heading.
$PAGE->set_heading(get_string('myhome') . " - $linktext");
if (empty($CFG->defaulthomepage)) {
    $PAGE->navbar->add(get_string('dashboard', 'block_iomad_company_admin'), new moodle_url($CFG->wwwroot . '/my'));
}
$PAGE->navbar->add($linktext, $linkurl);

 echo $OUTPUT->header();
if(!is_siteadmin()){
     echo "You dont have permission to access this page";
     exit();
}
global $DB, $USER;
 
          echo '<div><input type="submit"  name="Approved" value="Approve All" id="aprovebutton"></div>';


	        $table = new html_table();
            $table->attributes['company_admin'] =  'block_iomad_company_admin';
            $table->head = array( get_string('fullname', 'block_iomad_company_admin'), 'Current Company' , 'Requested Company',get_string('approve', 'block_iomad_company_admin'));
 


$get_request=$DB->get_records_sql("SELECT * FROM mdl_request_transfer rt WHERE rt.status=0 ");

foreach ($get_request as $req) {
    $userobj=$DB->get_record('user', array('id'=>$req->user_id));
    $usercompid=$DB->get_record('company_users', array('userid'=>$req->user_id));
    $usercomp=$DB->get_record('company', array('id'=>$usercompid->companyid));
    $compobj=$DB->get_record('company', array('id'=>$req->company_id));
                
                $table->data[] = array(
                'fullname'=>$userobj->firstname." ".$userobj->lastname,
                'currentcompany' => $usercomp->name,
                'companyrequested' => $compobj->name,  

                 'approve'=>'<a  href="approve.php?rid='.$req->id.'&companyid='.$req->company_id.'&uid='.$userobj->id.' ">Approve </a>'
             );    

}

echo html_writer::table($table);

$get_approveid= optional_param('rid', 0 , PARAM_INT);
$get_compid= optional_param('companyid', 0 , PARAM_INT);
$get_userid= optional_param('uid', 0 , PARAM_INT);



if ($get_approveid)
 {
        $update= new stdClass();
        $update->id=$get_approveid;       
        $update->status=1;        
        $up=$DB->update_record('request_transfer', $update);        

       
       $cmobj=$DB->get_record('company_users', array('userid'=>$get_userid));
       if(!$cmobj){

          $upd= new stdClass();
         
       $upd->userid=$get_userid;        
       $upd->companyid=$get_compid;
       $upd->departmentid=$get_compid;
       $ins=$DB->insert_record('company_users',$upd);
      
       }
       else{
       $upd= new stdClass();
        $upd->id=$cmobj->id;      
        $upd->companyid=$get_compid;
        $upd->departmentid=$get_compid;
        $ins=$DB->update_record('company_users',$upd);
        //redirect($CFG->wwwroot . '/blocks/iomad_company_admin/approve.php','Request Approved');
     
    }
    
   
redirect($CFG->wwwroot . '/blocks/iomad_company_admin/approve.php','Request Approved');



}

echo $OUTPUT->footer();
