<?php
/**
 * @package   block_iomad_company_admin
 * @copyright 2021 Derick Turner
 * @author    Derick Turner
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/// SETUP - NEED TO BE CHANGED
/// generate token in moodle admin:  http://iomad.dev/admin/settings.php?section=webservicetokens
$token = '0cb02d6a22de9554c5f646a2ebb144e0';
/// use your domain here:
$domainname = 'http://iomad.dev';