<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
* @package block_manage_group
* @category local
* @copyright  ELS <admin@elearningstack.com>
* @author eLearningstack
*/
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir."/csvlib.class.php");
$totasluser = optional_param('totaluser', 0, PARAM_INT);
$company = optional_param('company', 0, PARAM_INT);
$fromfilter = optional_param('startdate', 0, PARAM_INT);
$tofilter = optional_param('enddate', 0, PARAM_INT);
global $CFG, $DB, $OUTPUT,$PAGE;  
$report = array();
$report[] =  array(get_string('headername', 'block_manage_group'));
$currenttime = time();
$report[] =  array(get_string('generated_report', 'block_manage_group') . date('l, d F Y', $currenttime)
);
$report[] =  array(get_string('total_users', 'block_manage_group') .' '.  $totasluser);
$table = new html_table();
$report[] = $table->head = array(
  get_string('serialno', 'block_manage_group'), 
  get_string('companyname', 'block_manage_group'), 
  get_string('Contractenddate', 'block_manage_group'),
  get_string('companystatus', 'block_manage_group'),
);
$count=$perpage+1; 
if ($company) {
  $query = ' id = ' . $company;
}
if ($fromfilter) {
  $query = ' validto >= ' . $fromfilter; 
} 
if ($tofilter) {
  $enddate= strtotime("+1 day", $tofilter);
  $query = ' validto <= ' . $enddate; 
}  
if ($fromfilter && $tofilter) {
  $enddate= strtotime("+1 day", $tofilter);
  $query = ' validto BETWEEN ' . $fromfilter . ' AND ' .$enddate; 
} 
if ($fromfilter && $company) {
  $query = ' id = ' . $company . ' AND validto >= ' . $fromfilter; 
} 
if ($tofilter && $company) {
  $enddate= strtotime("+1 day", $tofilter);
  $query = ' id = ' . $company . ' AND validto <= ' . $enddate; 
}
if ($fromfilter && $tofilter && $company) {
  $enddate= strtotime("+1 day", $tofilter);
  $query = ' id = ' . $company . ' AND validto between ' . $fromfilter . ' AND ' .$enddate; 
}
if ($query) {
$com ="SELECT id,name as namess,validto,suspended FROM {company} WHERE $query
ORDER BY id DESC";
}else{
$com ="SELECT id,name as namess,validto,suspended FROM {company} ORDER BY namess ASC";
}
$qsss = $DB->get_records_sql($com);
$totalcount = count($qsss);

$companys = $DB->get_records_sql($com);

foreach ($companys as $co) {
     $companyname =  $co->namess;
     $Contractenddate = $co->validto;
     if ($Contractenddate == 0) {
       $enddate = get_string('enddaenofound', 'block_manage_group');
     }else{
      $enddate = date('l, d F Y, h:i:s A', $co->validto);
     }
   
      $suspended =  $co->suspended;
      if ($suspended == 0) {
        $status = get_string('active', 'block_manage_group');
      }else{
        $status = get_string('suspended', 'block_manage_group');
      }
      $report[] = $table->data[] = array(
  'serialno' => $count++,
  'course_name' => $companyname,
  'Contractenddate' => $enddate,
  'companystatus' => $status,
 );
}
   $myfile = new csv_export_writer();
   $dlfile = $myfile->download_array(get_string('headername', 'block_manage_group'),$report); 
