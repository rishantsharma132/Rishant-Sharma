<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Moodle frontpage.
 *
 * @package    core
 * @copyright  1999 onwards Martin Dougiamas (http://dougiamas.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

    if (!file_exists('../../config.php')) {
        header('Location: install.php');
        die;
    }
    require_once('../../config.php');
    require_once($CFG->dirroot .'/course/lib.php');
    require_once($CFG->libdir .'/filelib.php');
    require_once($CFG->libdir .'/enrollib.php');
    global $DB, $USER, $CFG, $PAGE;
    $userid = optional_param('user', $USER->id, PARAM_INT);
    redirect_if_major_upgrade_required();
    $PAGE->requires->jquery();
    $PAGE->requires->jquery_plugin('ui');
    $urlparams = array();
    if (!empty($CFG->defaulthomepage) && ($CFG->defaulthomepage == HOMEPAGE_MY) && optional_param('redirect', 1, PARAM_BOOL) === 0) {
        $urlparams['redirect'] = 0;
    }
    $PAGE->set_url('/', $urlparams);
    $PAGE->set_course($SITE);

    if ($CFG->forcelogin) {
        require_login();
    } else {
        user_accesstime_log();
    }

    $hassiteconfig = has_capability('moodle/site:config', get_context_instance(CONTEXT_SYSTEM));

/// If the site is currently under maintenance, then print a message
    if (!empty($CFG->maintenance_enabled) and !$hassiteconfig) {
        print_maintenance_message();
    }

    if ($hassiteconfig && moodle_needs_upgrading()) {
        redirect($CFG->wwwroot .'/'. $CFG->admin .'/index.php');
    }

    if (get_home_page() != HOMEPAGE_SITE) {
        // Redirect logged-in users to My Moodle overview if required
        if (optional_param('setdefaulthome', false, PARAM_BOOL)) {
            set_user_preference('user_home_page_preference', HOMEPAGE_SITE);
        } else if (!empty($CFG->defaulthomepage) && ($CFG->defaulthomepage == HOMEPAGE_MY) && optional_param('redirect', 1, PARAM_BOOL) === 1) {
            //redirect($CFG->wwwroot .'/my/');
        } else if (!empty($CFG->defaulthomepage) && ($CFG->defaulthomepage == HOMEPAGE_USER)) {
            $PAGE->settingsnav->get('usercurrentsettings')->add(get_string('makethismyhome'), new moodle_url('/', array('setdefaulthome'=>true)), navigation_node::TYPE_SETTING);
        }
    }
    if (isloggedin()) {
       // add_to_log(SITEID, 'course', 'view', 'view.php?id='.SITEID, SITEID);
    }

/// If the hub plugin is installed then we let it take over the homepage here
    if (get_config('local_hub', 'hubenabled') && file_exists($CFG->dirroot.'/local/hub/lib.php')) {
        require_once($CFG->dirroot.'/local/hub/lib.php');
        $hub = new local_hub();
        $continue = $hub->display_homepage();
        if (empty($continue)) {
            exit;
        }
    }
    $PAGE->set_pagetype('site-index');
    $PAGE->set_other_editing_capability('moodle/course:manageactivities');
    $PAGE->set_docs_path('');
    $PAGE->set_pagelayout('sidebar');
    $editing = $PAGE->user_is_editing();
    $PAGE->set_title($SITE->fullname);
    $PAGE->set_heading($SITE->fullname);

echo $OUTPUT->header();

 $companyid=$DB->get_record_sql("SELECT userid as comid from {company_users} 
    where userid=$USER->id AND managertype =  1 ");
if ($companyid){

?>

<div class="main-wrapper">
<div class="main emp_wizd">
<h1 style="text-align: center;">Enrollment Wizard</h1>
<div id="emp_type">
<div class="col-md-12 emp_type" style="margin-bottom: 20px;">
    <h4>Course Package Group</h4>
    

        <select name="groups" class="groups" id="group" class="form-control" style="margin-left: 0px;" value="">
            <?php
    if (isset($_GET['groupid'])) {
     $get_task=$_GET['groupid'];
 $res1=$DB->get_records_sql("SELECT name from {course_groups} WHERE id = $get_task AND deleted = 0 ORDER BY name ASC ");
$lue1 = '';
 foreach ($res1 as $lue) {
     $lue1 = $lue->name; 
 }
 if (!empty($lue1)) {
    echo "<option value=''selected> $lue1</option>";
 }else{
   echo "<option value=''>--Select Package Group Type--</option>";
 }
 

    }else{
        echo "<option value=''>--Select Package Group Type--</option>";
    }
    
     ?>
                
            
            <?php 
            $res=$DB->get_records_sql("SELECT * from {course_groups} WHERE bm_user_id = $USER->id AND deleted = 0 ORDER BY name ASC");
            foreach($res as $value)
            {
                ?>
                  <option value="<?php echo $value->id; ?>"><?php echo $value->name; ?></option>
                <?php
            }
            ?>
        </select>
</div>
</div>
<?php 

if (isset($_GET['groupid'])) {
    $get_task=$_GET['groupid'];
    $companyid=$DB->get_record_sql("SELECT companyid as comid from {company_users} where userid=$USER->id ");
 ?>
 


<form method="POST">
   
<!-- <div align=''><form name='form_back' action='<?php echo $CFG->wwwroot; ?>/my/' method='POST'><input type='submit' name='Back' value='Back' class="btn btn-primary" style='width:80px'></form></div> -->
<!-- <a href="<?php echo $CFG->wwwroot; ?>/my" class="btn btn-primary">BACK</a> -->


<!-- <div class="col-md-6 search_type" style="margin-bottom: 20px">
    <h4>Search Employee Name</h4>
   
        <div id="autocomplete">

            <input type="text" name="search" id="search-box" placeholder="Search" autocomplete="off" >
            <div id="groupList"></div>
        </div>
        
  


</div> -->

    <div class="col-md-12">

<div style="border: 0px solid black; height: 30px; width: 80%; margin-bottom: 8px;">
<h4>Enroll to Selected User(s)</h4>
</div> 
 
<div id="autocomplete"style="margin-bottom: 8px;">
 <input type="text" name="search_user" placeholder="Search Employee Name" id="search_user"><br/> 
</div>
   
    <?php
     //cohort id starts
    $companyid=$DB->get_record_sql("SELECT companyid as comid from {company_users} where userid=$USER->id ");
    $select_cohort = $DB->get_records_sql("SELECT u.* FROM {user} u INNER JOIN {company_users} cu on u.id=cu.userid
     WHERE cu.companyid=$companyid->comid AND managertype =  0 ORDER BY u.firstname ASC");

    $emp_name = array();
    $emp_id = array();
    $check = array();;
    ?>
<select multiple name="emp[]" id="show1" class="form-control" style="margin-bottom: 20px;">
  
  <?php
        foreach ($select_cohort as $user)
        {
           
        ?>
            <option value="<?php echo $user->id; ?>"><?php echo  $user->firstname.' '.$user->lastname; ?></option>
        <?php
          
        }    
        ?>
</select>
        <!-- <select   name= "emp[]" size="10" id="show1" class="form-control">
         <option value="">--Select Package Group Type--</option>
        <?php
        foreach ($select_cohort as $user)
        {
           
        ?>
            <option value="<?php echo $user->id; ?>"><?php echo  $user->firstname.' '.$user->lastname; ?></option>
        <?php
          
        }    
        ?>
        </select> -->
        <input type="submit" name="as_task" value = "Enroll" />
       
</div>

       
    

<div class="col-md-12">

<div class="course_set">
 	<h2>Courses selected</h2>
 </div>
<?php
echo "<table id='customers' style='width:100%;margin-bottom:50px;'><form name='assin' method='post' >";



    // $compnay_course=$DB->get_records_sql("SELECT * from {company_course} where companyid=$companyid->companyid");


 $compnay_course = $DB->get_records_sql("SELECT c.id, c.fullname from {course} c 
    JOIN {company_course} cc on c.id=cc.courseid
    where cc.companyid=$companyid->comid AND c.category!=985 AND c.visible=1 ORDER BY c.fullname ASC");


// die('hii');
if($compnay_course)
{

    foreach ($compnay_course as $key_course) {
        $courseid=$key_course->id;     
        $compnay_course1 = $DB->get_records_sql("SELECT c.id, c.fullname from {course} c 
            JOIN {course_group_assignment} cc on c.id=cc.userid 
    where cc.userid=$courseid AND cc.course_group_id=$get_task AND cc.bm_id = $USER->id AND c.category!=985 AND c.visible=1 ORDER BY c.fullname ASC");
        foreach ($compnay_course1 as $kvalue) {
            $courseid1=$kvalue->id;  
        }
        
        if ($courseid == $courseid1) {
             echo "<tr><td><input type = 'checkbox' name = 'radio[]'  value='".$courseid1."' checked/></td>"; 
            echo "<td>".$key_course->fullname."</td></tr>";
         }else{
            echo "<tr><td><input type = 'checkbox' name = 'radio[]'  value='".$courseid1."' /></td>"; 
            echo "<td>".$key_course->fullname."</td></tr>";
         }
           
    }
   
    // foreach ($compnay_course1 as $keycourse) {
    //     $courseid1=$keycourse->id;        
    //         echo "<tr><td><input type = 'checkbox' name = 'radio[]'  value='".$courseid1."' /></td>"; 
    //         echo "<td>".$keycourse->fullname."</td></tr>";
    // }
} 

echo "</table>";
?>
</div>






 
</form>
</div>
<?php } ?>
    <?php
		
if(isset($_POST['as_task']))
{
	
    
    $choice = $_POST['radio'];
  
    $emp_selected=$_POST['emp'];
    // print_r($emp_selected);
    // exit();
    
    foreach ($choice as $courseid) {

       
    $instance = $DB->get_record('enrol', array('courseid'=>$courseid, 'enrol'=>'manual'), '*', MUST_EXIST);

        if(!empty($instance))
        {
            foreach ($emp_selected as $userid) {

            $coursecontext = context_course::instance($courseid);

            if(!is_enrolled($coursecontext, $userid))
            {
                $timestart = time();
                $timeend=0;
                $role_id=5;
              
                $enrol_manual = enrol_get_plugin('manual');

                $enrolled =$enrol_manual->enrol_user($instance, $userid, $role_id, $timestart, $timeend);
            
            }  
            }

        }
    }
    ?>
   <script type='text/javascript'>alert('User enrolled Successfully into selected course!!!');</script>
    <?php
}
?>
</div>
</div>
<script>
    $(document).ready(function(){
      // bind change event to select
      $('#group').on('change', function () {
          var url = $(this).val(); // get selected value
          if (url) { // require a URL
              window.location ="course_group.php?groupid=" + url; // redirect
          }
          return false;
      });
    });

//  $(document).ready(function(){
//  $("#search_user").keyup(function(){ 
//        var search = $(this).val();
//        if (search != '') {
//        	$.ajax({
//        		url: "get_search_users.php",
//        		method: "POST",
//        		data: { search:search},
//        		success:function(data){
//        			console.log(data);
//        			$("#show1").fadeIn("fast").html(data);
//        		}
//        	});
//        }else{
//        	$("#show1").fadeOut();
//        }
// });

//  });

 $(document).ready(function(){
 $("#search_user").keyup(function(){ 
       var search = $(this).val();
       jQuery.ajax({
        type: 'POST',
        data_type:'html',
       url:"get_search_users.php",
        data:{search:search},
        success: function(data) {
           $('#show1').html(data);
        },
       
    });
});

 });
 
</script>

<?php
}
else{
   echo "You cannot edit this page! Only BM can manage course package groups ";
}
echo $OUTPUT->footer();

