<?php

require_once('../../config.php');


$gid=$_GET['id'];
if(!empty($gid))
{
	$recordwithout = $DB->get_record('course_groups', array('id' => $gid), '*');
	$recordwithout->deleted = 1;
	$res = $DB->update_record('course_groups', $recordwithout);
}
if($res)

{

	header('location:manage_group.php');

}

else

{

	echo"Error in Deletion";

}

?>