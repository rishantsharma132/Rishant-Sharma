<?php 
require_once('../../config.php');
global $DB, $USER;
$search=$_POST['search'];
$company_id=$DB->get_record_sql("SELECT * from {company_users} where userid=$USER->id");
$compnay_course = $DB->get_records_sql("SELECT c.id, c.fullname from {course} c JOIN {company_course} cc on c.id=cc.courseid where c.fullname LIKE '$search%'  AND cc.companyid=$company_id->companyid AND c.category!=985 AND c.visible=1 ORDER BY c.fullname ASC");
foreach ($compnay_course as $key_course) {
$courseid=$key_course->id;
        $contextid = context_course::instance($courseid);
        $get_roles=$DB->get_record('role_assignments', array('contextid' => $contextid->id, 'userid' => $USER->id));
     
            echo "<tr><td><input type = 'checkbox' name = 'radio[]'  value='".$courseid."' /></td>"; 
            echo "<td>".$key_course->fullname."</td></tr>";
    }