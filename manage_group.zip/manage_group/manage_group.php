<?php 
require_once('../../config.php');

require($CFG->dirroot.'/blocks/manage_group/classes/forms/manage_group_form.php');
require($CFG->dirroot.'/blocks/manage_group/locallib.php');

global $DB, $USER, $CFG;

redirect_if_major_upgrade_required();
require_login();

$context = context_system::instance();
$companyid1 = iomad::get_my_companyid($context);

$urlparams = array();

if (!empty($CFG->defaulthomepage) && ($CFG->defaulthomepage == HOMEPAGE_MY) && optional_param('redirect', 1, PARAM_BOOL) === 0) {

    $urlparams['redirect'] = 0;
  //  redirect($CFG->wwwroot . '/blocks/manage_group/manage_group.php','Your record successfully Updated');

}


$PAGE->set_course($SITE); 

$PAGE->set_url('/', $urlparams);

$PAGE->set_title('Manage Groups');

$PAGE->set_pagelayout('sidebar');

$PAGE->set_heading('Manage Groups');

$PAGE->requires->js_call_amd('block_manage_group/getpreview', 'init');
echo $OUTPUT->header();

?>
<div class="main-wrapper" style="margin-bottom: 20px">
<?php
  $companyid=$DB->get_record_sql("SELECT companyid as comid from {company_users} 
  WHERE userid=$USER->id AND managertype =  1 ");
if ($companyid){


?>

<!-- <a href="<?php echo $CFG->wwwroot;?>/my" class="btn btn-primary">BACK</a> -->

<?php

$mform = new manage_group_form();

if ($mform->is_cancelled()) {
    echo "You did not fill in the data correctly."; // Corrected message
} else if ($fromform = $mform->get_data()) {

  // echo "<pre>";
  // print_r($fromform);  
  // exit();
  
    // Prepare data for insertion
    
    $record = new stdClass();
    $record->name = $fromform->group_name;
    $record->companyid = $companyid->comid;
    $record->bm_user_id = $USER->id;
    $record->deleted = $fromform->delete;
    // $fromform->calendar_year
    $record->type = $fromform->type;
    $record->calendar_year = $fromform->calendar_year;
    
    $a = $fromform->due_type;
    $b = $fromform->due_number;


    $c = $a . ' ' . $b;

    $record->training_duration = $c;

    
  // $record->training_duration = $fromform->training_duration;

    $record->due_date_duration = $fromform->duedate;
    $record->hours_required = $fromform->hours_required;
   
    $string_version = implode(',', $fromform->groupassignlist);

    $record->employee_group = $string_version;

    $course = implode(',', $fromform->courselist);
    $record->course_list = $course;
    
    $record->assign_new_year = $fromform->assign_new_year;
    $record->assign_new_employees = $fromform->assign_new_employees;

    $result1 = $DB->insert_record('course_groups', $record);
   // 
    $courseobj = $DB->get_record('course', array('id' => $courseid));
    $record2 = new stdClass();

    $record2->bm_id = $USER->id;

     $record2->master_tpl_id = 0;
     $record2->task_description =  $fromform->group_name;
     $record2->task_status ='Open'; 
     $record2->task_name = $fromform->group_name;
     $record2->created_date = time();

     $record2->course_id =  $courseid;
     
    //  $string_version = implode(',', $fromform->groupassignlist);
     $record2->group_assign = $string_version;

     $record2->category = $fromform->type;
     $record2->due_type = $fromform->due_type;

     $record2->due_date = $fromform->due_number;

    $record2->packaged = $result1;
    $record2->parent_tsk = 0;
    $parentid = $DB->insert_record('bm_task_list', $record2);
// 
    $co=1;
    $totalcourses = count($fromform->courselist);
    foreach($fromform->courselist as $courseid){
    
     $courseobj = $DB->get_record('course', array('id' => $courseid));
  
     $record1 = new stdClass();
     $record1->bm_id = $USER->id;

     $record1->master_tpl_id = 0;
     $record1->task_description =  $courseobj->fullname;
     $record1->task_status ='Open'; 
     $record1->task_name = $fromform->group_name;
     $record1->created_date = time();

     $record1->course_id =  $courseid;

     $record1->group_assign = $string_version;

     $record1->category = $fromform->type;
     $record1->due_type = $fromform->due_type;

     $record1->due_date = $fromform->due_number;
     ///

 
   $duedate = get_custom_duedate($fromform->type,$fromform->duedate,$totalcourses,$fromform->calendar_year,$co);
    //  echo "<br>--".$co.'--<br>';
      $record1->custom_due_date = $duedate;
   
     ///
     $record1->parent_tsk = $parentid;
     $record1->packaged = $result1;

      $co= $co+1;
      $result = $DB->insert_record('bm_task_list', $record1);

     
   }

  //  redirect($CFG->wwwroot .'/'. $CFG->admin .'/manage_course.php');
   redirect($CFG->wwwroot . '/blocks/manage_group/manage_group.php','Package Created successfully');
   
}

    $mform->set_data($toform);
    $mform->display();
    
  }
  else{
     echo "You cannot manage this page! Only BM can manage the courses ";
     
  }
  
echo $OUTPUT->footer();