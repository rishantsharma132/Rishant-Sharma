define(['jquery', 'core/ajax', 'core/str', 'core/templates'], function ($, AJAX, str, templates) {
    return {
        init: function () {
            this.addPreviewButtonListener();
            this.addRadioListeners();
            $('#myTable').hide();
            $('#annualTable').hide();
        },

        addPreviewButtonListener: function () {
            $(document).on('click', '#showTableBtn', function () {
                var courseids = JSON.stringify($("#id_courselist").val());
                var due_type = $("#id_due_type").val();
                var due_number = $("#id_due_number").val();
                var groupassignlist = JSON.stringify($("#id_groupassignlist").val());
                var selectedType = $("input[name='type']:checked").val();
                var quarterly = $("input[name='duedate']:checked").val() || 0;
                var duedate = {
                    quarterly: quarterly
                };
                var calendar_year = $("#id_calendar_year").val();

                var promise = AJAX.call([{
                    methodname: 'blocks_manage_group_get_course_data',
                    args: {
                        courseids: courseids,
                        groupassignlist: groupassignlist,
                        due_type: due_type,
                        due_number: due_number,
                        table_type: selectedType,
                        duedate: duedate,
                        calendar_year: calendar_year,
                    }
                }]);
                
                promise[0].done(function (json) {
                    var data = JSON.parse(json);

                    if (selectedType == 'annual') {
                        var annualContext = {
                            annualTable: data
                        };
                
                        templates.render('block_manage_group/user_list', annualContext).then(function (html, js) {
                            $('#annualTable tbody').html(html);
                            $('#myTable').hide();
                            $('#annualTable').show();
                        });
                    } else if (selectedType == 'initialtraining') {
                        var initialTrainingContext = {
                            tabledata: data
                        };
                
                        templates.render('block_manage_group/user_list', initialTrainingContext).then(function (html, js) {
                            $('#myTable tbody').html(html);
                            $('#myTable').show();
                            $('#annualTable').hide();
                        });
                    }
                });
                
            });
        },

        addRadioListeners: function () {
            $(document).on('change', 'input[name="type"]', function () {
                var selectedType = $(this).val();
                if (selectedType === 'annual') {
                    $('#myTable').hide();
                    $('#annualTable').show();
                } else if (selectedType === 'initialtraining') {
                    $('#myTable').show();
                    $('#annualTable').hide();
                }
            });
        }
    };
});
