<?php
// This file is part of Moodle - http://moodle.org/
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * This block allows the user to give the course a rating, which
 * is displayed in a custom table (<prefix>_block_rate_course).
 *
 * @package    recent_access
 * @subpackage reportes
 * @copyright  2018 Pal infocom 
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die;

require_once($CFG->libdir . '/formslib.php');

class filter_form extends moodleform {

    public function definition() {
        $startdate = optional_param('startdate', 0, PARAM_INT);
        $enddate = optional_param('enddate', 0, PARAM_INT);
        $companyname = optional_param('company', 0, PARAM_INT);
        $companyn = self::get_search_areas_list();                                                                                                                            
        $options = array(                                                                                                           
            'multiple' => false,                                                  
            'noselectionstring' => get_string('allusers', 'search'),                                                                
        );         
        $mform =& $this->_form;
        $mform->addElement('autocomplete', 'company', get_string('select_company','block_manage_group'), $companyn, $options);
        if ($companyname) {
            $mform->setDefault('company',  $companyname);
            }
        $mform->addElement('date_selector', 'from_date', get_string('fromtrx_date', 'block_manage_group'), ['optional' => true]);
        $mform->setType('trx_date', PARAM_TEXT);  
        if ($startdate) {
            $mform->setDefault('from_date',  $startdate);
            }  
        $mform->addElement('date_selector', 'to_date', get_string('totrx_date', 'block_manage_group'), ['optional' => true]);
        $mform->setType('trx_date', PARAM_TEXT);
        if ($enddate) {
            $mform->setDefault('to_date',  $enddate);
            } 
        $this->add_action_buttons(false,  get_string('submitbutton','block_manage_group'));
    }
    public function get_search_areas_list(){
        global $DB;
        $urs =array();
        $urs[''] = get_string('allusers','block_manage_group');
        $users = $DB->get_records_sql("SELECT id,name as namess FROM {company} ORDER BY namess ASC");
        foreach ($users as $user ) {                                                                          
            $urs[$user->id] = $user->namess;                                                                  
        }
        return $urs;
    }
    function validation($data, $files){ 
        global $DB; 
        $errors = parent::validation($data, $files);  
        $now = time();  
        $startdate = $data['from_date'];  
        $enddate = $data['to_date']; 
        $classtime = $data['class_start'];  
        $course = $data['course'];  
        if ($enddate < $startdate && $enddate > 0) {  
            $errors['to_date'] = get_string('notfy', 'block_manage_group');  
        } 
         
        return $errors;  
    }
}