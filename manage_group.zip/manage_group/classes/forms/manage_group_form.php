<?php
// This file is part of Moodle - http://moodle.org/
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * This block allows the user to give the course a rating, which
 * is displayed in a custom table (<prefix>_block_rate_course).
 *
 * @package    recent_access
 * @subpackage reportes
 * @copyright  2018 Pal infocom 
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die;

require_once($CFG->libdir . '/formslib.php');


// print_r($group_data);
// exit();
class manage_group_form extends moodleform {
    

        protected $formdata;
        function definition() {

            global $CFG, $PAGE, $DB;
                    
        $id = optional_param('id', 0, PARAM_INT); 

        if ($id) {
            $pageparams = array('id' => $id);
        } 

        $group_data = $DB->get_record('course_groups', array('id' => $id));


            $mform = $this->_form;
            $formdata   = $this->_customdata['formdata'];
        //  crete a group name   
            $mform->addElement('text', 'group_name', get_string('packagename', 'block_manage_group'));
            $mform->setType('group_name', PARAM_TEXT);
            $mform->addRule('group_name', null, 'required', null, 'client');
            $mform->setDefault('group_name', $group_data->name);
            $mform->addElement('hidden', 'bm_id', $USER->id);
            $mform->addElement('hidden', 'delete', '0');
            $mform->addElement('hidden', 'id', $id);



        // Divide in the three options
            $radioarray=array();
            $radioarray[] = $mform->createElement('radio', 'type', '',  'Annual (12 Months)', 'annual', $attributes);
            $radioarray[] = $mform->createElement('radio', 'type', '',  'Initial Training', 'initialtraining', $attributes);
            $radioarray[] = $mform->createElement('radio', 'type', '',  'Multi-Step Plan', 'multistepplan', $attributes);
            $mform->addGroup($radioarray, 'radioar', 'Type', array(' '), false);
            $mform->setDefault('type', $group_data->type);
            $mform->addRule('radioar', null, 'required', null, 'client');

        // create a calender to show the Year 
            $years = array();
            $current_year = date('Y');
            $years_range = range($current_year - 20, $current_year + 30); 
            foreach ($years_range as $year) {
                $years[$year] = $year;
            }

            $mform->hideIf('calendar_year', 'type', 'neq', 'annual');
            $mform->setDefault('calendar_year', $group_data->calendar_year ?? $current_year); 
            $mform->addElement('select', 'calendar_year', get_string('selectcalendaryear', 'block_manage_group'), $years);

        // When we have click on the annual it will show these options
            $radioarray=array();
            $radioarray[] = $mform->createElement('radio', 'duedate', '',  'Quarterly', 'quarterly', $attributes);
            $radioarray[] = $mform->createElement('radio', 'duedate', '',  'Semi-Annual', 'semiannual', $attributes);
            $radioarray[] = $mform->createElement('radio', 'duedate', '',  'Annual', 'annualduration', $attributes);
            $mform->addGroup($radioarray, 'duedater', 'Due Date Duration', array(' '), false);  
            $mform->hideIf('duedater', 'type', 'neq', 'annual');
            $mform->setDefault('duedate', $group_data->due_date_duration);
            
        //This is the due date field in the initial plan
            $mform->addElement('html', '<div style="display:flex;">');

                // Add the select element
                $mform->addElement('select', 'due_type', get_string('selecttrainingduration', 'block_manage_group'), array(
                    '' => get_string('selectany', 'block_manage_group'),
                    'days' => get_string('days', 'block_manage_group'),
                    'months' => get_string('months', 'block_manage_group'),
                    'years' => get_string('years', 'block_manage_group')
                ));
                $mform->hideIf('due_type', 'type', 'neq', 'initialtraining');
                $mform->setDefault('due_type', $group_data->training_duration);

                $mform->addElement('text', 'due_number', '', array('placeholder' => 'dd/mm/yy'));
                $mform->hideIf('due_number', 'type', 'neq', 'initialtraining');

                $mform->setDefault('due_number', $group_data->training_duration);

                $mform->addElement('html', '</div>');

        // These are two option we have added 
            // $mform->addElement('text', 'hours_required', get_string('howmanyhours', 'block_manage_group'));
            // $mform->setType('hours_required', PARAM_NUMBER);
            // $mform->addRule('hours_required', get_string('required'), 'required', null, 'client');
            // $mform->setDefault('hours_required', $group_data->hours_required);

        // here we have get the Employee type
                global $DB;

                $query1 = $DB->get_records_sql("SELECT id, name FROM {task_groups}");

                $groupOptions = array();

                foreach ($query1 as $key1) {

                    $groupOptions[$key1->name] = $key1->name;
                }
                
                $options = array(
                    'multiple' => true,
                    'noselectionstring' => get_string('selectemployeetype', 'block_manage_group'),
                );

                $mform->addElement('autocomplete', 'groupassignlist', get_string('selectemployeetype', 'block_manage_group') , $groupOptions, $options);
                $mform->setDefault('groupassignlist', $group_data->employee_group);


            // Here we have added the two checkups
                // $mform->addElement('advcheckbox', 'assign_new_year', get_string('assignonnewyear', 'block_manage_group'));
                // $mform->setDefault('assign_new_year', $group_data->assign_new_year);

                $mform->addElement('advcheckbox', 'assign_new_year', get_string('assignonnewyear', 'block_manage_group'));
                $mform->setDefault('assign_new_year', $group_data->assign_new_year);
                $mform->addRule('assign_new_year', null, 'callback', 'assign_task_to_company_users', 'client');

                function assign_task_to_company_users($value) {
                    global $mform, $DB, $USER;

                    if ($value) {
                        $companyid = $USER->companyid; 
                        
                        if ($companyid) {
                            $task_name = $mform->getElement('group_name')->getValue(); 
                            $task_id = $DB->get_field('course_groups', 'id', array('name' => $task_name, 'companyid' => $companyid));
                            

                            if ($task_id) {
                                $company_users = $DB->get_records('company_users', array('company_id' => $companyid));
                                
                                foreach ($company_users as $user) {
                                    assign_task($task_id, $user->userid);
                                }
                            } else {
                                
                            }
                        } else {
                            
                        }
                    }

                    return true;
                }

                //
        
                $mform->addElement('advcheckbox', 'assign_new_employees', get_string('assigntonewemployees', 'block_manage_group'));
                $mform->setDefault('assign_new_employees', $group_data->assign_new_employees);
                
                $mform->addElement('header', 'header_course_assign', 'Assign/Unassign Courses');

            // Here we have get the the Unassign courses 

            global $DB, $USER;
            $searchareas = \core_search\manager::get_search_areas_list(true);
            $areanames = array();
            
            $companyid = $DB->get_record_sql("SELECT companyid as comid FROM {company_users} WHERE userid = ?", array($USER->id));
            $all_unassign_courses = $DB->get_records_sql("SELECT c.id, c.fullname FROM {course} c
                JOIN {company_course} cc ON c.id = cc.courseid
                WHERE cc.companyid = ? AND c.category != 985 AND c.visible = 1 $coursewhere22
                ORDER BY c.fullname ASC", array($companyid->comid));
            
            foreach ($all_unassign_courses as $unassign_course) {
                if (isset($_GET['groupid'])) {
                    $groupid = $_GET['groupid'];
                    $get_tasks = $DB->get_records_sql("SELECT * FROM {assign_group_package_course} WHERE bm_id = ? AND courseid = ? AND course_group_id = ?", array($USER->id, $unassign_course->id, $groupid));
                } else {
                    $get_tasks = $DB->get_records_sql("SELECT * FROM {assign_bulk_course} WHERE bm_id = ? AND courseid = ?", array($USER->id, $unassign_course->id));
                }
            
                if (!$get_tasks) {
                    $areanames[$unassign_course->id] = $unassign_course->fullname;
                }
            }
            
            $options = array(
                'multiple' => true,
                'noselectionstring' => 'Course List',
            );

            if (!empty($group_data->assign_new_employees)) {
                $selected_course_ids = explode(',', $group_data->course_list);
               
            }
            
            if ($mform->isSubmitted()) {
                $data = $mform->getData();
                $selected_course_ids = $data['courselist'];
                $selected_courses = array();
            
                foreach ($selected_course_ids as $selected_course_id) {
                    if (isset($areanames[$selected_course_id])) {
                        $selected_courses[] = $areanames[$selected_course_id];
                    }
                }
            }
            $mform->addElement('autocomplete', 'courselist', 'Course List', $areanames, $options);
            $mform->setDefault('courselist', $group_data->course_list);

            // This is the preview button 
                $mform->addElement('button', 'showTableBtn', 'Preview', array('id' => 'showTableBtn', 'style' => 'margin-left: 350px;'));

            // Here we have create a Initial table when click on the Preview button
                $mform->addElement('html', '<table id="myTable" style="display: none;">');
                $mform->addElement('html', '<thead><tr>
                                        <th>' . 'Course Selection'. '</th>
                                        <th>' . 'Employee Group' . '</th>
                                        <th>' . 'Hours' . '</th>
                                        <th>' . 'Due Date' . '</th>
                                    </tr></thead><tbody class="coursesdata">
                                    </tbody></table>');   

            // Here we have create a Annual table when click on the Preview button
                $mform->addElement('html', '<table id="annualTable" style="display: none;">');
                $mform->addElement('html', '<thead><tr>
                                        <th>' . 'Quarter' . '</th>
                                        <th>' . 'Assign Courses' . '</th>
                                        <th>' . 'Hours' . '</th>
                                        <th>' . 'End Date' . '</th>
                                     </tr></thead><tbody class="coursesdata">');
                                    
                                    
                $mform->addElement('html', '</tbody></table>');
                                    
                $this->add_action_buttons();
                // redirect($CFG->wwwroot . '/blocks/manage_group/manage_group.php', 'Sucess');
               
            }   
   
    }
    