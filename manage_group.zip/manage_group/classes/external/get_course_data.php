<?php

namespace blocks_manage_groups\external;

defined('MOODLE_INTERNAL') || die();

use external_function_parameters;
use external_value;


/**
 * Trait implementing the external function local_edwiserbridge_course_progress_data
 */
class get_course_data{

    public static function get_course_data_is_allowed_from_ajax() {
        return true;
    }    
   
    /**
     * Paramters defined for create service function.
     */
    public static function get_course_data_parameters() {
        return new external_function_parameters([
            'courseids' => new external_value(PARAM_RAW, 'Course Selection'),
            'groupassignlist' => new external_value(PARAM_RAW, 'Employee List'),
            'due_type' => new external_value(PARAM_RAW, 'type'),
            'due_number' => new external_value(PARAM_INT, 'Due Date')
        ]);
    }
    
    public static function get_course_data($courseids,$groupassignlist,$due_type,$due_number) {
        global  $DB;
        $return =array();
        $coursearr = explode($courseids);
        foreach($coursearr as $courseid){
            $new = array();
            $course = $DB->get_record('course', array('id' => $courseid));
            $query = "SELECT cd.value as dvalue
            FROM {customfield_data} cd
            WHERE fieldid = ? AND instanceid = ?";
            $dueDates = $DB->get_records_sql($query, array(1, $courseid));
            if ($dueDates) {
                foreach ($dueDates as $dueDate) {
                    $hours =  $dueDate->dvalue;
                }
            } else {
                $hours = 0;
            }
            $new['coursename'] = $course->fullname;
            $new['coursehours'] = $hours;
            $new['groupassign'] = $groupassignlist;
            $new['duedate'] = time();
            $return[] = $new;
        }
        return $return;
        
    }

    public static function get_course_data_returns() {
        return new external_value(PARAM_RAW, 'Comment Link');
    }

   
}


