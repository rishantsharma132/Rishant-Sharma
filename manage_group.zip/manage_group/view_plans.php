<?php 
require_once('../../config.php');
global $DB, $USER, $CFG;

redirect_if_major_upgrade_required();

require_login();

$context = context_system::instance();
$companyid1 = iomad::get_my_companyid($context);

$urlparams = array();

if (!empty($CFG->defaulthomepage) && ($CFG->defaulthomepage == HOMEPAGE_MY) && optional_param('redirect', 1, PARAM_BOOL) === 0) {

    $urlparams['redirect'] = 0;

}

$PAGE->set_course($SITE); 

$PAGE->set_url('/', $urlparams);

$PAGE->set_title('View Plans');

$PAGE->set_pagelayout('sidebar');

$PAGE->set_heading('View Plans');

echo $OUTPUT->header();

?>
<div class="main-wrapper" style="margin-bottom: 20px">
<?php
  $companyid=$DB->get_record_sql("SELECT userid as comid from {company_users} 
    where userid=$USER->id AND managertype =  1 ");
if ($companyid){

if(isset($_POST['submit']))

{

  $groupname=$_POST['group_name'];
  $bm_id=$_POST['bm_id'];
  $delete=$_POST['delete'];
  $record = new stdClass();
  $record->name= $groupname;
  $record->companyid = $companyid1;
  $record->bm_user_id = $bm_id;
  $record->deleted = $delete;
  

  $result1 = $DB->insert_record('course_groups', $record);

  if ($result1) {
    echo "Data inserted successfully";
  } else {
      echo "Error in insertion";
  }

}

?>

<div id="main">
<a href="<?php echo $CFG->wwwroot;?>/my" class="btn btn-primary">BACK</a>

 	  <!-- <h3>Manage Group</h3> -->

 	  <!-- <form method="POST">

          <div class="form-control">

          	   <label>Group Name</label>
               <input type="text" name="group_name" required>
               <input type="hidden" name="bm_id" value="<?php echo $USER->id ?>">
               <input type="hidden" name="delete" value="0">
               <input type="submit" name="submit" value="Add">

          </div>


     </form> -->

 </div>	

 <div id="group_table">

    <h3>All Groups</h3>

      <table>

        <tr>

          <th>Packages Name</th>

          <!-- <th>View</th> -->
          <th>Edit</th>
          <th>Delete</th>

            

        </tr> 

<?php

$result=$DB->get_records_sql("SELECT * from mdl_course_groups WHERE bm_user_id = $USER->id AND deleted = 0");

foreach($result as $key)
{ 
?>
        <tr>

            <td><?php echo $key->name; ?></td>
           <!--  <td><a href="<?php echo $CFG->wwwroot;?>/blocks/taskmanager/view-group.php?name=<?php echo $key->name; ?>">View</a></td>
 -->
             <td><a href="edit_course_group.php?id=<?php echo $key->id; ?>"><button type="button" class="green-button">Edit</button></a></td>
             <td><a href="delete_course_group.php?id=<?php echo $key->id; ?>"><button type="button" class="red-button">Delete</button></a></td>
<?php

}

?>
        </tr> 
      </table>
 </div> 
</div>
<?php
}
else{
   echo "You cannot edit this page! Only BM edit this page";
}


echo $OUTPUT->footer();