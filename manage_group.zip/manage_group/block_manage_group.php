<?php
class block_manage_group extends block_base 
{
    public function init() 
    {
        $this->title = get_string('pluginname', 'block_manage_group');
    }
    public function get_content() {
       global  $DB, $USER,$PAGE,$SESSION,$CFG,$OUTPUT;
                            $this->content = new stdClass();        
                        if (is_siteadmin()) {
                            $this->content->text .= html_writer::start_tag("ul");
                            $this->content->text .= html_writer::start_tag("li");
                            $this->content->text .= "<a href='$CFG->wwwroot/blocks/manage_group/all_company.php' target='_blank'>";
                            $this->content->text .= get_string('companycontract', 'block_manage_group');
                            $this->content->text .= "</a>";
                            $this->content->text .= html_writer::end_tag("li");
                            $this->content->text .= html_writer::end_tag("ul");
                        }
                            return $this->content;
    }
    function has_config() {
         return true;
    }

}