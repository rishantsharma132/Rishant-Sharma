<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * enrolment plugin version specification.
 *
 * @package    block_manage_group
 * @copyright  2021 Elearning Stack
 * @author     Eugene Venter
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once('../../config.php');
 require($CFG->dirroot.'/blocks/manage_group/classes/forms/filterform.php');
require_login();
global $DB, $PAGE;
$id = optional_param('id', 0, PARAM_TEXT);
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url('/blocks/manage_group/all_company.php');
$PAGE->set_heading(get_string('headername', 'block_manage_group'));
$PAGE->set_title(get_string('headername', 'block_manage_group'));
$PAGE->set_pagelayout('admin');
$PAGE->navbar->add(get_string('headername', 'block_manage_group'));
echo $OUTPUT->header();
if (is_siteadmin()) {
    $startdate=0;
    $enddate=0;
    $mform = new filter_form();
     if ($fromform = $mform->get_data()) {
        $fromfilter = $fromform->from_date;
        $tofilter = $fromform->to_date;
        if($fromform->company){
            $company= $fromform->company;
        }
        else{
            $company= 0;
        }
        $mform->display();
        echo "<h1>".get_string('headername','block_manage_group')."</h1>";
        $renderer = $PAGE->get_renderer('block_manage_group');
        echo $renderer->allcompany($fromfilter,$tofilter,$company);
    } else {
        $startdate = optional_param('startdate', 0, PARAM_INT);
        $startdate= strtotime(" ", $startdate); 
        $enddate = optional_param('enddate', 0, PARAM_INT);
        $enddate= strtotime(" ", $enddate); 
        $company = optional_param('company', 0, PARAM_INT);
        $mform->display();
        echo "<h1>".get_string('headername','block_manage_group')."</h1>";
        $renderer = $PAGE->get_renderer('block_manage_group');
        echo $renderer->allcompany($startdate,$enddate,$company);
    }
    }else{
        redirect($CFG->wwwroot, 'Sorry,Only admin user can view this page', null, \core\output\notification::NOTIFY_SUCCESS);
    }
echo $OUTPUT->footer();
?>  