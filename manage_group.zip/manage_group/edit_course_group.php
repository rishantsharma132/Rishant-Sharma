<?php 
require_once('../../config.php');
global $DB, $USER, $CFG;

require($CFG->dirroot.'/blocks/manage_group/classes/forms/manage_group_form.php');

require_login();

$PAGE->set_title('Edit Course Group');

$PAGE->set_pagelayout('sidebar');

$PAGE->set_heading('Edit Course Group');

echo $OUTPUT->header();

$gid=$_GET['id'];
?>
<div class="main-wrapper">
  
<div class="main">
<?php
if(isset($_POST['submit']))
 {      
    $gname=$_POST['grpname'];

    $new=$_POST['id'];

  redirect($CFG->wwwroot . '/blocks/manage_group/manage_group.php','Your record successfully Updated');

}
$result = $DB->get_record('course_groups', array('id' =>$gid));
?>


<?php
  $companyid=$DB->get_record_sql("SELECT companyid as comid from {company_users} 
  WHERE userid=$USER->id AND managertype =  1 ");
if ($companyid){




$mform = new manage_group_form();

if ($mform->is_cancelled()) {

} else if ($fromform = $mform->get_data()) {

  $record = new stdClass();

  $record->id = $fromform->id;

  $record->name = $fromform->group_name;
  $record->companyid = $companyid->comid;
  $record->bm_user_id = $USER->id;
  $record->deleted = $fromform->delete;
  // $fromform->calendar_year
  $record->type = $fromform->type;
  $record->calendar_year = $fromform->calendar_year;
  
  $a = $fromform->due_type;
  $b = $fromform->due_number;


  $c = $a . ' ' . $b;

  $record->training_duration = $c;

  
// $record->training_duration = $fromform->training_duration;

  $record->due_date_duration = $fromform->duedate;
  $record->hours_required = $fromform->hours_required;
 
  $string_version = implode(',', $fromform->groupassignlist);

  $record->employee_group = $string_version;

  $course = implode(',', $fromform->courselist);
  $record->course_list = $course;
  
  $record->assign_new_year = $fromform->assign_new_year;
  $record->assign_new_employees = $fromform->assign_new_employees;
  // echo'<pre>';
  // print_r($record);
  // exit();
  $result1 = $DB->update_record('course_groups', $record);
 

  // foreach($fromform->courselist as $courseid){
    
  //   $courseobj = $DB->get_record('course', array('id' => $courseid));
  
  //    $record1 = new stdClass();
  //    $record1->bm_id = $USER->id;

  //    $record1->master_tpl_id = 0;
  //    $record1->task_description =  $courseobj->fullname;
  //    $record1->task_status ='Open'; 
  //    $record1->task_name = $fromform->group_name;
  //    $record1->created_date = time();

  //    $record1->course_id =  $courseid;

  //    $record1->group_assign = $string_version;

  //    $record1->category = $fromform->type;
  //    $record1->due_type = $fromform->due_type;

  //    $record1->due_date = $fromform->due_number;
  //    ///

 
  //  $duedate = get_custom_duedate($fromform->type,$fromform->duedate,$totalcourses,$fromform->calendar_year,$co);
  //   //  echo "<br>--".$co.'--<br>';
  //     $record1->custom_due_date = $duedate;
   
  //    ///
  //    $record1->parent_tsk = $parentid;
  //    $record1->packaged = $result1;

  //     $co= $co+1;
  //     $result = $DB->update_record('bm_task_list', $record1);
  // }
 
  redirect($CFG->wwwroot . '/blocks/manage_group/view_plans.php','Package Created successfully');
    $mform->set_data($toform);

} 

    $mform->set_data($toform);
    $mform->display();
}
?>

 <div class="editbutton">
 	 <form class="edit-groups" action="edit_course_group.php" method="POST">
 	 	
 	 	
        <!-- <label class="all-group">Name:</label> -->
          <!-- <input class="master" type="text" name="grpname"  placeholder="Group name" value="<?php echo $result->name; ?>"> -->
       <!-- <input class="st-bt" type="submit" name="submit" value="Update" style="margin-top: 0px;">
       <input name="id"  type="hidden" value="<?php echo $gid ?>" title="Remove"> -->
  </form>

  <!-- New add feacture in this page -->
  <!-- <div id="group_table">

  <h3>All Groups</h3>

    <table>

      <tr>

        <th>Group Name</th>

        <th>View</th>
        <th>Edit</th>
        <th>Delete</th>

          

      </tr> 

  <?php

  $result=$DB->get_records_sql("SELECT * from mdl_course_groups WHERE bm_user_id = $USER->id AND deleted = 0");

  foreach($result as $key)
  { 
  ?>
      <tr>

          <td><?php echo $key->name; ?></td>
         <td><a href="<?php echo $CFG->wwwroot;?>/blocks/taskmanager/view-group.php?name=<?php echo $key->name; ?>">View</a></td>
 
          <td><a href="edit_course_group.php?id=<?php echo $key->id; ?>"><button type="button" class="green-button">Edit</button></a></td>
          <td><a href="delete_course_group.php?id=<?php echo $key->id; ?>"><button type="button" class="red-button">Delete</button></a></td>
  <?php

  }

  ?>
      </tr> 
    </table>
  </div>  -->
  <!-- New add feacture in this page -->
</div>
</div>
</div>
<?php
echo $OUTPUT->footer();