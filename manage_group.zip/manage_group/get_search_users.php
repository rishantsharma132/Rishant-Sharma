<!-- <?php 
require_once('../../config.php');
global $DB, $USER;
$search_data=$_POST['search'];

$group_data = $DB->get_records_sql("SELECT * FROM {course_groups} WHERE name LIKE '%$search_data%' ");


$output = "<ul>";
if ($group_data > 0) {
	
		
	foreach ($group_data as $value) {
		$output .= "<li><a href='course_group.php?groupid=".$value->id."'>".$value->name."</a> </li>";
	}
		
	
	
	
		
}else{
	$output .= "<li>Group Not Found<li>";
}
$output .= "</ul>";
echo $output;
?> -->
<?php 
require_once('../../config.php');
global $DB, $USER;
$search=$_POST['search'];
$companyid=$DB->get_record_sql("SELECT * from {company_users} where userid=$USER->id");
$select_cohort = $DB->get_records_sql("SELECT u.* FROM {user} u INNER JOIN {company_users} cu on u.id=cu.userid 
WHERE cu.companyid=$companyid->companyid AND (CONCAT(u.firstname, ' ', u.lastname)) LIKE '$search%'ORDER BY u.firstname ASC");
 foreach ($select_cohort as $user){
 ?>
  <option value="<?php echo $user->id; ?>"><?php echo  $user->firstname.' '.$user->lastname; ?></option>
  <?php
}

?>
