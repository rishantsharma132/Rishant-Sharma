<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

require_once('../../config.php');
require_login();
class block_manage_group_renderer extends plugin_renderer_base {

public function allcompany($fromfilter=0,$tofilter=0,$company=0) {
        global $CFG, $DB, $OUTPUT;
        $baseurl = new moodle_url($this->url, array('startdate' => $fromfilter, 'enddate' => $tofilter,'company' => $company));
        $page = optional_param('page', 0, PARAM_INT);
        $limit = 10;
        $perpage = $page * $limit;
            $table = new html_table();
            $table->head = array(
              get_string('serialno', 'block_manage_group'), 
              get_string('companyname', 'block_manage_group'), 
              get_string('Contractenddate', 'block_manage_group'),
              get_string('companystatus', 'block_manage_group'),
            );
            $count=$perpage+1; 
            if ($company) {
              $query = ' id = ' . $company;
          }
          if ($fromfilter) {
              $query = ' validto >= ' . $fromfilter; 
          } 
          if ($tofilter) {
              $enddate= strtotime("+1 day", $tofilter);
              $query = ' validto <= ' . $enddate; 
          }  
          if ($fromfilter && $tofilter) {
              $enddate= strtotime("+1 day", $tofilter);
              $query = ' validto BETWEEN ' . $fromfilter . ' AND ' .$enddate; 
          } 
          if ($fromfilter && $company) {
              $query = ' id = ' . $company . ' AND validto >= ' . $fromfilter; 
          } 
          if ($tofilter && $company) {
              $enddate= strtotime("+1 day", $tofilter);
              $query = ' id = ' . $company . ' AND validto <= ' . $enddate; 
          }
          if ($fromfilter && $tofilter && $company) {
              $enddate= strtotime("+1 day", $tofilter);
              $query = ' id = ' . $company . ' AND validto between ' . $fromfilter . ' AND ' .$enddate; 
          }
          if ($query) {
            $com ="SELECT id,name as namess,validto,suspended FROM {company} WHERE $query
            ORDER BY id DESC";
          }else{
            $com ="SELECT id,name as namess,validto,suspended FROM {company} ORDER BY namess ASC";
          }
          $qsss = $DB->get_records_sql($com);
          $totalcount = count($qsss);
          $com .= " LIMIT $perpage,$limit ";
          $companys = $DB->get_records_sql($com);
            
            foreach ($companys as $co) {
                 $companyname =  $co->namess;
                 $Contractenddate = $co->validto;
                 if ($Contractenddate == 0) {
                   $enddate = get_string('enddaenofound', 'block_manage_group');
                 }else{
                  $enddate = date('l, d F Y, h:i:s A', $co->validto);
                 }
               
                  $suspended =  $co->suspended;
                  if ($suspended == 0) {
                    $status = get_string('active', 'block_manage_group');
                  }else{
                    $status = get_string('suspended', 'block_manage_group');
                  }
             $table->data[] = array(
              'serialno' => $count++,
              'course_name' => $companyname,
              'Contractenddate' => $enddate,
              'companystatus' => $status,
             );
}


echo "<h2>".get_string('total_users', 'block_manage_group')."  $totalcount</h2>" ;
 echo html_writer::table($table);
 if(!$companys){
  echo "<h1 style='color:red'>".get_string('norecordfound', 'block_manage_group')."</h1>" ;
}
 echo $OUTPUT->paging_bar($totalcount, $page, $limit, $baseurl);
 echo '<a href="'.$CFG->wwwroot.'/blocks/manage_group/all_company_csv.php?company='.$company.'&startdate='.$fromfilter.'&enddate='.$tofilter.'&totaluser='.$totalcount.'" id="export" role="button" class="btn btn-primary" style="margin-right:50px;" >
 '.get_string('download_csv', 'block_manage_group').'
  </a>';
}

  }
?>
 