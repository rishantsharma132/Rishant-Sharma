<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Iomad External Web Services
 *
 * @package   block_iomad_company_admin
 * @copyright 2021 Derick Turner
 * @author    Derick Turner
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once($CFG->libdir . "/externallib.php");

class block_manage_group_external extends external_api {

    /**
     * block_iomad_company_admin_create_companies
     *
     * Return description of method parameters
     * @return external_function_parameters
    */

    public static function get_course_data_is_allowed_from_ajax() {
        return true;
    }    
   
    /**
     * Paramters defined for create service function.
     */
    public static function get_course_data_parameters() {
        return new external_function_parameters([
            'courseids' => new external_value(PARAM_RAW, 'Course Selection'),
            'groupassignlist' => new external_value(PARAM_RAW, 'Employee List'),
            'due_type' => new external_value(PARAM_RAW, 'type'),
            'due_number' => new external_value(PARAM_RAW, 'Due Date'),
            'table_type' => new external_value(PARAM_RAW, 'Table Type'),
            'duedate' => new external_single_structure([
                'quarterly' => new external_value(PARAM_RAW, 'Quarterly')
            ], 'duedate'),
            'calendar_year' => new external_value(PARAM_RAW, 'calendar_year'),
        ]);
    }
    
    public static function get_course_data($courseids, $groupassignlist, $due_type, $due_number, $table_type, $duedate, $calendar_year) {

        global $DB;
        $return = new stdClass();
        $return->userlist = array();        
        $courseidarray = json_decode($courseids);
        $groupassignlist = json_decode($groupassignlist);
        $groupassignew = implode(',', $groupassignlist);
        
            if ($table_type == 'initialtraining') {
                foreach ($courseidarray as $courseid) {
                    $new = array();
                    $course = $DB->get_record('course', array('id' => $courseid));
                    $query = "SELECT cd.value as dvalue
                        FROM {customfield_data} cd
                        WHERE fieldid = ? AND instanceid = ?";
                    $dueDates = $DB->get_records_sql($query, array(1, $courseid));
                    if ($dueDates) {
                        foreach ($dueDates as $dueDate) {
                            $hours = $dueDate->dvalue;
                        }
                    } else {
                        $hours = 0; 
                    }
                        $new['coursename'] = $course->fullname;
                        $new['groupassign'] = $groupassignew;
                        $new['coursehours'] = $hours;
                        $new['duedate'] = "{$due_number} {$due_type}"; 
                        $return->userlist[] = $new;
                
            
            }        
        } elseif ($table_type == 'annual') {
            $duedate_duration = $duedate['quarterly'];
           
            if ($duedate_duration == 'quarterly') {
                $numCourses = count($courseidarray);
                $courseIndex = 0;       

                // $current_month = date('m');
                $current_year = date('Y'); 
                $current_month = date('m');

                if ($calendar_year == $current_year) {
                    $caldate = strtotime($calendar_year . '-' . $current_month . '-01');
                    // $caldate = strtotime($calendar_year . '-01-01');
                    
                } else {
                    $caldate = strtotime($calendar_year . 'Y' . $current_month . '-01');
                }

    

                // $caldate = strtotime($calendar_year . '-' . $current_month . '-01');
                $jan = strtotime($calendar_year . '-01-01');
                $apr = strtotime($calendar_year . '-04-01');
                $jul = strtotime($calendar_year . '-07-01');
                $oct = strtotime($calendar_year . '-10-01');
                
                    if ($caldate < $jan) {
                        $totalqueter = 4;
                    } elseif ($caldate > $jan && $caldate < $apr) {
                        $totalqueter = 3;
                    } elseif ($caldate > $apr && $caldate < $jul) {
                        $totalqueter = 2;
                    } elseif ($caldate > $jul && $caldate < $oct) {
                        $totalqueter = 1;
                    } else {
                        $calendar_year++;
                        $totalqueter = 4; 
                    }
                    
                    $addedcourse = ceil($numCourses/$totalqueter);
                    $skip = 0;
                    for ($i = 1; $i <= 4; $i++) {
                        $coursename = '';
                        $hours = 0;
                        $new1 = array();
                        $new1['duedate'] = "Quarter " . $i;
                        $new1['coursename'] = "";
                        $new1['coursehours'] = "";
                        $new1['calendar_year'] = "";
                        
                        for($j=0; $j<$addedcourse; $j++){
                            if($totalqueter<4 && $i==1){
                                $skip++;
                                break;
                            }
                            if($totalqueter<3 && $i==2){
                                $skip++;
                                break;
                            }
                            if($totalqueter<2 && $i==3){
                                $skip++;
                                break;
                            }
                        
                            if($i==1){
                                $index = $j;
                            }
                            if($i==2){
                                if($skip==1){
                                    $index = $j;
                                }
                                else{
                                    $index = $j+$addedcourse;
                                } 
                            }
                            if($i==3){
                                if($skip==1){
                                    $index = $j+$addedcourse;
                                }  
                                elseif($skip==2){
                                    $index = $j;
                                }                  
                                else{
                                    $index = $j+($addedcourse*2);
                                }
                                
                            }
                            if($i==4){
                                if($skip==1){ 
                                    $index = $j+($addedcourse*2);
                                }  
                                elseif($skip==2){
                                    $index = $j+$addedcourse;
                                }                  
                                elseif($skip==3){
                                    $index = $j;
                                }
                                else{
                                    $index = $j+($addedcourse*3);
                                }
                                
                            }
                            $course = $DB->get_record('course', array('id' => $courseidarray[$index]));
                            $query = "SELECT cd.value as dvalue
                                FROM {customfield_data} cd
                                WHERE fieldid = ? AND instanceid = ?";
                            $dueDates = $DB->get_records_sql($query, array(1, $courseidarray));
                            if ($dueDates) {
                                foreach ($dueDates as $dueDate) {
                                    $hours += $dueDate->dvalue;
                                }
                            } else {
                                $hours = 0;
                            }
                            
                            $coursename .= $course->fullname.',';
                            
                        }
                        
                        $new1['duedate'] = "Quarter " . $i;
                        $courseid = $courseids[$courseIndex];
                        $new1['coursename'] = $coursename;
                        $new1['coursehours'] = $hours;
                
                        // $current_year =  $calendar_year['year'];

                        if ($i == 1) {
                            $caldate = "31/Mar/" . $calendar_year;
                        } elseif ($i == 2) {
                            $caldate = "30/June/" . $calendar_year;
                        } elseif ($i == 3) {
                            $caldate = "30/Sept/" . $calendar_year;
                        } elseif ($i == 4) {
                            $caldate = "31/Dec/" . $calendar_year;
                        }

                        $new1['calendar_year'] = $caldate;

                        $return->userlist[] = $new1;
                    }
                }
                elseif ($duedate_duration == 'semiannual') {
                    $numCourses = count($courseidarray);
                    $courseIndex = 0;

                    $current_year = date('Y'); 
                    $current_month = date('m');

                    if ($calendar_year == $current_year) {
                        $caldate = strtotime($calendar_year . '-01-01');
                        
                    } else {
                        $caldate = strtotime($calendar_year . 'Y' . $current_month . '-01');
                    }

                    $jan = strtotime($calendar_year . '-01-01');
                    $jul = strtotime($calendar_year . '-07-01');
                
                    if ($caldate < $jan) {
                        $totalqueter = 2;
                    } elseif ($caldate >= $jan && $caldate < $jul) {
                        $totalqueter = 1; 
                    } else {
                        // $calendar_year++;
                        $totalqueter = 2; 
                    }
                
                    $addedcourse = ceil($numCourses / $totalqueter);
                    $return->userlist = array();
                    $skip = 0;
                    for ($i = 1; $i <= 2; $i++) {
                        $coursename = ''; 
                        $hours = 0;
                
                        $new2 = array();
                        $new2['duedate'] = "Quarter " . $i;
                        $new2['coursename'] = "";
                        $new2['coursehours'] = "";
                        $new2['calendar_year'] = "";
                
                        for ($j = 0; $j < $addedcourse; $j++) {

                            if($totalqueter<2 && $i==1){
                                $skip++;
                                break;
                            }
                            if($i==1){
                                $index = $j;
                            }
                            
                            if($i==2){
                                if($skip==1){
                                    $index = $j;
                                }
                                else{
                                    $index = $j+$addedcourse;
                                } 
                            }
                
                            $course = $DB->get_record('course', array('id' => $courseidarray[$index]));
                            $query = "SELECT cd.value as dvalue
                                    FROM {customfield_data} cd
                                    WHERE fieldid = ? AND instanceid = ?";
                            $dueDates = $DB->get_records_sql($query, array(1, $courseidarray[$index]));
                
                            if ($dueDates) {
                                foreach ($dueDates as $dueDate) {
                                    $hours += $dueDate->dvalue; 
                                }
                            }
                            
                            $coursename .= $course->fullname . ',';
                        }
                      
                        $new2['coursename'] = $coursename;
                        $new2['coursehours'] = $hours;
                        $new2['calendar_year'] = ($i == 1) ? "31/Jul/" . $calendar_year : "31/Dec/" . $calendar_year;
                
                        $return->userlist[] = $new2;
                    }
                }
                elseif ($duedate_duration == 'annualduration') {
                    $numCourses = count($courseidarray);
                    $courseIndex = 0;

                    $current_month = date('m');
                    $caldate = strtotime($calendar_year . '-' . $current_month . '-01');
                    $jan = strtotime($calendar_year . '-01-01');
                    $dec = strtotime($calendar_year . '-12-31'); 
                    
                    if ($current_month == '12') { 
                        $totalqueter = 1; 
                    } else {
                        $totalqueter = 1;
                    }
                    
                    $addedcourse = $numCourses; 
                    $return->userlist = array();
                    
                    $coursename = ''; 
                    $hours = 0;
                    
                    for ($j = 0; $j < $addedcourse; $j++) {
                        $index = $j;
                        if ($index >= $numCourses) {
                            break; 
                        }
                    
                        $course = $DB->get_record('course', array('id' => $courseidarray[$index]));
                        $query = "SELECT cd.value as dvalue
                                FROM {customfield_data} cd
                                WHERE fieldid = ? AND instanceid = ?";
                        $dueDates = $DB->get_records_sql($query, array(1, $courseidarray[$index]));
                    
                        if ($dueDates) {
                            foreach ($dueDates as $dueDate) {
                                $hours += $dueDate->dvalue; 
                            }
                        }
                                        
                        $coursename .= $course->fullname . ',';
                    }
                    
                    $new3 = array();
                    $new3['duedate'] = "Quarter 1";
                    $new3['coursename'] = $coursename;
                    $new3['coursehours'] = $hours;
                    $new3['calendar_year'] = "31/Dec/" . $calendar_year;
                    
                    $return->userlist[] = $new3;
                }
        }
            return json_encode($return);
    }

    public static function get_course_data_returns() {
        return new external_value(PARAM_RAW, 'Comment Link');
    }

}