<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_course_wise_time', language 'en', branch 'MOODLE_20_STABLE'
 *
 * @package   block_manage_group
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Manage Group';
$string['companyname'] = 'Company Name';
$string['Contractenddate'] = 'Contract End Date';
$string['companystatus'] = 'Company Status';
$string['serialno'] = 'Serial no';
$string['submitbutton'] = 'Submit';
$string['fromtrx_date'] = 'From Date';
$string['totrx_date'] = 'To Date';
$string['select_company'] = 'Select a Company';
$string['allusers'] = 'All Company';
$string['notfy'] = 'To Start date must be greater than From End date';
$string['norecordfound'] = 'No Records Found';
$string['enddaenofound'] = 'End Date Not Found';
$string['active'] = 'Active';
$string['suspended'] = 'Suspended';
$string['companycontract'] = 'All Company Contract';
$string['download_csv'] = 'Download CSV File';
$string['headername'] = 'All Company Details';
$string['generated_report'] = 'Report generated date :';
$string['total_users'] = 'Total Company :';


$string['packagename'] = 'Package Name';
$string['type'] = 'Type';
$string['annual'] = 'Annual (12 Months)';
$string['initialtraining'] = 'Initial Training';
$string['multistepplan'] = 'Multi-Step Plan';
$string['selectcalendaryear'] = 'Select Calendar Year';
$string['selecttrainingduration'] = 'Select Training Duration';
$string['selectany'] = '--- SELECT ANY ---';
$string['days'] = 'Day';
$string['months'] = 'Month';
$string['years'] = 'Years';
$string['trainingduration'] = 'Training Duration';
$string['duedateduration'] = 'Due Date Duration';
$string['quarterly'] = 'Quarterly';
$string['semiannual'] = 'Semi-Annual';
$string['annualduration'] = 'Annual';
$string['howmanyhours'] = 'How Many Hours are Required?';
$string['selectemployeetype'] = 'Select Employee Type';
$string['assignonnewyear'] = 'Assign to all employees in selected group';
$string['assigntonewemployees'] = 'Assign to all new or transferred employees';
$string['add'] = 'Add';


$string['managecoursepackages'] = 'Manage Course Packages';
$string['selectpackagetype'] = 'Select Package Type';
$string['packagetype'] = 'Package Type';
$string['savechanges'] = 'Save Changes';

