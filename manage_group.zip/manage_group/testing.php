<?php
require_once('../../config.php');
 global $CFG, $DB, $OUTPUT;
// $get_details=$DB->get_records_sql("SELECT cu.userid , ue.enrolid FROM {company_users} cu 
// INNER JOIN {user_enrolments} ue ON cu.userid = ue.userid 
// WHERE cu.companyid = 6");
$get_details=$DB->get_records_sql("SELECT userid FROM {company_users}
WHERE companyid = 6");
foreach ($get_details as $detail) {
    $rrr = $detail->userid;
    $get_detail=$DB->get_records_sql("SELECT enrolid FROM {user_enrolments} WHERE userid = $rrr");
    echo "<pre>";
    print_r($get_detail);
    echo "<pre>";
}
 // echo "<pre>";
 // print_r($get_details);
 // echo "<pre>";
?>