<?php 
require_once('../../config.php');
function get_custom_duedate($type,$duration,$totalcourses,$calendar_year,$count){
    if ($type == 'annual') {  
        if ($duration == 'quarterly') {
            $current_year = date('Y'); 
            $current_month = date('m');

                if ($calendar_year == $current_year) {
                    $caldate = strtotime($calendar_year . '-' . $current_month . '-01');
                    // $caldate = strtotime($calendar_year . '-01-01');
                    
                } else {
                    $caldate = strtotime($calendar_year . 'Y' . $current_month . '-01');
                }
            $jan = strtotime($calendar_year . '-01-01');
            $apr = strtotime($calendar_year . '-04-01');
            $jul = strtotime($calendar_year . '-07-01');
            $oct = strtotime($calendar_year . '-10-01');
            
                if ($caldate < $jan) {
                    $totalqueter = 4;
                } elseif ($caldate > $jan && $caldate < $apr) {
                    $totalqueter = 3;
                } elseif ($caldate > $apr && $caldate < $jul) {
                    $totalqueter = 2;
                } elseif ($caldate > $jul && $caldate < $oct) {
                    $totalqueter = 1;
                } else {                   
                    $totalqueter = 4; 
                }
            $skip = 0;
            $qcourses = ceil($totalcourses/$totalqueter);
            $qqcourses = $qcourses+$qcourses;
            $qqqcourses = $qqcourses+$qcourses;
            $qqqqcourses = $qqqcourses+$qcourses;
  
            $datepart = 0;

                if ($count <= $qcourses) {
                    $custom_due_date = date('Y-m-d', strtotime("31-Mar-$calendar_year"));
                } elseif ($count > $qcourses && $count <= $qqcourses) {
                    $custom_due_date = date('Y-m-d', strtotime("30-Jun-$calendar_year"));
                } elseif ($count > $qqcourses && $count <= $qqqcourses) {
                    $custom_due_date = date('Y-m-d', strtotime("30-Sep-$calendar_year"));
                } elseif ($count > $qqqcourses && $count <= $qqqqcourses) {
                    $custom_due_date = date('Y-m-d', strtotime("31-Dec-$calendar_year"));
                }
            return $custom_due_date;
        }  elseif ($duration == 'semiannual') {
            $current_year = date('Y'); 
            $current_month = date('m');
        
            if ($calendar_year == $current_year) {
                $caldate = strtotime($calendar_year . '-01-01');
            } else {
                $caldate = strtotime($calendar_year . 'Y' . $current_month . '-01');
            }
        
            $jan = strtotime($calendar_year . '-01-01');
            $jul = strtotime($calendar_year . '-07-01');
        
            if ($caldate < $jan) {
                $totalqueter = 2;
            } elseif ($caldate >= $jan && $caldate < $jul) {
                $totalqueter = 1; 
            } else {
                $totalqueter = 2; 
            }
        
            $skip = 0;
            $qcourses = ceil($totalcourses / $totalqueter);
            $qqcourses = $qcourses + $qcourses;
        
            if ($count <= $qcourses) {
                $custom_due_date = date('Y-m-d', strtotime("30-Jun-$calendar_year"));
            } elseif ($count > $qcourses && $count <= $qqcourses) {
                $custom_due_date = date('Y-m-d', strtotime("31-Dec-$calendar_year"));
            }
        
            return $custom_due_date;
        }elseif ($duration == 'annualduration') {
            $current_year = date('Y'); 
            $current_month = date('m');
        
            if ($calendar_year == $current_year) {
                $caldate = strtotime($calendar_year . '-01-01');
            } else {
                $caldate = strtotime($calendar_year . '-'.$current_month.'-01');
            }
        
            $jan = strtotime($calendar_year . '-01-01');
            $dec = strtotime($calendar_year . '-12-31');
        
            if ($caldate < $jan) {
                $custom_due_date = date('Y-m-d', strtotime("30-Jun-$calendar_year"));
            } else {
                $custom_due_date = date('Y-m-d', strtotime("31-Dec-$calendar_year"));
            }
        
            return $custom_due_date;
        }
        
    }

}
