<?php
require_once('../../config.php');
global $DB, $USER, $CFG;
redirect_if_major_upgrade_required();
require_login();
$context = context_system::instance();
$companyid1 = iomad::get_my_companyid($context);

$urlparams = array();

if (!empty($CFG->defaulthomepage) && ($CFG->defaulthomepage == HOMEPAGE_MY) && optional_param('redirect', 1, PARAM_BOOL) === 0) {

    $urlparams['redirect'] = 0;
}

$PAGE->set_course($SITE); 
$PAGE->set_url('/', $urlparams);
$PAGE->set_title('Manage Groups');
$PAGE->set_pagelayout('sidebar');
$PAGE->set_heading('Manage Groups');
echo $OUTPUT->header();
?>

<!-- Pal info com -->
<div class="total_tasks">
	<h3>Compliance</h3><hr>
	<ul class="training">
		<li><span class="icon"><i class="fa fa-check-square-o" aria-hidden="true" style="color: #333 !important;"></i></span>  
		<?php
		    $total_tasks=0;
			$gettasks=$DB->get_records_sql("SELECT count(id) as taskid from {master_task_list}");
			foreach ($gettasks as $keytask) {
				$total_tasks=$keytask->taskid;
			}
			echo "Number of Tasks : ".$total_tasks;
		?>
		</li><hr>
		<li><span class="icon"><i class="fa fa-users" aria-hidden="true"></i></span>  
		<?php
		        $total_users=0;
				$select_users = "SELECT count(id) as userid from mdl_user where id NOT IN (1,2) and deleted=0";
				$exe_sel_users = $DB->get_records_sql($select_users);
				foreach ($exe_sel_users as $key) {

					$total_users=$key->userid;
				}
                echo "Number of Employees : ".$total_users;
				
					
		?>
		</li><hr>
		<li><i class="fa fa-book" aria-hidden="true"></i></span>  
		<?php
		    $count_course=0; 
			$query11="SELECT count(id) as cours FROM mdl_course where category!=0";

  			$data11=$DB->get_records_sql($query11);
  			foreach ($data11 as $key11) 
  			{
			    $count_course=$key11->cours;
		    }
		    echo "Number of Courses : ".$count_course;
		    
		?>
  		</li>
	</ul>
</div>

<!-- Pal info com -->

<!-- pal info com  -->
<div class="table-container">
  <table class="data-table">
    <thead>
      <tr>
        <th>Compliance</th>
        <th>Username</th>
        <th>Task name</th>
        <th>Group</th>
        <th>Due date</th>
        <th>View</th>	
      </tr>
    </thead>
    <tbody>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
    </tbody>
  </table>
</div>

<!-- pal info com --> 
<?php
  $companyid=$DB->get_record_sql("SELECT userid as comid from {company_users}
    where userid=$USER->id AND managertype =  1 ");
if($companyid){
}
  else{
     echo "You cannot manage this page! Only BM can manage the courses ";
  }
echo $OUTPUT->footer();