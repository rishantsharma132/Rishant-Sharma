<?php

defined('MOODLE_INTERNAL') || die();

$functions = array(
    'blocks_manage_group_get_course_data' => array(
        'classname' => 'block_manage_group_external',
        'methodname' => 'get_course_data',
        'classpath' => 'blocks/manage_group/externallib.php',
        'description' => 'get cuser fata',
        'type' => 'write',
    )
);