<?php
require_once('../../config.php');
global $DB, $USER, $CFG;

redirect_if_major_upgrade_required();
require_login();

$PAGE->set_title('Manage Course');
$PAGE->set_pagelayout('sidebar');

echo $OUTPUT->header();
 $companyid=$DB->get_record_sql("SELECT userid as comid from {company_users} 
    where userid=$USER->id AND managertype =  1 ");
 $coursewhere = '';
 if(isset($_POST['search1'])){
    $search1=$_POST['search'];
    $coursewhere .= " AND u.firstname LIKE '%$search1%'";
 }
  $coursewhere2 = '';
 if(isset($_POST['search2'])){
    $sear=$_POST['sear'];
    $coursewhere2 .= " AND u.firstname LIKE '%$sear%'";
 }
if ($companyid){
$get_task=$_GET['groupid'];
?>
<div class="main-wrapper">
<div class="main">
  <div class="text-center">
  <h1>Bulk Enrollment New</h1>
  </div>

    <!-- <a href="<?php echo $CFG->wwwroot;?>/my/" class="btn btn-primary">BACK</a> -->
<?php
if(isset($_POST['remove']))
{
    $unassignvalues=$_POST['removeselect'];
   
    if($unassignvalues)
    {
      foreach ($unassignvalues as $key_un) {
        
        $companyid=$DB->get_record_sql("SELECT userid as urid from {company_users} where userid=$USER->id AND managertype = 1 ");
        
          $get_assigned=$DB->get_record('assign_bulk_user', array('userid' => $key_un, 'bm_id' => $companyid->urid));
          if($get_assigned)
          {
            $query= "DELETE from mdl_assign_bulk_user where id=$get_assigned->id";
            $res1 =$DB->execute($query);

            
      }
      }
    }
}

if(isset($_POST['add']))
{
     $assignvalues=$_POST['addselect'];
     

    if($assignvalues)
    {
      foreach ($assignvalues as $key_ass) {
        $companyid=$DB->get_record_sql("SELECT userid as urid from {company_users} where userid=$USER->id AND managertype = 1 ");
        $get_assigned=$DB->get_record('assign_bulk_user', array('course_group_id' => $get_task, 'userid' => $USER->id, 'bm_id' => $companyid->urid));

        if(!$get_assigned)
        {
          $time=time();

          $record = new stdClass();

          $record->bm_id=$USER->id;

          $record->userid=$key_ass;

          $record->course_group_id=$get_task;
          
          $result_data = $DB->insert_record('assign_bulk_user', $record);
          // print_r($result_data);
          // exit();
      }
    }
  }
}
?>
<div role="main"><span id="maincontent" class="task_table"></span>

<?php

      $companyid=$DB->get_record_sql("SELECT companyid as comid from {company_users} where userid=$USER->id ");


     // $compnay_course=$DB->get_records_sql("SELECT * from {company_course} where companyid=$companyid->companyid");
      
      $all_assign_courses = $DB->get_records_sql("SELECT u.id, u.firstname,u.lastname,u.email from {user} u 
      JOIN {assign_bulk_user} abu on u.id=abu.userid WHERE u.deleted = 0 $coursewhere ORDER BY u.firstname ASC");
           
      
      ?>
      <div class="tasks_table">
     
    <h2>Select Employee(s) to Enroll</h2>
    
<form id="assigntasks" method="post">

  <table class="generaltable generalbox boxaligncenter" cellspacing="0">
    <tbody>
        <tr>
        <td id="existingcell">
            <p><label for="removeselect">Assigned Student</label></p>
            <div class="userselector" id="removeselect_wrapper_handmade">
            <select name="removeselect[]" id="removeselect" multiple="multiple" size="20" class="form-control no-overflow">
                <?php
              
                 foreach ($all_assign_courses as  $assign_course) {

                  $get_tasks=$DB->get_records_sql("SELECT * from {assign_bulk_user} where bm_id=$USER->id and userid=$assign_course->id ");

                  if($get_tasks)
                  {
        
                    ?>
                        <option value="<?php echo $assign_course->id; ?>"><?php echo $assign_course->firstname .' '. $assign_course->lastname .' ('. $assign_course->email .')'; ?></option>
                    <?php
                    
                  }
                  // print_r($get_tasks);
                  // exit();
                
              
             }
                ?>
            </select>
            </div>
            <div style="margin-top:10px">
            <input type="text" name="search" placeholder="Search Here" style="height:35px">
              <input type="submit" value="Search" name="search1"><br>

            </div>
             
        </td>
        <td id="buttonscell">
            <div id="addcontrols">
                <input name="add" id="add" type="submit" value="◄&nbsp;Assign" title="Add"><br>
            </div>
            <div id="removecontrols">
                <input name="remove" id="remove" type="submit" value="Unassign&nbsp;►" title="Remove">
            </div>  
        </td>
        <td id="potentialcell">
            <p><label for="addselect">Un-assigned Student</label></p>
            <div class="userselector" id="addselect_wrapper_handmade">
            <select name="addselect[]" id="addselect" multiple="multiple" size="20" class="form-control no-overflow">
            <?php
            
            $all_unassign_courses = $DB->get_records_sql("SELECT u.id, u.firstname,u.lastname,u.email from {user} u JOIN {company_users} cu on u.id=cu.userid
            where cu.companyid=$companyid->comid $coursewhere2 ORDER BY u.firstname ASC");    
            foreach ($all_unassign_courses as  $unassign_courses) {

              $get_tasks=$DB->get_records_sql("SELECT * from {assign_bulk_user} where bm_id=$USER->id and userid=$unassign_courses->id ");

              if(!$get_tasks)
              {
                    ?>
                        <option value="<?php echo $unassign_courses->id; ?>"><?php echo $unassign_courses->firstname .' '. $unassign_courses->lastname .' ('. $unassign_courses->email .')'; ?></option>
                    <?php
                    
              }
                }
              
              ?>
            </select>
            </div>
            <div style="margin-top:10px">
              <input type="text" name="sear" placeholder="Search Here" style="height:35px">
              <input type="submit" value="Search" name="search2"><br>
              </div>

         
        </td>
        </tr>

    </tbody>
</table>
</form>
</div>
</div>
</div>
</div> 
<?php
// }
?>
<script>
  $(document).ready(function(){
      // bind change event to select
      $('#group').on('change', function () {
          var url = $(this).val(); // get selected value
          if (url) { // require a URL
              window.location ="bulk_user_enrol.php?groupid=" + url; // redirect
          }
          return false;
      });
    });
</script>
<?php
}
else{
   echo "You cannot manage this page! Only BM can manage the courses ";
}






$companyid=$DB->get_record_sql("SELECT userid as comid from {company_users} 
where userid=$USER->id AND managertype =  1 ");
$coursewhere11 = '';
if(isset($_POST['search11'])){
$search11=$_POST['search'];
$coursewhere11 .= " AND c.fullname LIKE '%$search11%'";
}
$coursewhere22 = '';
if(isset($_POST['search22'])){
$sear22=$_POST['sear'];
$coursewhere22 .= " AND c.fullname LIKE '%$sear22%'";
}
if ($companyid){
$get_task=$_GET['groupid'];
?>
<div class="main-wrapper">
<div class="main">

<?php
if(isset($_POST['removecourse']))
{
$unassignvalues1=$_POST['removeselect'];

if($unassignvalues1)
{
  foreach ($unassignvalues1 as $key_un) {
    
    $companyid=$DB->get_record_sql("SELECT userid as urid from {company_users} where userid=$USER->id AND managertype = 1 ");
    if (isset($_GET['groupid'])) {
      $groupid=$_GET['groupid'];
      $get_assigned1=$DB->get_record('assign_group_package_course', array( 'course_group_id' =>  $groupid, 'courseid' => $key_un, 'bm_id' => $companyid->urid));
    }else{
      $get_assigned1=$DB->get_record('assign_bulk_course', array( 'courseid' => $key_un, 'bm_id' => $companyid->urid));
    }
      
      if($get_assigned1)
      {
        if (isset($_GET['groupid'])) {
          $query= "DELETE from mdl_assign_group_package_course where id=$get_assigned1->id";
          $res1 =$DB->execute($query);
        }else{
          $query= "DELETE from mdl_assign_bulk_course where id=$get_assigned1->id";
          $res1 =$DB->execute($query);
        }
      

       

        
  }
  }
}
}

if (isset($_GET['groupid'])) {
                $groupid=$_GET['groupid'];
$all_group_data_insert = $DB->get_records_sql("SELECT cga.userid as courseid from {course_group_assignment} cga 
where cga.course_group_id=$groupid AND cga.bm_id = $USER->id "); 
foreach ($all_group_data_insert as $datainsert) {
  $companyid=$DB->get_record_sql("SELECT userid as urid from {company_users} where userid=$USER->id AND managertype = 1 ");
  $get_assigned1=$DB->get_record('assign_group_package_course', array('course_group_id' => $get_task, 'courseid' => $datainsert->courseid, 'bm_id' => $companyid->urid));

  if(!$get_assigned1)
  {
  $time=time();

  $record = new stdClass();

  $record->bm_id=$USER->id;

  $record->courseid=$datainsert->courseid;

  $record->course_group_id=$get_task;

  //print_r($record);
  
  $result_data = $DB->insert_record('assign_group_package_course', $record);
  }
}
   
         }

if(isset($_POST['addcourse']))
{
 $assignvalues1=$_POST['addselect'];
 

if($assignvalues1)
{
  foreach ($assignvalues1 as $key_ass) {
    $companyid=$DB->get_record_sql("SELECT userid as urid from {company_users} where userid=$USER->id AND managertype = 1 ");
    $get_assigned1=$DB->get_record('assign_bulk_course', array('course_group_id' => $get_task, 'courseid' => $key_ass, 'bm_id' => $companyid->urid));

    if(!$get_assigned1)
    {
      $time=time();

      $record = new stdClass();

      $record->bm_id=$USER->id;

      $record->courseid=$key_ass;

      $record->course_group_id=$get_task;

      // print_r($record);
      // exit();
      if (isset($_GET['groupid'])) {
        $result_data = $DB->insert_record('assign_group_package_course', $record);
      }else {
        $result_data = $DB->insert_record('assign_bulk_course', $record);
      }
      

                                   
        
  }
}
}
}
?>
<div role="main"><span id="maincontent" class="task_table"></span>
<form method="POST">
<div id="e_group">

    <select name="groups" class="groups" id="group" class="form-control" value="">
           <?php
if (isset($_GET['groupid'])) {
 $get_task=$_GET['groupid'];
$res1=$DB->get_records_sql("SELECT name from {course_groups} WHERE id = $get_task AND deleted = 0 ORDER BY name ASC");


$lue1 = '';
foreach ($res1 as $lue) {
 $lue1 = $lue->name;
}
if (!empty($lue1)) {
echo "<option value=''selected> $lue1</option>";
}


}

 ?>
         <option value="" >--Select Package Group Type--</option> 
        <?php 
        $res=$DB->get_records_sql("SELECT * from {course_groups} WHERE bm_user_id = $USER->id AND deleted = 0 ORDER BY name ASC");
        foreach($res as $value)
        {
            ?>
              <option value="<?php echo $value->id; ?>"><?php echo $value->name; ?></option>
            <?php
        }
        ?>
    </select>
</div>

</form>
<?php

  $companyid=$DB->get_record_sql("SELECT companyid as comid from {company_users} where userid=$USER->id ");


// $compnay_course=$DB->get_records_sql("SELECT * from {company_course} where companyid=$companyid->companyid");
  // $all_assign_courses = $DB->get_records_sql("SELECT c.id, c.fullname from {course} c JOIN {assign_bulk_course} cc on c.id=cc.courseid
  // where c.category!=985 AND c.visible=1 ORDER BY c.fullname ASC");
  
   if (isset($_GET['groupid'])) {

   $groupid=$_GET['groupid'];

    $all_assign_courses1 = $DB->get_records_sql("SELECT c.id, c.fullname from {assign_group_package_course} abc INNER JOIN {course} c ON abc.courseid = c.id 
    where abc.course_group_id = $groupid AND c.category!=985 AND c.visible=1 $coursewhere11 ORDER BY c.fullname ASC");
   
  }
   else{
     $all_assign_courses1 = $DB->get_records_sql("SELECT c.id, c.fullname from {assign_bulk_course} abc INNER JOIN {course} c ON abc.courseid = c.id 
     where c.category!=985 AND c.visible=1 $coursewhere11 ORDER BY c.fullname ASC");
  }
  
  // print_r($all_assign_courses1); 
  // exit();  
  
  ?>

<!-- Pal infocom -->
<form method="post">
  <label for="start" class="date" >Due date:
  <input type="date" id="start" name="trip-start" /></label>
</form>
<script>
   document.addEventListener('DOMContentLoaded', function() {
    const currentDate = new Date(); 
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth() + 1;
    const day = currentDate.getDate();

    const formattedDate = `${year}-${month < 10 ? '0' + month : month}-${day < 10 ? '0' + day : day}`;

    document.getElementById('start').value = formattedDate; 
    
   
    const calendarEl = document.getElementById('calendar',

    // const calendar = new FullCalendar.Calendar(calendarEl,
     {
      initialView: 'dayGridMonth',
      height: 650,
      events: 'fetchEvents.php', 
      selectable: true,
      select: async function(start, end, allDay) {
        const { value: formValues } = await Swal.fire({
          title: 'Add Event',
          html:
            '<input id="swalEvtTitle" class="swal2-input" placeholder="Enter title">' +
            '<textarea id="swalEvtDesc" class="swal2-input" placeholder="Enter description"></textarea>' +
            '<input id="swalEvtURL" class="swal2-input" placeholder="Enter URL">',
          focusConfirm: false,
          preConfirm: () => {
            return [
              document.getElementById('swalEvtTitle').value,
              document.getElementById('swalEvtDesc').value,
              document.getElementById('swalEvtURL').value
            ]
          }
        });

        if (formValues) {
          fetch("bulk_user_enrol.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ request_type:'addEvent', start:start.startStr, end:start.endStr, event_data: formValues}),
          })
          .then(response => response.json())
          .then(data => {
            if (data.status == 1) {
              Swal.fire('Event added successfully!', '', 'success');
            } else {
              Swal.fire(data.error, '', 'error');
            }

            calendar.refetchEvents();
          })
          .catch(console.error);
        }
      }
    });

    // calendar.render();
  });

</script>

<!-- Pal infocom -->

  <div class="tasks_table">
 
<h2>Select Course to Enroll</h2>

<form id="assigntasks" method="post">

<table class="generaltable generalbox boxaligncenter" cellspacing="0">
<tbody>
    <tr>
    <td id="existingcell">
        <p><label for="removeselect">Assigned Course</label></p>
        <div class="userselector bottomselector" id="removeselect_wrapper_handmade">
        <select name="removeselect[]" id="removeselect" multiple="multiple" size="20" class="form-control no-overflow">
            <?php
           
             foreach ($all_assign_courses1 as  $assign_course) {
              if (isset($_GET['groupid'])) {
                $groupid=$_GET['groupid'];
                $get_tasks=$DB->get_records_sql("SELECT * from {assign_group_package_course} where bm_id=$USER->id and courseid=$assign_course->id AND course_group_id = $groupid ");
               }else {
                $get_tasks=$DB->get_records_sql("SELECT * from {assign_bulk_course} where bm_id=$USER->id and courseid=$assign_course->id ");
               }

             

              if($get_tasks)
              {
    
                ?>
                    <option value="<?php echo $assign_course->id; ?>"><?php echo $assign_course->fullname; ?></option>
                <?php
                
              }
            }
          
            ?>
        </select>
        </div>
        <div style="margin-top:10px">
         <input type="text" name="search" placeholder="Search Here" style="height:35px">
          <input type="submit" value="Search" name="search1"><br>
        </div>
    </td>
    <td id="buttonscell">
        <div id="addcontrols">
            <input name="addcourse" id="addcourse" type="submit" value="◄&nbsp;Assign" title="Add"><br>
        </div>
        <div id="removecontrols">
            <input name="removecourse" id="removecourse" type="submit" value="Unassign&nbsp;►" title="Remove">
        </div>  
    </td>
    <td id="potentialcell">
        <p><label for="addselect">Un-assigned Course</label></p>
        <div class="userselector bottomselector" id="addselect_wrapper_handmade">
        <select name="addselect[]" id="addselect" multiple="multiple" size="20" class="form-control no-overflow">
        <?php
        
  //        if (isset($_GET['groupid'])) {
  //               $groupid=$_GET['groupid'];
  //       $all_unassign_courses1 = $DB->get_records_sql("SELECT c.id, c.fullname from {course} c JOIN {course_group_assignment} cga on c.id=cga.userid
  // where cga.course_group_id=$groupid AND cga.bm_id = $USER->id AND c.category!=985 AND c.visible=1 $coursewhere22 ORDER BY c.fullname ASC"); 
   
  //        }else{
          $all_unassign_courses1 = $DB->get_records_sql("SELECT c.id, c.fullname from {course} c JOIN {company_course} cc on c.id=cc.courseid
          where cc.companyid=$companyid->comid AND c.category!=985 AND c.visible=1 $coursewhere22 ORDER BY c.fullname ASC"); 
         //}

        foreach ($all_unassign_courses1 as  $unassign_courses) {
          if (isset($_GET['groupid'])) {
            $groupid=$_GET['groupid'];
               $get_tasks=$DB->get_records_sql("SELECT * from {assign_group_package_course} where bm_id=$USER->id and courseid=$unassign_courses->id and course_group_id=$groupid");

             }else{
              $get_tasks=$DB->get_records_sql("SELECT * from {assign_bulk_course} where bm_id=$USER->id and courseid=$unassign_courses->id");

            }
              
              if(!$get_tasks)
              {
                ?>
                    <option value="<?php echo $unassign_courses->id; ?>"><?php echo $unassign_courses->fullname; ?></option>
                <?php
                
             }
            }
          
          ?>
        </select>
        </div>
        <div style="margin-top:10px">
          <input type="text" name="sear" placeholder="Search Here" style="height:35px">
          <input type="submit" value="Search" name="search22"><br>
        </div>

     
    </td>
    </tr>

</tbody>
</table>
</form>
</div>
</div>
</div>
</div> 



<!-- pal infocom -->

<button class="enrol-preview-btn">Preview</button>
<table id="enrolled-courses-table" style="display: none;">
    <thead>
        <tr>
            <th>Course Section</th>
            <th>Employee</th>
            <th>Hours</th>
            <th>Due Date</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        
        foreach ($all_assign_courses1 as $assign_course) : ?>
            <tr>
                <td><?php echo $assign_course->fullname; ?></td>
                <td>
                    <?php

                    if($all_assign_courses){
                    foreach ($all_assign_courses as $assign_user) {
                        $assign_user->courseid == $assign_course->id;
                        echo $assign_user->firstname . ' ' . $assign_user->lastname . '<br>';
                      }
                    }else{
                      echo "No Employee selected";
                    }
                    
                    ?>
                </td>
              
                <td>
                  <span class="due-date-count">
                    <?php

                    $query = "SELECT cd.value as dvalue
                              FROM {customfield_data} cd
                              WHERE fieldid = ? AND instanceid = ?";

                    $dueDates = $DB->get_records_sql($query, array(1, $assign_course->id));
                    // print_r($dueDates);

                    if ($dueDates) {
                        foreach ($dueDates as $dueDate) {
                            echo $dueDate->dvalue . "<br>";
                        }
                    } else {
                        echo "No due dates found."; 
                    }
                    ?>
                  </span>
                </td>

                <td>
                     <span class="due-date-placeholder"></span>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>  
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const previewButton = document.querySelector('.enrol-preview-btn');
        const table = document.getElementById('enrolled-courses-table');

        previewButton.addEventListener('click', function () {
            table.style.display = 'table';
            var startdate = document.getElementById("start").value;
            var allclass = document.getElementsByClassName('due-date-placeholder');
            for (var i = 0; i < allclass.length; i++) {
              allclass[i].innerHTML = startdate;
            }
        });
    });
</script>
<br>
<!-- pal info com  -->

<div class="text-center">
  <form action="" method="POST">
    <input type="text" value="" id="abc" name="abc" style="display: none;">
<button Type="submit"  name="Bulkenrol" class="btn btn-primary">Bulk Enroll</button> 
</form>
</div>

<script>
$(document).ready(function(){
  $('#group').on('change', function () {
      var url = $(this).val(); 
      if (url) { 
          window.location ="bulk_user_enrol.php?groupid=" + url; // redirect
      }else{
        window.location ="bulk_user_enrol.php";
      }
      return false;
  });
});
// pal info com
jQuery( document ).ready(function() {
   
  $('#start').on('change', function () {

  $('#abc').val($(this).val()); 
  
  });
});
// pal info com
</script>


<?php
}
else{
echo "You cannot manage this page! Only BM can manage the courses ";
}



if (isset($_POST['Bulkenrol'])) {
  $all_ass_user = $DB->get_records_sql("SELECT userid as uids from {assign_bulk_user} ");

  if (isset($_GET['groupid'])) {
    $groupid=$_GET['groupid'];
  
    $all_ass_course = $DB->get_records_sql("SELECT courseid as courid from {assign_group_package_course} WHERE course_group_id = $groupid");
  }else{
    $all_ass_course = $DB->get_records_sql("SELECT courseid as courid from {assign_bulk_course} ");
  }
  
  // echo "<pre>";
  // print_r($all_ass_course);
  // echo "</pre>";
  
foreach ($all_ass_course as $courid) {
  $courseid = $courid->courid;
  $instance = $DB->get_record('enrol', array('courseid'=>$courseid, 'enrol'=>'manual'), '*', MUST_EXIST);

      if(!empty($instance))
      {
          foreach ($all_ass_user as $useid) {
            $userid = $useid->uids;
          $coursecontext = context_course::instance($courseid);
            $alreadyenrol = $DB->get_record_sql("SELECT ue.id from {enrol} e 
            INNER JOIN {user_enrolments} ue ON e.id=ue.enrolid WHERE e.courseid = $courseid AND ue.userid = $userid");
            if ($alreadyenrol) {
              
              $get_assigned=$DB->get_record('assign_bulk_user', array('userid' => $userid));
              if($get_assigned)
              {
                $query= "DELETE from mdl_assign_bulk_user where id=$get_assigned->id";
                $res1 =$DB->execute($query);
              }

        $get_assigned1=$DB->get_record('assign_bulk_course', array( 'courseid' => $courseid));
      if($get_assigned1)
      {
        $query= "DELETE from mdl_assign_bulk_course where id=$get_assigned1->id";
        $res1 =$DB->execute($query);    
  }
            }else{
              if(!is_enrolled($coursecontext, $userid))
              {
                  $timestart = time();
// pal info com
                  $timeend = strtotime($_POST['abc']);
//pal info com
                  $enrol_manual = enrol_get_plugin('manual');
    
                  $enrolled = $enrol_manual->enrol_user($instance, $userid, $role_id, $timestart, $timeend);
                    $get_assigned=$DB->get_record('assign_bulk_user', array('userid' => $userid));
                    if($get_assigned)
                    {
                      $query= "DELETE from mdl_assign_bulk_user where id=$get_assigned->id";
                      $res1 =$DB->execute($query);
                    }
                              $get_assigned1=$DB->get_record('assign_bulk_course', array( 'courseid' => $courseid));
                if($get_assigned1)
                {
                  $query= "DELETE from mdl_assign_bulk_course where id=$get_assigned1->id";
                  $res1 =$DB->execute($query);    
            }
                  
                    
                  
              }
            }
          }

      }
  }

  ?>
                  <script type='text/javascript'>
                  alert('User enrolled Successfully into selected course!!!');
                  window.location.href = "<?php $CFG->wwwroot;?>/lms/blocks/manage_group/bulk_user_enrol.php";

                  </script>
                   <?php

}

echo $OUTPUT->footer(); 